"""
TelegramDriveSync Bot - Configuration
All tokens, IDs, and global settings
"""

import os
from typing import List

class Config:
    """Configuration class for bot settings"""
    
    # Bot Configuration
    BOT_TOKEN = os.getenv("BOT_TOKEN", "7658474148:AAH1AZ3Ec-4cIkrFLSoW8cKs6c92Hvtmsm4")
    
    # Admin Configuration
    ADMIN_IDS = [
        7230950406,  # Primary admin (auto-detected)
        # Add more admin IDs here as needed
    ]
    
    # Payment Configuration
    CRYPTOBOT_API_TOKEN = os.getenv("CRYPTOBOT_API_TOKEN", "416708:AAWOiCPexQOgq3YpPCejNEOxr52uYqlH521")
    
    # Group Configuration
    AUTHORIZED_GROUPS = []  # Groups where bot can share files/logs
    
    # Google Drive Configuration
    GOOGLE_CLIENT_ID = os.getenv("GOOGLE_CLIENT_ID", "")
    GOOGLE_CLIENT_SECRET = os.getenv("GOOGLE_CLIENT_SECRET", "")
    GOOGLE_REDIRECT_URI = os.getenv("GOOGLE_REDIRECT_URI", "urn:ietf:wg:oauth:2.0:oob")
    
    # Database Configuration
    DATABASE_PATH = "bot_database.db"
    
    # File Storage Configuration
    STORAGE_PATH = "storage"
    MAX_FILE_SIZE = 50 * 1024 * 1024  # 50MB
    ALLOWED_FILE_TYPES = [
        'image/jpeg', 'image/png', 'image/gif', 'image/webp',
        'video/mp4', 'video/avi', 'video/mkv', 'video/mov',
        'application/pdf', 'application/zip', 'application/rar',
        'text/plain', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
    ]
    
    # Twitter/X Configuration
    TWITTER_BEARER_TOKEN = os.getenv("TWITTER_BEARER_TOKEN", "")
    
    # Subscription Configuration
    SUBSCRIPTION_PRICE_USD = 5.00  # Price in USD
    SUBSCRIPTION_DURATION_DAYS = 365  # 1 year
    
    # Bot Messages
    MESSAGES = {
        'welcome': (
            "🤖 <b>Selamat datang di TelegramDriveSync!</b>\n\n"
            "🔹 Upload file ke Google Drive\n"
            "🔹 Scraping Twitter/X\n"
            "🔹 Multi-akun Google Drive\n"
            "🔹 Streaming video langsung\n"
            "🔹 Log aktivitas lengkap\n\n"
            "💳 Berlangganan sekali, akses selamanya!"
        ),
        'subscription_required': (
            "💳 <b>Berlangganan Diperlukan</b>\n\n"
            "Untuk menggunakan bot ini, Anda perlu berlangganan terlebih dahulu.\n\n"
            "💰 Harga: $5.00 USD\n"
            "⏰ Durasi: Selamanya\n"
            "🚫 Sekali bayar, tidak ada biaya bulanan\n\n"
            "Klik tombol di bawah untuk mulai berlangganan:"
        ),
        'oauth_required': (
            "🔐 <b>Koneksi Google Drive Diperlukan</b>\n\n"
            "Anda perlu menghubungkan akun Google Drive untuk melanjutkan.\n\n"
            "✅ Aman dan terenkripsi\n"
            "🔒 Bot tidak menyimpan password\n"
            "📁 Akses hanya untuk upload file\n\n"
            "Klik tombol di bawah untuk memulai:"
        ),
        'payment_success': (
            "✅ <b>Pembayaran Berhasil!</b>\n\n"
            "Selamat! Langganan Anda telah aktif.\n"
            "Sekarang silakan hubungkan akun Google Drive untuk mulai menggunakan semua fitur."
        ),
        'oauth_success': (
            "✅ <b>Google Drive Terhubung!</b>\n\n"
            "Akun Google Drive Anda berhasil dihubungkan.\n"
            "Sekarang Anda dapat menggunakan semua fitur bot.\n\n"
            "Gunakan /menu untuk melihat menu utama."
        )
    }
    
    # Pagination Settings
    ITEMS_PER_PAGE = 5
    MAX_CALLBACK_DATA_LENGTH = 64
    
    # Rate Limiting
    MAX_UPLOADS_PER_HOUR = 20
    MAX_SCRAPING_PER_DAY = 100
    
    # Auto Cleanup Settings
    AUTO_CLEANUP_DAYS = 30
    LOG_RETENTION_DAYS = 90
    
    # Broadcast Settings
    BROADCAST_CHUNK_SIZE = 20
    BROADCAST_DELAY_SECONDS = 1
    
    # Error Handling
    MAX_RETRIES = 3
    RETRY_DELAY_SECONDS = 5
    
    @classmethod
    def is_admin(cls, user_id: int) -> bool:
        """Check if user is admin"""
        return user_id in cls.ADMIN_IDS
    
    @classmethod
    def add_authorized_group(cls, group_id: int):
        """Add group to authorized list"""
        if group_id not in cls.AUTHORIZED_GROUPS:
            cls.AUTHORIZED_GROUPS.append(group_id)
    
    @classmethod
    def remove_authorized_group(cls, group_id: int):
        """Remove group from authorized list"""
        if group_id in cls.AUTHORIZED_GROUPS:
            cls.AUTHORIZED_GROUPS.remove(group_id)
    
    @classmethod
    def is_authorized_group(cls, group_id: int) -> bool:
        """Check if group is authorized for file sharing"""
        return group_id in cls.AUTHORIZED_GROUPS
