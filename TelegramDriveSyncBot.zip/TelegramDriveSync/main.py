#!/usr/bin/env python3
"""
TelegramDriveSync Bot - Main Entry Point
Handles bot startup, polling, and admin notifications
"""

import logging
import os
import asyncio
from telegram.ext import Application
from config import Config
from bot import setup_bot
from database import init_database
from scheduler import setup_scheduler
import signal
import sys

# Configure logging
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO,
    handlers=[
        logging.FileHandler('bot.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class TelegramDriveSyncBot:
    def __init__(self):
        self.application = None
        self.scheduler = None
        
    async def notify_admin_startup(self):
        """Notify admins that bot has started"""
        try:
            for admin_id in Config.ADMIN_IDS:
                await self.application.bot.send_message(
                    chat_id=admin_id,
                    text="🤖 <b>Bot Telah Aktif!</b>\n\n"
                         "✅ Sistem berhasil dimulai\n"
                         "📊 Database terhubung\n"
                         "⏰ Scheduler aktif\n"
                         "🔄 Polling dimulai\n\n"
                         "<i>Bot siap melayani pengguna!</i>",
                    parse_mode='HTML'
                )
        except Exception as e:
            logger.error(f"Failed to notify admin about startup: {e}")
    
    async def setup_signal_handlers(self):
        """Setup graceful shutdown handlers"""
        def signal_handler(signum, frame):
            logger.info(f"Received signal {signum}, shutting down gracefully...")
            asyncio.create_task(self.shutdown())
        
        signal.signal(signal.SIGINT, signal_handler)
        signal.signal(signal.SIGTERM, signal_handler)
    
    async def shutdown(self):
        """Graceful shutdown"""
        logger.info("Shutting down bot...")
        
        # Notify admins about shutdown
        try:
            for admin_id in Config.ADMIN_IDS:
                await self.application.bot.send_message(
                    chat_id=admin_id,
                    text="🛑 <b>Bot Sedang Shutdown</b>\n\n"
                         "⏹️ Menghentikan layanan...\n"
                         "💾 Menyimpan data...\n"
                         "🔄 Proses akan dihentikan dalam beberapa detik",
                    parse_mode='HTML'
                )
        except Exception as e:
            logger.error(f"Failed to notify admin about shutdown: {e}")
        
        # Stop scheduler
        if self.scheduler:
            self.scheduler.shutdown()
            logger.info("Scheduler stopped")
        
        # Stop application
        if self.application:
            await self.application.stop()
            logger.info("Application stopped")
        
        sys.exit(0)
    
    async def run(self):
        """Main run method"""
        try:
            # Initialize database
            logger.info("Initializing database...")
            init_database()
            
            # Create application
            logger.info("Setting up bot application...")
            self.application = setup_bot()
            
            # Setup scheduler
            logger.info("Setting up scheduler...")
            self.scheduler = setup_scheduler(self.application)
            
            # Setup signal handlers
            await self.setup_signal_handlers()
            
            # Initialize and start application
            await self.application.initialize()
            await self.application.start()
            
            # Notify admins
            await self.notify_admin_startup()
            
            logger.info("Bot started successfully! Press Ctrl+C to stop.")
            
            # Start polling
            await self.application.updater.start_polling(
                allowed_updates=None,
                drop_pending_updates=True
            )
            
            # Keep running until stopped
            await self.application.updater.idle()
            
        except KeyboardInterrupt:
            logger.info("Received keyboard interrupt")
            await self.shutdown()
        except Exception as e:
            logger.error(f"Critical error in main loop: {e}")
            await self.shutdown()
            raise

def main():
    """Entry point"""
    # Validate environment
    if not Config.BOT_TOKEN:
        logger.error("BOT_TOKEN not found in environment variables")
        sys.exit(1)
    
    if not Config.ADMIN_IDS:
        logger.error("No admin IDs configured")
        sys.exit(1)
    
    # Create storage directory
    os.makedirs('storage', exist_ok=True)
    
    # Run bot
    bot = TelegramDriveSyncBot()
    asyncio.run(bot.run())

if __name__ == '__main__':
    main()
