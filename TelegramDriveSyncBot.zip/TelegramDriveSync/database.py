"""
TelegramDriveSync Bot - Database Operations
Handles all database queries for users, logs, subscriptions, GDrive accounts, and tickets
"""

import sqlite3
import logging
from datetime import datetime, timedelta
from typing import List, Dict, Optional, Tuple
from config import Config
import json

logger = logging.getLogger(__name__)

def get_db_connection():
    """Get database connection with row factory"""
    conn = sqlite3.connect(Config.DATABASE_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_database():
    """Initialize database with all required tables"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        # Users table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY,
                user_id INTEGER UNIQUE NOT NULL,
                username TEXT,
                first_name TEXT,
                last_name TEXT,
                is_paid BOOLEAN DEFAULT FALSE,
                payment_date DATETIME,
                oauth_complete BOOLEAN DEFAULT FALSE,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                last_activity DATETIME DEFAULT CURRENT_TIMESTAMP,
                subscription_expires DATETIME,
                is_active BOOLEAN DEFAULT TRUE
            )
        ''')
        
        # Google Drive accounts table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS gdrive_accounts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                account_email TEXT NOT NULL,
                credentials_json TEXT NOT NULL,
                is_primary BOOLEAN DEFAULT FALSE,
                storage_used INTEGER DEFAULT 0,
                storage_total INTEGER DEFAULT 15000000000,
                is_active BOOLEAN DEFAULT TRUE,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                last_used DATETIME,
                FOREIGN KEY (user_id) REFERENCES users (user_id)
            )
        ''')
        
        # Activity logs table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS activity_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                action TEXT NOT NULL,
                details TEXT,
                file_name TEXT,
                file_size INTEGER,
                gdrive_account_id INTEGER,
                status TEXT DEFAULT 'success',
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users (user_id),
                FOREIGN KEY (gdrive_account_id) REFERENCES gdrive_accounts (id)
            )
        ''')
        
        # Support tickets table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS support_tickets (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ticket_id TEXT UNIQUE NOT NULL,
                user_id INTEGER NOT NULL,
                category TEXT NOT NULL,
                subject TEXT,
                status TEXT DEFAULT 'open',
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                closed_at DATETIME,
                FOREIGN KEY (user_id) REFERENCES users (user_id)
            )
        ''')
        
        # Support messages table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS support_messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ticket_id TEXT NOT NULL,
                sender_id INTEGER NOT NULL,
                sender_type TEXT NOT NULL,
                message_text TEXT,
                message_type TEXT DEFAULT 'text',
                file_id TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (ticket_id) REFERENCES support_tickets (ticket_id)
            )
        ''')
        
        # Authorized groups table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS authorized_groups (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                group_id INTEGER UNIQUE NOT NULL,
                group_title TEXT,
                added_by INTEGER,
                status TEXT DEFAULT 'approved',
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (added_by) REFERENCES users (user_id)
            )
        ''')
        
        # Scheduled tasks table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS scheduled_tasks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                task_type TEXT NOT NULL,
                task_data TEXT NOT NULL,
                scheduled_time DATETIME NOT NULL,
                status TEXT DEFAULT 'pending',
                created_by INTEGER,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                executed_at DATETIME,
                FOREIGN KEY (created_by) REFERENCES users (user_id)
            )
        ''')
        
        # Payment records table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS payment_records (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                payment_id TEXT UNIQUE,
                amount REAL NOT NULL,
                currency TEXT NOT NULL,
                status TEXT NOT NULL,
                provider TEXT DEFAULT 'cryptobot',
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                completed_at DATETIME,
                FOREIGN KEY (user_id) REFERENCES users (user_id)
            )
        ''')
        
        conn.commit()
        logger.info("Database initialized successfully")
        
    except Exception as e:
        logger.error(f"Database initialization error: {e}")
        conn.rollback()
        raise
    finally:
        conn.close()

# User Management Functions

def create_user(user_id: int, username: str = None, first_name: str = None, last_name: str = None) -> bool:
    """Create a new user"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute('''
            INSERT OR IGNORE INTO users (user_id, username, first_name, last_name)
            VALUES (?, ?, ?, ?)
        ''', (user_id, username, first_name, last_name))
        
        success = cursor.rowcount > 0
        conn.commit()
        
        if success:
            logger.info(f"Created new user: {user_id}")
        
        return success
        
    except Exception as e:
        logger.error(f"Error creating user {user_id}: {e}")
        conn.rollback()
        return False
    finally:
        conn.close()

def get_user_by_id(user_id: int) -> Optional[Dict]:
    """Get user by ID"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute('SELECT * FROM users WHERE user_id = ?', (user_id,))
        row = cursor.fetchone()
        return dict(row) if row else None
    except Exception as e:
        logger.error(f"Error getting user {user_id}: {e}")
        return None
    finally:
        conn.close()

def update_user_payment(user_id: int, payment_id: str = None) -> bool:
    """Mark user as paid"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        expire_date = datetime.now() + timedelta(days=Config.SUBSCRIPTION_DURATION_DAYS)
        
        cursor.execute('''
            UPDATE users 
            SET is_paid = TRUE, payment_date = CURRENT_TIMESTAMP, subscription_expires = ?
            WHERE user_id = ?
        ''', (expire_date, user_id))
        
        success = cursor.rowcount > 0
        conn.commit()
        
        if success:
            logger.info(f"Updated payment status for user {user_id}")
        
        return success
        
    except Exception as e:
        logger.error(f"Error updating payment for user {user_id}: {e}")
        conn.rollback()
        return False
    finally:
        conn.close()

def update_user_oauth(user_id: int, oauth_complete: bool = True) -> bool:
    """Update user OAuth status"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute('''
            UPDATE users 
            SET oauth_complete = ?, last_activity = CURRENT_TIMESTAMP
            WHERE user_id = ?
        ''', (oauth_complete, user_id))
        
        success = cursor.rowcount > 0
        conn.commit()
        
        if success:
            logger.info(f"Updated OAuth status for user {user_id}: {oauth_complete}")
        
        return success
        
    except Exception as e:
        logger.error(f"Error updating OAuth for user {user_id}: {e}")
        conn.rollback()
        return False
    finally:
        conn.close()

def is_user_paid(user_id: int) -> bool:
    """Check if user has paid"""
    user = get_user_by_id(user_id)
    if not user:
        return False
    
    # Check if subscription is still valid
    if user['subscription_expires']:
        expire_date = datetime.fromisoformat(user['subscription_expires'])
        return user['is_paid'] and datetime.now() < expire_date
    
    return user['is_paid']

def is_user_oauth_complete(user_id: int) -> bool:
    """Check if user has completed OAuth"""
    user = get_user_by_id(user_id)
    return user['oauth_complete'] if user else False

def get_all_users(limit: int = None, offset: int = 0) -> List[Dict]:
    """Get all users with pagination"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        query = 'SELECT * FROM users ORDER BY created_at DESC'
        params = []
        
        if limit:
            query += ' LIMIT ? OFFSET ?'
            params.extend([limit, offset])
        
        cursor.execute(query, params)
        rows = cursor.fetchall()
        
        return [dict(row) for row in rows]
        
    except Exception as e:
        logger.error(f"Error getting all users: {e}")
        return []
    finally:
        conn.close()

# Google Drive Account Management

def add_gdrive_account(user_id: int, account_email: str, credentials_json: str, is_primary: bool = False) -> int:
    """Add Google Drive account for user"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        # If this is primary, unset other primary accounts
        if is_primary:
            cursor.execute('''
                UPDATE gdrive_accounts 
                SET is_primary = FALSE 
                WHERE user_id = ?
            ''', (user_id,))
        
        cursor.execute('''
            INSERT INTO gdrive_accounts (user_id, account_email, credentials_json, is_primary)
            VALUES (?, ?, ?, ?)
        ''', (user_id, account_email, credentials_json, is_primary))
        
        account_id = cursor.lastrowid
        conn.commit()
        
        logger.info(f"Added GDrive account {account_email} for user {user_id}")
        return account_id
        
    except Exception as e:
        logger.error(f"Error adding GDrive account for user {user_id}: {e}")
        conn.rollback()
        return 0
    finally:
        conn.close()

def get_user_gdrive_accounts(user_id: int, active_only: bool = True) -> List[Dict]:
    """Get user's Google Drive accounts"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        query = 'SELECT * FROM gdrive_accounts WHERE user_id = ?'
        params = [user_id]
        
        if active_only:
            query += ' AND is_active = TRUE'
        
        query += ' ORDER BY is_primary DESC, created_at ASC'
        
        cursor.execute(query, params)
        rows = cursor.fetchall()
        
        return [dict(row) for row in rows]
        
    except Exception as e:
        logger.error(f"Error getting GDrive accounts for user {user_id}: {e}")
        return []
    finally:
        conn.close()

def get_primary_gdrive_account(user_id: int) -> Optional[Dict]:
    """Get user's primary Google Drive account"""
    accounts = get_user_gdrive_accounts(user_id)
    for account in accounts:
        if account['is_primary']:
            return account
    # Return first account if no primary set
    return accounts[0] if accounts else None

def update_gdrive_storage(account_id: int, used: int, total: int = None) -> bool:
    """Update Google Drive storage info"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        if total:
            cursor.execute('''
                UPDATE gdrive_accounts 
                SET storage_used = ?, storage_total = ?, last_used = CURRENT_TIMESTAMP
                WHERE id = ?
            ''', (used, total, account_id))
        else:
            cursor.execute('''
                UPDATE gdrive_accounts 
                SET storage_used = ?, last_used = CURRENT_TIMESTAMP
                WHERE id = ?
            ''', (used, account_id))
        
        success = cursor.rowcount > 0
        conn.commit()
        return success
        
    except Exception as e:
        logger.error(f"Error updating storage for account {account_id}: {e}")
        conn.rollback()
        return False
    finally:
        conn.close()

# Activity Logging

def log_activity(user_id: int, action: str, details: str = None, file_name: str = None, 
                file_size: int = None, gdrive_account_id: int = None, status: str = 'success') -> int:
    """Log user activity"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute('''
            INSERT INTO activity_logs 
            (user_id, action, details, file_name, file_size, gdrive_account_id, status)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ''', (user_id, action, details, file_name, file_size, gdrive_account_id, status))
        
        log_id = cursor.lastrowid
        conn.commit()
        
        return log_id
        
    except Exception as e:
        logger.error(f"Error logging activity for user {user_id}: {e}")
        conn.rollback()
        return 0
    finally:
        conn.close()

def get_user_logs(user_id: int, limit: int = 20, offset: int = 0) -> List[Dict]:
    """Get user activity logs"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute('''
            SELECT al.*, ga.account_email
            FROM activity_logs al
            LEFT JOIN gdrive_accounts ga ON al.gdrive_account_id = ga.id
            WHERE al.user_id = ?
            ORDER BY al.created_at DESC
            LIMIT ? OFFSET ?
        ''', (user_id, limit, offset))
        
        rows = cursor.fetchall()
        return [dict(row) for row in rows]
        
    except Exception as e:
        logger.error(f"Error getting logs for user {user_id}: {e}")
        return []
    finally:
        conn.close()

def get_all_logs(limit: int = 50, offset: int = 0) -> List[Dict]:
    """Get all activity logs (admin only)"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute('''
            SELECT al.*, u.username, u.first_name, ga.account_email
            FROM activity_logs al
            LEFT JOIN users u ON al.user_id = u.user_id
            LEFT JOIN gdrive_accounts ga ON al.gdrive_account_id = ga.id
            ORDER BY al.created_at DESC
            LIMIT ? OFFSET ?
        ''', (limit, offset))
        
        rows = cursor.fetchall()
        return [dict(row) for row in rows]
        
    except Exception as e:
        logger.error(f"Error getting all logs: {e}")
        return []
    finally:
        conn.close()

# Support Ticket System

def create_support_ticket(user_id: int, category: str, subject: str = None) -> str:
    """Create a new support ticket"""
    import uuid
    ticket_id = str(uuid.uuid4())[:8]
    
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute('''
            INSERT INTO support_tickets (ticket_id, user_id, category, subject)
            VALUES (?, ?, ?, ?)
        ''', (ticket_id, user_id, category, subject))
        
        conn.commit()
        logger.info(f"Created support ticket {ticket_id} for user {user_id}")
        
        return ticket_id
        
    except Exception as e:
        logger.error(f"Error creating support ticket for user {user_id}: {e}")
        conn.rollback()
        return ""
    finally:
        conn.close()

def add_support_message(ticket_id: str, sender_id: int, sender_type: str, 
                       message_text: str, message_type: str = 'text', file_id: str = None) -> int:
    """Add message to support ticket"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute('''
            INSERT INTO support_messages 
            (ticket_id, sender_id, sender_type, message_text, message_type, file_id)
            VALUES (?, ?, ?, ?, ?, ?)
        ''', (ticket_id, sender_id, sender_type, message_text, message_type, file_id))
        
        message_id = cursor.lastrowid
        
        # Update ticket timestamp
        cursor.execute('''
            UPDATE support_tickets 
            SET updated_at = CURRENT_TIMESTAMP 
            WHERE ticket_id = ?
        ''', (ticket_id,))
        
        conn.commit()
        return message_id
        
    except Exception as e:
        logger.error(f"Error adding message to ticket {ticket_id}: {e}")
        conn.rollback()
        return 0
    finally:
        conn.close()

def get_user_tickets(user_id: int, limit: int = 10, offset: int = 0) -> List[Dict]:
    """Get user support tickets"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute('''
            SELECT * FROM support_tickets 
            WHERE user_id = ?
            ORDER BY updated_at DESC
            LIMIT ? OFFSET ?
        ''', (user_id, limit, offset))
        
        rows = cursor.fetchall()
        return [dict(row) for row in rows]
        
    except Exception as e:
        logger.error(f"Error getting tickets for user {user_id}: {e}")
        return []
    finally:
        conn.close()

def get_ticket_messages(ticket_id: str) -> List[Dict]:
    """Get all messages for a ticket"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute('''
            SELECT * FROM support_messages 
            WHERE ticket_id = ?
            ORDER BY created_at ASC
        ''', (ticket_id,))
        
        rows = cursor.fetchall()
        return [dict(row) for row in rows]
        
    except Exception as e:
        logger.error(f"Error getting messages for ticket {ticket_id}: {e}")
        return []
    finally:
        conn.close()

# Group Management

def add_authorized_group(group_id: int, group_title: str, added_by: int) -> bool:
    """Add authorized group"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute('''
            INSERT OR REPLACE INTO authorized_groups (group_id, group_title, added_by)
            VALUES (?, ?, ?)
        ''', (group_id, group_title, added_by))
        
        success = cursor.rowcount > 0
        conn.commit()
        
        if success:
            Config.add_authorized_group(group_id)
            logger.info(f"Added authorized group {group_id}")
        
        return success
        
    except Exception as e:
        logger.error(f"Error adding authorized group {group_id}: {e}")
        conn.rollback()
        return False
    finally:
        conn.close()

def get_authorized_groups() -> List[Dict]:
    """Get all authorized groups"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute('SELECT * FROM authorized_groups ORDER BY created_at DESC')
        rows = cursor.fetchall()
        return [dict(row) for row in rows]
        
    except Exception as e:
        logger.error(f"Error getting authorized groups: {e}")
        return []
    finally:
        conn.close()

# Payment Records

def create_payment_record(user_id: int, payment_id: str, amount: float, currency: str) -> int:
    """Create payment record"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute('''
            INSERT INTO payment_records (user_id, payment_id, amount, currency, status)
            VALUES (?, ?, ?, ?, 'pending')
        ''', (user_id, payment_id, amount, currency))
        
        record_id = cursor.lastrowid
        conn.commit()
        
        return record_id
        
    except Exception as e:
        logger.error(f"Error creating payment record for user {user_id}: {e}")
        conn.rollback()
        return 0
    finally:
        conn.close()

def update_payment_status(payment_id: str, status: str) -> bool:
    """Update payment status"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute('''
            UPDATE payment_records 
            SET status = ?, completed_at = CURRENT_TIMESTAMP
            WHERE payment_id = ?
        ''', (status, payment_id))
        
        success = cursor.rowcount > 0
        conn.commit()
        
        return success
        
    except Exception as e:
        logger.error(f"Error updating payment status for {payment_id}: {e}")
        conn.rollback()
        return False
    finally:
        conn.close()

# Cleanup Functions

def cleanup_old_logs(days: int = 90) -> int:
    """Clean up old activity logs"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cutoff_date = datetime.now() - timedelta(days=days)
        
        cursor.execute('''
            DELETE FROM activity_logs 
            WHERE created_at < ?
        ''', (cutoff_date,))
        
        deleted_count = cursor.rowcount
        conn.commit()
        
        logger.info(f"Cleaned up {deleted_count} old log entries")
        return deleted_count
        
    except Exception as e:
        logger.error(f"Error cleaning up old logs: {e}")
        conn.rollback()
        return 0
    finally:
        conn.close()

def get_database_stats() -> Dict:
    """Get database statistics"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        stats = {}
        
        # Count users
        cursor.execute('SELECT COUNT(*) as total, COUNT(CASE WHEN is_paid THEN 1 END) as paid FROM users')
        user_stats = cursor.fetchone()
        stats['users'] = {'total': user_stats['total'], 'paid': user_stats['paid']}
        
        # Count GDrive accounts
        cursor.execute('SELECT COUNT(*) as total FROM gdrive_accounts WHERE is_active = TRUE')
        stats['gdrive_accounts'] = cursor.fetchone()['total']
        
        # Count logs
        cursor.execute('SELECT COUNT(*) as total FROM activity_logs')
        stats['activity_logs'] = cursor.fetchone()['total']
        
        # Count tickets
        cursor.execute('SELECT COUNT(*) as total, COUNT(CASE WHEN status = "open" THEN 1 END) as open FROM support_tickets')
        ticket_stats = cursor.fetchone()
        stats['support_tickets'] = {'total': ticket_stats['total'], 'open': ticket_stats['open']}
        
        return stats
        
    except Exception as e:
        logger.error(f"Error getting database stats: {e}")
        return {}
    finally:
        conn.close()
