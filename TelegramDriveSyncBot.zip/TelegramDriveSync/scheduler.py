"""
TelegramDriveSync Bot - Task Scheduler
Handles scheduled backups, broadcasts, reminders, and auto-cleanup
"""

import logging
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.cron import CronTrigger
from apscheduler.triggers.interval import IntervalTrigger
from datetime import datetime, timedelta
from database import cleanup_old_logs, get_database_stats, get_all_users
from config import Config
import asyncio

logger = logging.getLogger(__name__)

class BotScheduler:
    def __init__(self, application):
        self.application = application
        self.scheduler = AsyncIOScheduler()
        self.setup_jobs()
    
    def setup_jobs(self):
        """Setup all scheduled jobs"""
        # Daily cleanup at 2 AM
        self.scheduler.add_job(
            func=self.daily_cleanup,
            trigger=CronTrigger(hour=2, minute=0),
            id='daily_cleanup',
            name='Daily Cleanup',
            replace_existing=True
        )
        
        # Weekly backup notification every Sunday at 12 PM
        self.scheduler.add_job(
            func=self.weekly_backup_reminder,
            trigger=CronTrigger(day_of_week=6, hour=12, minute=0),
            id='weekly_backup',
            name='Weekly Backup Reminder',
            replace_existing=True
        )
        
        # Database stats every 6 hours
        self.scheduler.add_job(
            func=self.send_database_stats,
            trigger=IntervalTrigger(hours=6),
            id='database_stats',
            name='Database Statistics',
            replace_existing=True
        )
        
        # Health check every hour
        self.scheduler.add_job(
            func=self.health_check,
            trigger=IntervalTrigger(hours=1),
            id='health_check',
            name='Health Check',
            replace_existing=True
        )
        
        # Process scheduled broadcasts every minute
        self.scheduler.add_job(
            func=self.process_scheduled_broadcasts,
            trigger=IntervalTrigger(minutes=1),
            id='scheduled_broadcasts',
            name='Process Scheduled Broadcasts',
            replace_existing=True
        )
        
        logger.info("Scheduler jobs configured successfully")
    
    async def daily_cleanup(self):
        """Daily cleanup tasks"""
        try:
            logger.info("Starting daily cleanup...")
            
            # Clean old logs
            deleted_logs = cleanup_old_logs(Config.LOG_RETENTION_DAYS)
            
            # Clean old temporary files
            import os
            import glob
            temp_files = glob.glob(f"{Config.STORAGE_PATH}/*")
            cleaned_files = 0
            
            for file_path in temp_files:
                try:
                    file_age = datetime.now() - datetime.fromtimestamp(os.path.getctime(file_path))
                    if file_age.days > Config.AUTO_CLEANUP_DAYS:
                        os.remove(file_path)
                        cleaned_files += 1
                except Exception as e:
                    logger.error(f"Error cleaning file {file_path}: {e}")
            
            # Notify admins
            cleanup_message = (
                f"🧹 <b>Daily Cleanup Completed</b>\n\n"
                f"📝 Log entries deleted: {deleted_logs}\n"
                f"📁 Temp files cleaned: {cleaned_files}\n"
                f"⏰ Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
            )
            
            for admin_id in Config.ADMIN_IDS:
                try:
                    await self.application.bot.send_message(
                        chat_id=admin_id,
                        text=cleanup_message,
                        parse_mode='HTML'
                    )
                except Exception as e:
                    logger.error(f"Failed to notify admin {admin_id} about cleanup: {e}")
            
            logger.info(f"Daily cleanup completed: {deleted_logs} logs, {cleaned_files} files")
            
        except Exception as e:
            logger.error(f"Error in daily cleanup: {e}")
    
    async def weekly_backup_reminder(self):
        """Weekly backup reminder for admins"""
        try:
            stats = get_database_stats()
            
            backup_message = (
                f"💾 <b>Weekly Backup Reminder</b>\n\n"
                f"👥 Total Users: {stats.get('users', {}).get('total', 0)}\n"
                f"💳 Paid Users: {stats.get('users', {}).get('paid', 0)}\n"
                f"📁 GDrive Accounts: {stats.get('gdrive_accounts', 0)}\n"
                f"📝 Activity Logs: {stats.get('activity_logs', 0)}\n"
                f"🎫 Support Tickets: {stats.get('support_tickets', {}).get('total', 0)}\n\n"
                f"🗓️ Please ensure database backups are up to date!"
            )
            
            for admin_id in Config.ADMIN_IDS:
                try:
                    await self.application.bot.send_message(
                        chat_id=admin_id,
                        text=backup_message,
                        parse_mode='HTML'
                    )
                except Exception as e:
                    logger.error(f"Failed to send backup reminder to admin {admin_id}: {e}")
        
        except Exception as e:
            logger.error(f"Error in weekly backup reminder: {e}")
    
    async def send_database_stats(self):
        """Send database statistics to admins"""
        try:
            stats = get_database_stats()
            
            stats_message = (
                f"📊 <b>Database Statistics</b>\n\n"
                f"👥 Users: {stats.get('users', {}).get('total', 0)} "
                f"({stats.get('users', {}).get('paid', 0)} paid)\n"
                f"📁 GDrive Accounts: {stats.get('gdrive_accounts', 0)}\n"
                f"📝 Activity Logs: {stats.get('activity_logs', 0)}\n"
                f"🎫 Support Tickets: {stats.get('support_tickets', {}).get('total', 0)} "
                f"({stats.get('support_tickets', {}).get('open', 0)} open)\n\n"
                f"⏰ {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
            )
            
            for admin_id in Config.ADMIN_IDS[:1]:  # Send to first admin only
                try:
                    await self.application.bot.send_message(
                        chat_id=admin_id,
                        text=stats_message,
                        parse_mode='HTML'
                    )
                except Exception as e:
                    logger.error(f"Failed to send stats to admin {admin_id}: {e}")
        
        except Exception as e:
            logger.error(f"Error sending database stats: {e}")
    
    async def health_check(self):
        """Perform health check and notify if issues found"""
        try:
            # Check bot connectivity
            bot_info = await self.application.bot.get_me()
            
            # Check database connectivity
            stats = get_database_stats()
            
            # Check for stuck processes or high error rates
            # This is a simplified health check
            
            logger.info(f"Health check passed - Bot: {bot_info.username}, DB Stats: {stats}")
            
        except Exception as e:
            logger.error(f"Health check failed: {e}")
            
            # Notify admins of health issues
            health_alert = (
                f"🚨 <b>Health Check Alert</b>\n\n"
                f"❌ Issue detected: {str(e)}\n"
                f"⏰ Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n"
                f"Please check bot status immediately!"
            )
            
            for admin_id in Config.ADMIN_IDS:
                try:
                    await self.application.bot.send_message(
                        chat_id=admin_id,
                        text=health_alert,
                        parse_mode='HTML'
                    )
                except:
                    pass  # If we can't send alerts, log the error
    
    async def process_scheduled_broadcasts(self):
        """Process any scheduled broadcasts"""
        try:
            from database import get_db_connection
            
            conn = get_db_connection()
            cursor = conn.cursor()
            
            # Get pending scheduled tasks
            cursor.execute('''
                SELECT * FROM scheduled_tasks 
                WHERE status = 'pending' AND scheduled_time <= ?
                ORDER BY scheduled_time ASC
                LIMIT 10
            ''', (datetime.now(),))
            
            tasks = cursor.fetchall()
            
            for task in tasks:
                try:
                    await self.execute_scheduled_task(dict(task))
                    
                    # Mark as completed
                    cursor.execute('''
                        UPDATE scheduled_tasks 
                        SET status = 'completed', executed_at = CURRENT_TIMESTAMP
                        WHERE id = ?
                    ''', (task['id'],))
                    
                except Exception as e:
                    logger.error(f"Error executing scheduled task {task['id']}: {e}")
                    
                    # Mark as failed
                    cursor.execute('''
                        UPDATE scheduled_tasks 
                        SET status = 'failed', executed_at = CURRENT_TIMESTAMP
                        WHERE id = ?
                    ''', (task['id'],))
            
            conn.commit()
            conn.close()
            
        except Exception as e:
            logger.error(f"Error processing scheduled broadcasts: {e}")
    
    async def execute_scheduled_task(self, task):
        """Execute a specific scheduled task"""
        import json
        
        task_type = task['task_type']
        task_data = json.loads(task['task_data'])
        
        if task_type == 'broadcast_message':
            await self.execute_broadcast(task_data)
        elif task_type == 'share_to_group':
            await self.execute_group_share(task_data)
        elif task_type == 'cleanup_reminder':
            await self.execute_cleanup_reminder(task_data)
        else:
            logger.warning(f"Unknown task type: {task_type}")
    
    async def execute_broadcast(self, data):
        """Execute broadcast message"""
        message = data.get('message', '')
        target_users = data.get('target_users', [])
        
        if not target_users:
            # Broadcast to all paid users
            users = get_all_users()
            target_users = [u['user_id'] for u in users if u['is_paid']]
        
        success_count = 0
        fail_count = 0
        
        for user_id in target_users:
            try:
                await self.application.bot.send_message(
                    chat_id=user_id,
                    text=message,
                    parse_mode='HTML'
                )
                success_count += 1
                
                # Add delay to avoid rate limiting
                await asyncio.sleep(1)
                
            except Exception as e:
                logger.error(f"Failed to broadcast to user {user_id}: {e}")
                fail_count += 1
        
        # Notify admin about broadcast results
        result_message = (
            f"📢 <b>Broadcast Completed</b>\n\n"
            f"✅ Successful: {success_count}\n"
            f"❌ Failed: {fail_count}\n"
            f"⏰ Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
        )
        
        for admin_id in Config.ADMIN_IDS[:1]:
            try:
                await self.application.bot.send_message(
                    chat_id=admin_id,
                    text=result_message,
                    parse_mode='HTML'
                )
            except:
                pass
    
    async def execute_group_share(self, data):
        """Execute scheduled group share"""
        group_id = data.get('group_id')
        message = data.get('message', '')
        file_id = data.get('file_id')
        
        try:
            if file_id:
                await self.application.bot.send_document(
                    chat_id=group_id,
                    document=file_id,
                    caption=message,
                    parse_mode='HTML'
                )
            else:
                await self.application.bot.send_message(
                    chat_id=group_id,
                    text=message,
                    parse_mode='HTML'
                )
            
            logger.info(f"Scheduled share to group {group_id} completed")
            
        except Exception as e:
            logger.error(f"Failed to share to group {group_id}: {e}")
    
    async def execute_cleanup_reminder(self, data):
        """Execute cleanup reminder"""
        await self.daily_cleanup()
    
    def start(self):
        """Start the scheduler"""
        self.scheduler.start()
        logger.info("Scheduler started successfully")
    
    def shutdown(self):
        """Shutdown the scheduler"""
        self.scheduler.shutdown()
        logger.info("Scheduler shutdown completed")
    
    def add_scheduled_broadcast(self, message: str, scheduled_time: datetime, 
                              target_users: list = None, created_by: int = None):
        """Add a scheduled broadcast"""
        import json
        from database import get_db_connection
        
        task_data = {
            'message': message,
            'target_users': target_users or []
        }
        
        conn = get_db_connection()
        cursor = conn.cursor()
        
        try:
            cursor.execute('''
                INSERT INTO scheduled_tasks (task_type, task_data, scheduled_time, created_by)
                VALUES (?, ?, ?, ?)
            ''', ('broadcast_message', json.dumps(task_data), scheduled_time, created_by))
            
            task_id = cursor.lastrowid
            conn.commit()
            
            logger.info(f"Added scheduled broadcast task {task_id}")
            return task_id
            
        except Exception as e:
            logger.error(f"Error adding scheduled broadcast: {e}")
            conn.rollback()
            return 0
        finally:
            conn.close()
    
    def add_scheduled_group_share(self, group_id: int, message: str, 
                                scheduled_time: datetime, file_id: str = None, created_by: int = None):
        """Add a scheduled group share"""
        import json
        from database import get_db_connection
        
        task_data = {
            'group_id': group_id,
            'message': message,
            'file_id': file_id
        }
        
        conn = get_db_connection()
        cursor = conn.cursor()
        
        try:
            cursor.execute('''
                INSERT INTO scheduled_tasks (task_type, task_data, scheduled_time, created_by)
                VALUES (?, ?, ?, ?)
            ''', ('share_to_group', json.dumps(task_data), scheduled_time, created_by))
            
            task_id = cursor.lastrowid
            conn.commit()
            
            logger.info(f"Added scheduled group share task {task_id}")
            return task_id
            
        except Exception as e:
            logger.error(f"Error adding scheduled group share: {e}")
            conn.rollback()
            return 0
        finally:
            conn.close()

def setup_scheduler(application):
    """Setup and return scheduler instance"""
    scheduler = BotScheduler(application)
    scheduler.start()
    return scheduler
