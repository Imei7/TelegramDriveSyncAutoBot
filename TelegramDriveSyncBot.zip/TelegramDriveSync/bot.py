"""
TelegramDriveSync Bot - Main Bot Setup and Routing
Handles command routing, user status checking, and handler integration
"""

import logging
from telegram import Update
from telegram.ext import (
    Application, CommandHandler, MessageHandler, CallbackQueryHandler,
    ConversationHandler, filters, ContextTypes
)
from config import Config
from database import get_user_by_id, is_user_paid, is_user_oauth_complete
from handlers import (
    admin_handler, user_handler, gdrive_handler, upload_handler,
    log_handler, oauth_handler, payment_handler, twitter_scraper,
    share_to_group_handler, contact_admin_handler
)

logger = logging.getLogger(__name__)

async def error_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle errors and notify admins"""
    logger.error(f"Exception while handling an update: {context.error}")
    
    # Prepare error message for admins
    error_msg = (
        f"🚨 <b>Bot Error Detected!</b>\n\n"
        f"<b>Error:</b> <code>{str(context.error)}</code>\n"
        f"<b>User ID:</b> {update.effective_user.id if update.effective_user else 'Unknown'}\n"
        f"<b>Chat ID:</b> {update.effective_chat.id if update.effective_chat else 'Unknown'}\n"
        f"<b>Message:</b> {update.message.text if update.message and update.message.text else 'No text'}\n"
    )
    
    # Notify all admins
    for admin_id in Config.ADMIN_IDS:
        try:
            await context.bot.send_message(
                chat_id=admin_id,
                text=error_msg,
                parse_mode='HTML'
            )
        except Exception as e:
            logger.error(f"Failed to notify admin {admin_id} about error: {e}")

async def check_user_access(update: Update, context: ContextTypes.DEFAULT_TYPE, require_payment=True, require_oauth=True):
    """Check user access levels and redirect if needed"""
    user_id = update.effective_user.id
    
    # Always allow admin access
    if user_id in Config.ADMIN_IDS:
        return True
    
    # Check if user exists in database
    user = get_user_by_id(user_id)
    if not user:
        # New user, redirect to start
        await update.message.reply_text(
            "👋 Selamat datang! Silakan gunakan /start untuk memulai.",
            reply_markup=None
        )
        return False
    
    # Check payment status
    if require_payment and not is_user_paid(user_id):
        await update.message.reply_text(
            "💳 <b>Akses Terbatas</b>\n\n"
            "Anda perlu berlangganan untuk menggunakan fitur ini.\n"
            "Gunakan /start untuk melakukan pembayaran.",
            parse_mode='HTML'
        )
        return False
    
    # Check OAuth status
    if require_oauth and not is_user_oauth_complete(user_id):
        await update.message.reply_text(
            "🔐 <b>OAuth Required</b>\n\n"
            "Anda perlu menghubungkan akun Google Drive terlebih dahulu.\n"
            "Gunakan menu utama untuk melakukan OAuth.",
            parse_mode='HTML'
        )
        return False
    
    return True

async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle /start command"""
    await user_handler.handle_start(update, context)

async def menu_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle /menu command"""
    if await check_user_access(update, context, require_payment=False, require_oauth=False):
        await user_handler.show_main_menu(update, context)

async def admin_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle /admin command"""
    user_id = update.effective_user.id
    if user_id not in Config.ADMIN_IDS:
        await update.message.reply_text("❌ Akses ditolak. Anda bukan admin.")
        return
    
    await admin_handler.show_admin_panel(update, context)

async def text_message_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle text messages based on context"""
    text = update.message.text
    user_id = update.effective_user.id
    
    # Admin messages
    if user_id in Config.ADMIN_IDS:
        await admin_handler.handle_text_message(update, context)
        return
    
    # User messages - route based on current state/menu
    current_state = context.user_data.get('current_state', 'main_menu')
    
    if current_state == 'awaiting_contact_message':
        await contact_admin_handler.handle_user_message(update, context)
    elif current_state == 'uploading_files':
        await upload_handler.handle_file_upload(update, context)
    elif current_state == 'twitter_scraping':
        await twitter_scraper.handle_username_input(update, context)
    else:
        # Default to main menu handling
        await user_handler.handle_text_message(update, context)

async def callback_query_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle callback queries from inline keyboards"""
    query = update.callback_query
    data = query.data
    user_id = update.effective_user.id
    
    await query.answer()  # Acknowledge the callback
    
    # Admin callbacks
    if user_id in Config.ADMIN_IDS and data.startswith('admin_'):
        await admin_handler.handle_callback(update, context)
        return
    
    # Payment callbacks
    if data.startswith('payment_'):
        await payment_handler.handle_callback(update, context)
        return
    
    # OAuth callbacks
    if data.startswith('oauth_'):
        await oauth_handler.handle_callback(update, context)
        return
    
    # Upload callbacks
    if data.startswith('upload_'):
        await upload_handler.handle_callback(update, context)
        return
    
    # GDrive callbacks
    if data.startswith('gdrive_'):
        await gdrive_handler.handle_callback(update, context)
        return
    
    # Log callbacks
    if data.startswith('log_'):
        await log_handler.handle_callback(update, context)
        return
    
    # Twitter scraper callbacks
    if data.startswith('twitter_'):
        await twitter_scraper.handle_callback(update, context)
        return
    
    # Share to group callbacks
    if data.startswith('share_'):
        await share_to_group_handler.handle_callback(update, context)
        return
    
    # Contact admin callbacks
    if data.startswith('contact_'):
        await contact_admin_handler.handle_callback(update, context)
        return
    
    # User menu callbacks
    await user_handler.handle_callback(update, context)

async def document_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle document uploads"""
    if await check_user_access(update, context):
        await upload_handler.handle_document_upload(update, context)

async def photo_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle photo uploads"""
    if await check_user_access(update, context):
        await upload_handler.handle_photo_upload(update, context)

async def video_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle video uploads"""
    if await check_user_access(update, context):
        await upload_handler.handle_video_upload(update, context)

def setup_bot():
    """Setup and configure the bot application"""
    # Create application
    application = Application.builder().token(Config.BOT_TOKEN).build()
    
    # Add error handler
    application.add_error_handler(error_handler)
    
    # Add command handlers
    application.add_handler(CommandHandler("start", start_command))
    application.add_handler(CommandHandler("menu", menu_command))
    application.add_handler(CommandHandler("admin", admin_command))
    
    # Add conversation handlers for complex flows
    payment_conv_handler = payment_handler.get_conversation_handler()
    if payment_conv_handler:
        application.add_handler(payment_conv_handler)
    
    oauth_conv_handler = oauth_handler.get_conversation_handler()
    if oauth_conv_handler:
        application.add_handler(oauth_conv_handler)
    
    contact_conv_handler = contact_admin_handler.get_conversation_handler()
    if contact_conv_handler:
        application.add_handler(contact_conv_handler)
    
    # Add callback query handler
    application.add_handler(CallbackQueryHandler(callback_query_handler))
    
    # Add file handlers
    application.add_handler(MessageHandler(filters.Document.ALL, document_handler))
    application.add_handler(MessageHandler(filters.PHOTO, photo_handler))
    application.add_handler(MessageHandler(filters.VIDEO, video_handler))
    
    # Add text message handler (should be last)
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, text_message_handler))
    
    logger.info("Bot setup completed successfully")
    return application
