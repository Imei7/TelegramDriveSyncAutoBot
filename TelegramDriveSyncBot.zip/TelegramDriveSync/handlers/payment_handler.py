"""
TelegramDriveSync Bot - Payment Handler
Integrasi pembayaran CryptoBot
"""

import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes, ConversationHandler, MessageHandler, filters
from database import create_payment_record, update_payment_status, update_user_payment, log_activity
from config import Config
import requests
import json
import hashlib
import time

logger = logging.getLogger(__name__)

# Payment conversation states
PAYMENT_CONFIRM, PAYMENT_WAITING = range(2)

class CryptoBotAPI:
    def __init__(self, token: str):
        self.token = token
        self.base_url = "https://pay.crypt.bot/api"
        self.headers = {
            'Crypto-Pay-API-Token': token,
            'Content-Type': 'application/json'
        }
    
    def create_invoice(self, amount: float, currency: str = "USD", description: str = "", payload: str = ""):
        """Create payment invoice"""
        try:
            data = {
                "amount": amount,
                "currency_type": "fiat",
                "fiat": currency,
                "description": description,
                "payload": payload,
                "allow_comments": False,
                "allow_anonymous": False
            }
            
            # For demo purposes, return simulated response
            # In real implementation, make actual API call
            invoice_id = f"inv_{int(time.time())}_{hash(payload) % 10000}"
            
            return {
                "ok": True,
                "result": {
                    "invoice_id": invoice_id,
                    "status": "active",
                    "hash": hashlib.md5(f"{invoice_id}{amount}".encode()).hexdigest()[:8],
                    "currency_type": "fiat",
                    "fiat": currency,
                    "amount": str(amount),
                    "description": description,
                    "payload": payload,
                    "bot_invoice_url": f"https://t.me/CryptoBot?start=pay_{invoice_id}",
                    "web_app_invoice_url": f"https://pay.crypt.bot/{invoice_id}",
                    "created_at": int(time.time()),
                    "allow_comments": False,
                    "allow_anonymous": False
                }
            }
            
        except Exception as e:
            logger.error(f"Error creating CryptoBot invoice: {e}")
            return {"ok": False, "error": str(e)}
    
    def get_invoice(self, invoice_id: str):
        """Get invoice status"""
        try:
            # For demo purposes, return simulated paid status after some time
            # In real implementation, make actual API call
            return {
                "ok": True,
                "result": {
                    "invoice_id": invoice_id,
                    "status": "paid",  # Simulated as paid
                    "hash": hashlib.md5(f"{invoice_id}".encode()).hexdigest()[:8],
                    "currency_type": "fiat",
                    "fiat": "USD",
                    "amount": str(Config.SUBSCRIPTION_PRICE_USD),
                    "paid_at": int(time.time()),
                    "paid_usd_rate": "1.0"
                }
            }
            
        except Exception as e:
            logger.error(f"Error getting CryptoBot invoice: {e}")
            return {"ok": False, "error": str(e)}
    
    def get_me(self):
        """Get bot info"""
        try:
            # For demo purposes, return simulated bot info
            return {
                "ok": True,
                "result": {
                    "app_id": 416708,
                    "name": "TelegramDriveSync",
                    "payment_processing_bot_username": "CryptoBot"
                }
            }
        except Exception as e:
            logger.error(f"Error getting CryptoBot info: {e}")
            return {"ok": False, "error": str(e)}

# Initialize CryptoBot API
crypto_api = CryptoBotAPI(Config.CRYPTOBOT_API_TOKEN)

async def start_payment_process(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Start payment process"""
    user_id = update.effective_user.id
    
    # Check if user already paid
    from database import is_user_paid
    if is_user_paid(user_id):
        await update.message.reply_text(
            "✅ <b>Anda sudah berlangganan!</b>\n\n"
            "Status: Premium Active\n"
            "Semua fitur sudah tersedia.\n\n"
            "Gunakan /menu untuk mengakses fitur.",
            parse_mode='HTML',
            reply_markup=InlineKeyboardMarkup([[
                InlineKeyboardButton("🏠 Main Menu", callback_data="show_main_menu")
            ]])
        )
        return ConversationHandler.END
    
    payment_message = (
        f"💳 <b>Berlangganan Premium</b>\n\n"
        f"🚀 <b>Fitur Premium:</b>\n"
        f"📤 Upload unlimited ke Google Drive\n"
        f"🔗 Twitter scraping dengan media download\n"
        f"📁 Multi-akun Google Drive\n"
        f"📽️ Video streaming langsung\n"
        f"📊 Log aktivitas lengkap\n"
        f"💬 Priority support dari admin\n\n"
        f"💰 <b>Harga:</b> ${Config.SUBSCRIPTION_PRICE_USD} USD\n"
        f"⏰ <b>Durasi:</b> Selamanya (sekali bayar)\n"
        f"🔒 <b>Anti Double Payment:</b> Sekali bayar, akses selamanya\n\n"
        f"💳 <b>Payment Method:</b>\n"
        f"🤖 CryptoBot (Crypto + Fiat)\n"
        f"💎 Bitcoin, Ethereum, USDT, dll\n"
        f"💳 Card payment tersedia\n\n"
        f"🛡️ <b>Keamanan:</b>\n"
        f"✅ Payment secure via CryptoBot\n"
        f"✅ Instant activation\n"
        f"✅ No recurring charges\n"
        f"✅ Refund available (24 jam)"
    )
    
    keyboard = [
        [InlineKeyboardButton("💳 Bayar Sekarang", callback_data="payment_create")],
        [InlineKeyboardButton("❓ Payment Info", callback_data="payment_info")],
        [InlineKeyboardButton("📞 Contact Support", callback_data="contact_admin_payment")],
        [InlineKeyboardButton("🔙 Back", callback_data="show_main_menu")]
    ]
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    if update.callback_query:
        await update.callback_query.edit_message_text(
            payment_message,
            parse_mode='HTML',
            reply_markup=reply_markup
        )
    else:
        await update.message.reply_text(
            payment_message,
            parse_mode='HTML',
            reply_markup=reply_markup
        )
    
    return PAYMENT_CONFIRM

async def create_payment_invoice(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Create payment invoice via CryptoBot"""
    user_id = update.effective_user.id
    
    await update.callback_query.answer("Creating payment invoice...")
    
    # Prepare invoice data
    amount = Config.SUBSCRIPTION_PRICE_USD
    description = f"TelegramDriveSync Premium Subscription - User {user_id}"
    payload = f"subscription_{user_id}_{int(time.time())}"
    
    try:
        # Create invoice
        invoice_response = crypto_api.create_invoice(
            amount=amount,
            currency="USD",
            description=description,
            payload=payload
        )
        
        if not invoice_response.get("ok"):
            raise Exception(invoice_response.get("error", "Unknown error"))
        
        invoice_data = invoice_response["result"]
        invoice_id = invoice_data["invoice_id"]
        
        # Store payment record in database
        record_id = create_payment_record(
            user_id=user_id,
            payment_id=invoice_id,
            amount=amount,
            currency="USD"
        )
        
        if not record_id:
            raise Exception("Failed to create payment record")
        
        # Store invoice data in context for tracking
        context.user_data['payment_invoice_id'] = invoice_id
        context.user_data['payment_amount'] = amount
        
        # Create payment message
        payment_message = (
            f"💳 <b>Payment Invoice Created</b>\n\n"
            f"💰 Amount: ${amount} USD\n"
            f"📝 Description: Premium Subscription\n"
            f"🆔 Invoice ID: <code>{invoice_id}</code>\n\n"
            f"🔔 <b>Payment Instructions:</b>\n"
            f"1️⃣ Click 'Pay Now' button below\n"
            f"2️⃣ Complete payment in CryptoBot\n"
            f"3️⃣ Return here after payment\n"
            f"4️⃣ Click 'Check Payment' to verify\n\n"
            f"⏰ <b>Invoice valid for:</b> 24 hours\n"
            f"🔄 <b>Auto-check:</b> Every 30 seconds\n\n"
            f"💡 <b>Payment Options in CryptoBot:</b>\n"
            f"💎 Crypto: BTC, ETH, USDT, TON, etc.\n"
            f"💳 Fiat: Card payments\n"
            f"⚡ Lightning Network (BTC)\n\n"
            f"❓ Need help? Use 'Contact Support' button."
        )
        
        keyboard = [
            [InlineKeyboardButton("💳 Pay Now", url=invoice_data["bot_invoice_url"])],
            [InlineKeyboardButton("🔍 Check Payment", callback_data=f"payment_check_{invoice_id}")],
            [InlineKeyboardButton("🌐 Open Web Payment", url=invoice_data.get("web_app_invoice_url", invoice_data["bot_invoice_url"]))],
            [
                InlineKeyboardButton("💬 Support", callback_data="contact_admin_payment"),
                InlineKeyboardButton("❌ Cancel", callback_data="payment_cancel")
            ]
        ]
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await update.callback_query.edit_message_text(
            payment_message,
            parse_mode='HTML',
            reply_markup=reply_markup
        )
        
        # Log payment creation
        log_activity(
            user_id=user_id,
            action="payment_created",
            details=f"Created payment invoice: ${amount} USD"
        )
        
        # Start auto-check process
        context.job_queue.run_repeating(
            callback=auto_check_payment,
            interval=30,  # Check every 30 seconds
            first=30,
            context={
                'user_id': user_id,
                'invoice_id': invoice_id,
                'chat_id': update.effective_chat.id,
                'message_id': update.callback_query.message.message_id
            },
            name=f"payment_check_{user_id}_{invoice_id}"
        )
        
        return PAYMENT_WAITING
        
    except Exception as e:
        logger.error(f"Error creating payment invoice for user {user_id}: {e}")
        
        error_message = (
            f"❌ <b>Payment Creation Failed</b>\n\n"
            f"Error: {str(e)}\n\n"
            f"🔄 <b>Please try again or:</b>\n"
            f"• Check your internet connection\n"
            f"• Wait a moment and retry\n"
            f"• Contact support if issue persists"
        )
        
        keyboard = [
            [InlineKeyboardButton("🔄 Try Again", callback_data="payment_create")],
            [InlineKeyboardButton("💬 Contact Support", callback_data="contact_admin_payment")],
            [InlineKeyboardButton("🔙 Back", callback_data="show_main_menu")]
        ]
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await update.callback_query.edit_message_text(
            error_message,
            parse_mode='HTML',
            reply_markup=reply_markup
        )
        
        return ConversationHandler.END

async def check_payment_status(update: Update, context: ContextTypes.DEFAULT_TYPE, invoice_id: str):
    """Check payment status"""
    user_id = update.effective_user.id
    
    await update.callback_query.answer("Checking payment status...")
    
    try:
        # Get invoice status from CryptoBot
        invoice_response = crypto_api.get_invoice(invoice_id)
        
        if not invoice_response.get("ok"):
            raise Exception(invoice_response.get("error", "Unknown error"))
        
        invoice_data = invoice_response["result"]
        status = invoice_data.get("status", "active")
        
        if status == "paid":
            # Payment successful!
            await process_successful_payment(update, context, invoice_id, invoice_data)
        elif status == "expired":
            # Payment expired
            await handle_expired_payment(update, context, invoice_id)
        else:
            # Payment still pending
            await handle_pending_payment(update, context, invoice_id, status)
    
    except Exception as e:
        logger.error(f"Error checking payment status for {invoice_id}: {e}")
        await update.callback_query.answer(f"❌ Error checking payment: {str(e)}")

async def process_successful_payment(update: Update, context: ContextTypes.DEFAULT_TYPE, 
                                   invoice_id: str, invoice_data: dict):
    """Process successful payment"""
    user_id = update.effective_user.id
    
    try:
        # Update payment status in database
        update_payment_status(invoice_id, "paid")
        
        # Update user payment status
        update_user_payment(user_id, invoice_id)
        
        # Stop auto-check job
        current_jobs = context.job_queue.get_jobs_by_name(f"payment_check_{user_id}_{invoice_id}")
        for job in current_jobs:
            job.schedule_removal()
        
        # Log successful payment
        log_activity(
            user_id=user_id,
            action="payment_success",
            details=f"Premium subscription activated - Invoice: {invoice_id}"
        )
        
        # Send success message
        success_message = (
            f"🎉 <b>Payment Successful!</b>\n\n"
            f"✅ Premium subscription activated\n"
            f"💰 Amount: ${invoice_data.get('amount', Config.SUBSCRIPTION_PRICE_USD)} USD\n"
            f"📅 Activated: {time.strftime('%Y-%m-%d %H:%M:%S')}\n"
            f"⏰ Duration: Lifetime access\n\n"
            f"🚀 <b>What's Next?</b>\n"
            f"1️⃣ Connect your Google Drive account\n"
            f"2️⃣ Start uploading files\n"
            f"3️⃣ Use Twitter scraping features\n"
            f"4️⃣ Enjoy all premium features!\n\n"
            f"🎯 Ready to get started?"
        )
        
        keyboard = [
            [InlineKeyboardButton("🔐 Connect Google Drive", callback_data="oauth_start")],
            [InlineKeyboardButton("📤 Upload Files", callback_data="upload_menu")],
            [InlineKeyboardButton("🔗 Scrape Twitter", callback_data="twitter_menu")],
            [InlineKeyboardButton("🏠 Main Menu", callback_data="show_main_menu")]
        ]
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await update.callback_query.edit_message_text(
            success_message,
            parse_mode='HTML',
            reply_markup=reply_markup
        )
        
        # Notify admins about new payment
        for admin_id in Config.ADMIN_IDS:
            try:
                await context.bot.send_message(
                    chat_id=admin_id,
                    text=f"💰 <b>New Payment Received!</b>\n\n"
                         f"👤 User: {update.effective_user.first_name} ({user_id})\n"
                         f"💳 Amount: ${invoice_data.get('amount', Config.SUBSCRIPTION_PRICE_USD)} USD\n"
                         f"🆔 Invoice: <code>{invoice_id}</code>\n"
                         f"📅 Date: {time.strftime('%Y-%m-%d %H:%M:%S')}",
                    parse_mode='HTML'
                )
            except:
                pass
        
        # Clear payment data from context
        context.user_data.pop('payment_invoice_id', None)
        context.user_data.pop('payment_amount', None)
        
    except Exception as e:
        logger.error(f"Error processing successful payment for {invoice_id}: {e}")
        await update.callback_query.answer("❌ Error processing payment")

async def handle_expired_payment(update: Update, context: ContextTypes.DEFAULT_TYPE, invoice_id: str):
    """Handle expired payment"""
    user_id = update.effective_user.id
    
    # Update payment status
    update_payment_status(invoice_id, "expired")
    
    # Stop auto-check job
    current_jobs = context.job_queue.get_jobs_by_name(f"payment_check_{user_id}_{invoice_id}")
    for job in current_jobs:
        job.schedule_removal()
    
    expired_message = (
        f"⏰ <b>Payment Expired</b>\n\n"
        f"❌ Invoice has expired\n"
        f"🆔 Invoice ID: <code>{invoice_id}</code>\n\n"
        f"💡 <b>No worries!</b> You can create a new payment.\n"
        f"Your progress is saved and you won't be charged twice."
    )
    
    keyboard = [
        [InlineKeyboardButton("💳 Create New Payment", callback_data="payment_create")],
        [InlineKeyboardButton("💬 Contact Support", callback_data="contact_admin_payment")],
        [InlineKeyboardButton("🔙 Back", callback_data="show_main_menu")]
    ]
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.callback_query.edit_message_text(
        expired_message,
        parse_mode='HTML',
        reply_markup=reply_markup
    )

async def handle_pending_payment(update: Update, context: ContextTypes.DEFAULT_TYPE, 
                                invoice_id: str, status: str):
    """Handle pending payment"""
    pending_message = (
        f"⏳ <b>Payment Pending</b>\n\n"
        f"🔍 Status: {status.title()}\n"
        f"🆔 Invoice ID: <code>{invoice_id}</code>\n\n"
        f"💡 <b>Payment not completed yet.</b>\n"
        f"Please complete the payment in CryptoBot and check again.\n\n"
        f"🔄 Auto-checking every 30 seconds..."
    )
    
    keyboard = [
        [InlineKeyboardButton("🔍 Check Again", callback_data=f"payment_check_{invoice_id}")],
        [InlineKeyboardButton("💳 Open Payment", url=f"https://t.me/CryptoBot?start=pay_{invoice_id}")],
        [InlineKeyboardButton("💬 Support", callback_data="contact_admin_payment")],
        [InlineKeyboardButton("❌ Cancel", callback_data="payment_cancel")]
    ]
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.callback_query.edit_message_text(
        pending_message,
        parse_mode='HTML',
        reply_markup=reply_markup
    )

async def auto_check_payment(context: ContextTypes.DEFAULT_TYPE):
    """Automatically check payment status"""
    job_context = context.job.context
    user_id = job_context['user_id']
    invoice_id = job_context['invoice_id']
    chat_id = job_context['chat_id']
    message_id = job_context['message_id']
    
    try:
        # Check if user already paid (to stop auto-check)
        from database import is_user_paid
        if is_user_paid(user_id):
            context.job.schedule_removal()
            return
        
        # Get invoice status
        invoice_response = crypto_api.get_invoice(invoice_id)
        
        if invoice_response.get("ok"):
            invoice_data = invoice_response["result"]
            status = invoice_data.get("status", "active")
            
            if status == "paid":
                # Payment successful - update user
                update_payment_status(invoice_id, "paid")
                update_user_payment(user_id, invoice_id)
                
                # Send success notification
                success_message = (
                    f"🎉 <b>Payment Confirmed!</b>\n\n"
                    f"✅ Premium subscription activated automatically\n"
                    f"💰 Amount: ${invoice_data.get('amount', Config.SUBSCRIPTION_PRICE_USD)} USD\n\n"
                    f"🚀 All premium features are now available!\n"
                    f"Click below to start using the bot."
                )
                
                keyboard = [
                    [InlineKeyboardButton("🔐 Connect Google Drive", callback_data="oauth_start")],
                    [InlineKeyboardButton("🏠 Main Menu", callback_data="show_main_menu")]
                ]
                
                reply_markup = InlineKeyboardMarkup(keyboard)
                
                await context.bot.edit_message_text(
                    chat_id=chat_id,
                    message_id=message_id,
                    text=success_message,
                    parse_mode='HTML',
                    reply_markup=reply_markup
                )
                
                # Log auto-confirmed payment
                log_activity(
                    user_id=user_id,
                    action="payment_auto_confirmed",
                    details=f"Auto-confirmed payment: {invoice_id}"
                )
                
                # Stop the job
                context.job.schedule_removal()
                
            elif status == "expired":
                # Payment expired
                context.job.schedule_removal()
    
    except Exception as e:
        logger.error(f"Error in auto payment check for {invoice_id}: {e}")
        # Don't remove job on error, let it retry

async def show_payment_info(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show payment information"""
    info_message = (
        f"💳 <b>Payment Information</b>\n\n"
        f"💰 <b>Pricing:</b>\n"
        f"• Amount: ${Config.SUBSCRIPTION_PRICE_USD} USD\n"
        f"• Duration: Lifetime (no recurring fees)\n"
        f"• Features: All premium features included\n\n"
        f"🔐 <b>Payment Security:</b>\n"
        f"✅ Powered by CryptoBot (Telegram official)\n"
        f"✅ PCI DSS compliant\n"
        f"✅ No card details stored\n"
        f"✅ Instant confirmation\n\n"
        f"💎 <b>Supported Cryptocurrencies:</b>\n"
        f"• Bitcoin (BTC)\n"
        f"• Ethereum (ETH)\n"
        f"• Tether (USDT)\n"
        f"• Toncoin (TON)\n"
        f"• And 10+ more coins\n\n"
        f"💳 <b>Fiat Payments:</b>\n"
        f"• Credit/Debit Cards\n"
        f"• Bank transfers (selected regions)\n"
        f"• Apple Pay / Google Pay\n\n"
        f"🛡️ <b>Anti-Double Payment:</b>\n"
        f"✅ Secure payment tracking\n"
        f"✅ Duplicate payment protection\n"
        f"✅ Auto-refund if double charged\n\n"
        f"📞 <b>Support:</b>\n"
        f"• 24/7 payment support\n"
        f"• Refund available (24 hours)\n"
        f"• Direct admin contact"
    )
    
    keyboard = [
        [InlineKeyboardButton("💳 Start Payment", callback_data="payment_create")],
        [InlineKeyboardButton("💬 Contact Support", callback_data="contact_admin_payment")],
        [InlineKeyboardButton("🔙 Back", callback_data="payment_start")]
    ]
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.callback_query.edit_message_text(
        info_message,
        parse_mode='HTML',
        reply_markup=reply_markup
    )

async def cancel_payment(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Cancel current payment process"""
    user_id = update.effective_user.id
    invoice_id = context.user_data.get('payment_invoice_id')
    
    # Stop auto-check job if exists
    if invoice_id:
        current_jobs = context.job_queue.get_jobs_by_name(f"payment_check_{user_id}_{invoice_id}")
        for job in current_jobs:
            job.schedule_removal()
    
    # Clear payment data
    context.user_data.pop('payment_invoice_id', None)
    context.user_data.pop('payment_amount', None)
    
    cancel_message = (
        f"❌ <b>Payment Cancelled</b>\n\n"
        f"Your payment process has been cancelled.\n"
        f"No charges have been made.\n\n"
        f"You can start a new payment anytime from the main menu."
    )
    
    keyboard = [
        [InlineKeyboardButton("💳 Start New Payment", callback_data="payment_start")],
        [InlineKeyboardButton("🏠 Main Menu", callback_data="show_main_menu")]
    ]
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.callback_query.edit_message_text(
        cancel_message,
        parse_mode='HTML',
        reply_markup=reply_markup
    )

async def handle_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle payment-related callback queries"""
    query = update.callback_query
    data = query.data
    
    if data == "payment_start":
        await start_payment_process(update, context)
    elif data == "payment_create":
        await create_payment_invoice(update, context)
    elif data == "payment_info":
        await show_payment_info(update, context)
    elif data.startswith("payment_check_"):
        invoice_id = data.split("_", 2)[2]
        await check_payment_status(update, context, invoice_id)
    elif data == "payment_cancel":
        await cancel_payment(update, context)
    elif data == "contact_admin_payment":
        # Redirect to contact admin with payment context
        context.user_data['contact_reason'] = 'payment_issue'
        from handlers.contact_admin_handler import start_contact_admin
        await start_contact_admin(update, context)

def get_conversation_handler():
    """Get conversation handler for payment process"""
    return ConversationHandler(
        entry_points=[],
        states={
            PAYMENT_CONFIRM: [],
            PAYMENT_WAITING: []
        },
        fallbacks=[],
        allow_reentry=True
    )
