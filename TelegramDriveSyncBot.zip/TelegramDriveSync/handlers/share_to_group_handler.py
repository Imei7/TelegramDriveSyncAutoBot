"""
TelegramDriveSync Bot - Share to Group Handler
Fitur share file/log ke grup (massal/checklist, jadwal)
"""

import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes, ConversationHandler, MessageHandler, filters
from database import (
    get_authorized_groups, add_authorized_group, get_all_logs, 
    get_user_logs, log_activity, get_user_gdrive_accounts
)
from config import Config
from utils import (
    paginate_items, create_pagination_keyboard, format_log_entry,
    format_file_size, get_file_type_emoji, parse_schedule_time
)
from datetime import datetime, timedelta
import json
import os

logger = logging.getLogger(__name__)

# Share conversation states
SHARE_SELECT_GROUPS, SHARE_ADD_CAPTION, SHARE_SCHEDULE_TIME, SHARE_CONFIRM = range(4)

async def show_group_share_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show group sharing menu"""
    user_id = update.effective_user.id
    
    # Check if user is admin
    if user_id not in Config.ADMIN_IDS:
        await update.callback_query.answer("❌ Admin access required")
        return
    
    groups = get_authorized_groups()
    
    share_message = f"📤 <b>Share to Groups</b>\n\n"
    
    if not groups:
        share_message += (
            f"❌ No authorized groups found.\n\n"
            f"Add groups to the authorized list first before sharing."
        )
        keyboard = [
            [InlineKeyboardButton("➕ Add Group", callback_data="admin_add_group")],
            [InlineKeyboardButton("🔙 Back", callback_data="admin_back_main")]
        ]
    else:
        share_message += f"📊 Authorized groups: {len(groups)}\n\n"
        
        # Show recent groups
        for group in groups[-3:]:  # Show last 3 groups
            title = group.get('group_title', 'Unknown')[:25]
            status = "✅" if group.get('status') == 'approved' else "⏳"
            share_message += f"{status} {title}\n"
            share_message += f"   ID: <code>{group['group_id']}</code>\n\n"
        
        share_message += (
            f"📋 <b>Share Options:</b>\n"
            f"📁 Share files from Google Drive\n"
            f"📝 Share activity logs\n"
            f"📊 Share system reports\n"
            f"🎥 Share videos with streaming\n"
            f"⏰ Schedule shares for later\n\n"
            f"🎯 <b>Features:</b>\n"
            f"• Multiple group selection\n"
            f"• Custom captions\n"
            f"• Scheduled posting\n"
            f"• Progress tracking\n"
            f"• Error handling"
        )
        
        keyboard = [
            [
                InlineKeyboardButton("📁 Share Files", callback_data="share_files"),
                InlineKeyboardButton("📝 Share Logs", callback_data="share_logs")
            ],
            [
                InlineKeyboardButton("📊 Share Reports", callback_data="share_reports"),
                InlineKeyboardButton("🎥 Share Videos", callback_data="share_videos")
            ],
            [
                InlineKeyboardButton("⏰ Scheduled Shares", callback_data="share_scheduled"),
                InlineKeyboardButton("📋 Share History", callback_data="share_history")
            ],
            [
                InlineKeyboardButton("🔗 Manage Groups", callback_data="admin_view_groups"),
                InlineKeyboardButton("🔙 Back", callback_data="admin_back_main")
            ]
        ]
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    if update.callback_query:
        await update.callback_query.edit_message_text(
            share_message,
            parse_mode='HTML',
            reply_markup=reply_markup
        )
    else:
        await update.message.reply_text(
            share_message,
            parse_mode='HTML',
            reply_markup=reply_markup
        )

async def start_file_share(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Start file sharing process"""
    user_id = update.effective_user.id
    
    if user_id not in Config.ADMIN_IDS:
        await update.callback_query.answer("❌ Admin access required")
        return
    
    # Get user's Google Drive accounts for file selection
    accounts = get_user_gdrive_accounts(user_id)
    
    if not accounts:
        await update.callback_query.edit_message_text(
            "❌ <b>No Google Drive Accounts</b>\n\n"
            "You need to connect a Google Drive account first to share files.",
            parse_mode='HTML',
            reply_markup=InlineKeyboardMarkup([[
                InlineKeyboardButton("🔐 Connect GDrive", callback_data="oauth_start"),
                InlineKeyboardButton("🔙 Back", callback_data="share_menu")
            ]])
        )
        return
    
    context.user_data['share_type'] = 'files'
    
    file_share_message = (
        f"📁 <b>Share Files to Groups</b>\n\n"
        f"📧 <b>Available Accounts:</b> {len(accounts)}\n"
        f"📊 Select files from your Google Drive to share with authorized groups.\n\n"
        f"🎯 <b>Share Process:</b>\n"
        f"1️⃣ Browse and select files\n"
        f"2️⃣ Choose target groups\n"
        f"3️⃣ Add custom caption (optional)\n"
        f"4️⃣ Schedule or send immediately\n\n"
        f"💡 <b>Supported:</b>\n"
        f"📄 Documents, Images, Videos\n"
        f"🔗 Direct download links\n"
        f"📱 Mobile-optimized sharing\n"
        f"🎥 Video streaming links"
    )
    
    keyboard = [
        [InlineKeyboardButton("📂 Browse Files", callback_data="share_browse_files")],
        [InlineKeyboardButton("🔗 Share by Link", callback_data="share_file_link")],
        [InlineKeyboardButton("📋 Recent Files", callback_data="share_recent_files")],
        [InlineKeyboardButton("🔙 Back", callback_data="share_menu")]
    ]
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.callback_query.edit_message_text(
        file_share_message,
        parse_mode='HTML',
        reply_markup=reply_markup
    )

async def start_log_share(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Start log sharing process"""
    user_id = update.effective_user.id
    
    if user_id not in Config.ADMIN_IDS:
        await update.callback_query.answer("❌ Admin access required")
        return
    
    context.user_data['share_type'] = 'logs'
    
    log_share_message = (
        f"📝 <b>Share Logs to Groups</b>\n\n"
        f"📊 Share system activity logs with authorized groups.\n\n"
        f"📋 <b>Available Log Types:</b>\n"
        f"📈 All system activity\n"
        f"👥 User activity logs\n"
        f"📤 Upload activities\n"
        f"🔗 Scraping activities\n"
        f"❌ Error logs\n"
        f"💳 Payment activities\n\n"
        f"⚙️ <b>Share Options:</b>\n"
        f"📄 Text format (readable)\n"
        f"📁 JSON export (detailed)\n"
        f"📊 Summary reports\n"
        f"📈 Statistics overview\n\n"
        f"🔒 <b>Privacy:</b>\n"
        f"• Sensitive data filtered\n"
        f"• User IDs anonymized\n"
        f"• Admin-only information"
    )
    
    keyboard = [
        [
            InlineKeyboardButton("📈 All Activity", callback_data="share_logs_all"),
            InlineKeyboardButton("👥 User Logs", callback_data="share_logs_users")
        ],
        [
            InlineKeyboardButton("📤 Upload Logs", callback_data="share_logs_uploads"),
            InlineKeyboardButton("🔗 Scrape Logs", callback_data="share_logs_scraping")
        ],
        [
            InlineKeyboardButton("❌ Error Logs", callback_data="share_logs_errors"),
            InlineKeyboardButton("💳 Payment Logs", callback_data="share_logs_payments")
        ],
        [
            InlineKeyboardButton("📊 Generate Report", callback_data="share_generate_report"),
            InlineKeyboardButton("🔙 Back", callback_data="share_menu")
        ]
    ]
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.callback_query.edit_message_text(
        log_share_message,
        parse_mode='HTML',
        reply_markup=reply_markup
    )

async def share_all_logs(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Share all system logs"""
    await share_logs_by_type(update, context, 'all', "All System Activity")

async def share_user_logs(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Share user activity logs"""
    await share_logs_by_type(update, context, 'user', "User Activity")

async def share_upload_logs(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Share upload activity logs"""
    await share_logs_by_type(update, context, 'upload', "Upload Activity")

async def share_scraping_logs(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Share scraping activity logs"""
    await share_logs_by_type(update, context, 'scraping', "Scraping Activity")

async def share_error_logs(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Share error logs"""
    await share_logs_by_type(update, context, 'error', "Error Logs")

async def share_payment_logs(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Share payment logs"""
    await share_logs_by_type(update, context, 'payment', "Payment Activity")

async def share_logs_by_type(update: Update, context: ContextTypes.DEFAULT_TYPE, 
                           log_type: str, log_title: str):
    """Share logs by specific type"""
    user_id = update.effective_user.id
    
    # Get logs based on type
    if log_type == 'all':
        logs = get_all_logs(limit=50)
    elif log_type == 'user':
        logs = get_all_logs(limit=100)
        logs = [log for log in logs if 'user' in log.get('action', '').lower()]
    elif log_type == 'upload':
        logs = get_all_logs(limit=100)
        logs = [log for log in logs if 'upload' in log.get('action', '').lower()]
    elif log_type == 'scraping':
        logs = get_all_logs(limit=100)
        logs = [log for log in logs if 'scrape' in log.get('action', '').lower() or 'twitter' in log.get('action', '').lower()]
    elif log_type == 'error':
        logs = get_all_logs(limit=100)
        logs = [log for log in logs if log.get('status') == 'failed' or 'error' in log.get('action', '').lower()]
    elif log_type == 'payment':
        logs = get_all_logs(limit=100)
        logs = [log for log in logs if 'payment' in log.get('action', '').lower()]
    else:
        logs = []
    
    context.user_data['share_logs'] = logs
    context.user_data['share_log_type'] = log_type
    context.user_data['share_log_title'] = log_title
    
    if not logs:
        await update.callback_query.edit_message_text(
            f"📝 <b>No {log_title} Found</b>\n\n"
            f"No logs of this type are available to share.",
            parse_mode='HTML',
            reply_markup=InlineKeyboardMarkup([[
                InlineKeyboardButton("🔙 Back", callback_data="share_logs")
            ]])
        )
        return
    
    # Preview logs
    preview_message = f"📝 <b>Preview: {log_title}</b>\n\n"
    preview_message += f"📊 Total logs: {len(logs)}\n"
    preview_message += f"📅 Date range: {logs[-1]['created_at'][:10]} to {logs[0]['created_at'][:10]}\n\n"
    preview_message += f"📋 <b>Sample entries:</b>\n\n"
    
    for log in logs[:3]:  # Show first 3 logs
        formatted_log = format_log_entry(log)
        # Sanitize for group sharing (remove user IDs, etc.)
        sanitized_log = sanitize_log_for_sharing(formatted_log)
        preview_message += f"{sanitized_log}\n\n"
    
    if len(logs) > 3:
        preview_message += f"... and {len(logs) - 3} more entries\n\n"
    
    preview_message += f"❓ Proceed to select groups for sharing?"
    
    keyboard = [
        [
            InlineKeyboardButton("✅ Select Groups", callback_data="share_select_groups"),
            InlineKeyboardButton("📊 Change Format", callback_data="share_change_format")
        ],
        [
            InlineKeyboardButton("📥 Export First", callback_data="share_export_logs"),
            InlineKeyboardButton("🔙 Back", callback_data="share_logs")
        ]
    ]
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.callback_query.edit_message_text(
        preview_message,
        parse_mode='HTML',
        reply_markup=reply_markup
    )

async def select_target_groups(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Select target groups for sharing"""
    groups = get_authorized_groups()
    
    if not groups:
        await update.callback_query.answer("No authorized groups available")
        return
    
    context.user_data['share_selected_groups'] = []
    
    group_message = f"🔗 <b>Select Target Groups</b>\n\n"
    group_message += f"📊 Available groups: {len(groups)}\n"
    group_message += f"✅ Select groups to share content with:\n\n"
    
    keyboard = []
    
    for group in groups:
        group_title = group.get('group_title', 'Unknown')[:20]
        group_id = group['group_id']
        selected = "☑️" if group_id in context.user_data.get('share_selected_groups', []) else "⬜"
        
        group_message += f"{selected} {group_title}\n"
        group_message += f"   ID: <code>{group_id}</code>\n\n"
        
        keyboard.append([InlineKeyboardButton(
            f"{selected} {group_title}",
            callback_data=f"share_toggle_group_{group_id}"
        )])
    
    # Action buttons
    keyboard.extend([
        [
            InlineKeyboardButton("✅ Select All", callback_data="share_select_all_groups"),
            InlineKeyboardButton("❌ Clear All", callback_data="share_clear_all_groups")
        ],
        [
            InlineKeyboardButton("➡️ Next: Caption", callback_data="share_add_caption"),
            InlineKeyboardButton("🔙 Back", callback_data="share_logs")
        ]
    ])
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.callback_query.edit_message_text(
        group_message,
        parse_mode='HTML',
        reply_markup=reply_markup
    )
    
    return SHARE_SELECT_GROUPS

async def toggle_group_selection(update: Update, context: ContextTypes.DEFAULT_TYPE, group_id: int):
    """Toggle group selection"""
    selected_groups = context.user_data.get('share_selected_groups', [])
    
    if group_id in selected_groups:
        selected_groups.remove(group_id)
    else:
        selected_groups.append(group_id)
    
    context.user_data['share_selected_groups'] = selected_groups
    
    # Refresh the group selection view
    await select_target_groups(update, context)

async def add_share_caption(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Add custom caption for sharing"""
    selected_groups = context.user_data.get('share_selected_groups', [])
    
    if not selected_groups:
        await update.callback_query.answer("❌ Please select at least one group first")
        return
    
    caption_message = (
        f"📝 <b>Add Caption (Optional)</b>\n\n"
        f"🎯 Selected groups: {len(selected_groups)}\n\n"
        f"✍️ Send a custom caption/message to include with the shared content.\n\n"
        f"💡 <b>Tips:</b>\n"
        f"• Keep it informative and relevant\n"
        f"• HTML formatting supported\n"
        f"• Mention important details\n"
        f"• Add context about the content\n\n"
        f"⏭️ Or skip to proceed without caption.\n\n"
        f"<i>Send your caption message:</i>"
    )
    
    keyboard = [
        [InlineKeyboardButton("⏭️ Skip Caption", callback_data="share_skip_caption")],
        [InlineKeyboardButton("❌ Cancel", callback_data="share_cancel")]
    ]
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.callback_query.edit_message_text(
        caption_message,
        parse_mode='HTML',
        reply_markup=reply_markup
    )
    
    return SHARE_ADD_CAPTION

async def handle_caption_input(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle caption input from user"""
    caption = update.message.text
    
    if caption == "/cancel":
        await update.message.reply_text("❌ Share process cancelled.")
        await show_group_share_menu(update, context)
        return ConversationHandler.END
    
    context.user_data['share_caption'] = caption
    
    await update.message.reply_text(
        f"✅ Caption added!\n\n"
        f"📝 <b>Caption preview:</b>\n{caption}\n\n"
        f"Now choose when to send:",
        parse_mode='HTML'
    )
    
    await show_schedule_options(update, context)
    
    return SHARE_SCHEDULE_TIME

async def show_schedule_options(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show scheduling options"""
    schedule_message = (
        f"⏰ <b>Schedule Sharing</b>\n\n"
        f"📅 Choose when to send the content to groups:\n\n"
        f"🚀 <b>Send Now:</b> Immediate delivery\n"
        f"⏰ <b>Schedule:</b> Set specific date/time\n"
        f"🔄 <b>Recurring:</b> Daily/weekly schedule\n\n"
        f"💡 <b>Schedule Format:</b>\n"
        f"• YYYY-MM-DD HH:MM\n"
        f"• Example: 2024-12-25 15:30\n"
        f"• Use 24-hour format"
    )
    
    keyboard = [
        [InlineKeyboardButton("🚀 Send Now", callback_data="share_send_now")],
        [InlineKeyboardButton("⏰ Schedule for Later", callback_data="share_schedule_later")],
        [InlineKeyboardButton("🔄 Recurring Schedule", callback_data="share_schedule_recurring")],
        [InlineKeyboardButton("🔙 Back to Caption", callback_data="share_add_caption")]
    ]
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    if update.callback_query:
        await update.callback_query.edit_message_text(
            schedule_message,
            parse_mode='HTML',
            reply_markup=reply_markup
        )
    else:
        await update.message.reply_text(
            schedule_message,
            parse_mode='HTML',
            reply_markup=reply_markup
        )

async def request_schedule_time(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Request schedule time from user"""
    time_message = (
        f"📅 <b>Schedule Time</b>\n\n"
        f"📝 Please send the date and time when you want to share the content.\n\n"
        f"📋 <b>Format:</b> YYYY-MM-DD HH:MM\n\n"
        f"💡 <b>Examples:</b>\n"
        f"• 2024-12-25 15:30\n"
        f"• 2024-01-01 00:00\n"
        f"• 2024-06-15 09:00\n\n"
        f"⏰ <b>Note:</b> Use 24-hour format\n"
        f"🌍 Timezone: Server time (UTC)\n\n"
        f"✍️ <i>Send the schedule time:</i>"
    )
    
    keyboard = [
        [InlineKeyboardButton("🚀 Send Now Instead", callback_data="share_send_now")],
        [InlineKeyboardButton("❌ Cancel", callback_data="share_cancel")]
    ]
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.callback_query.edit_message_text(
        time_message,
        parse_mode='HTML',
        reply_markup=reply_markup
    )
    
    return SHARE_SCHEDULE_TIME

async def handle_schedule_time_input(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle schedule time input"""
    time_str = update.message.text.strip()
    
    if time_str == "/cancel":
        await update.message.reply_text("❌ Share process cancelled.")
        await show_group_share_menu(update, context)
        return ConversationHandler.END
    
    # Parse schedule time
    schedule_time = parse_schedule_time(time_str)
    
    if not schedule_time:
        await update.message.reply_text(
            "❌ Invalid time format!\n\n"
            "Please use: YYYY-MM-DD HH:MM\n"
            "Example: 2024-12-25 15:30"
        )
        return SHARE_SCHEDULE_TIME
    
    # Check if time is in the future
    if schedule_time <= datetime.now():
        await update.message.reply_text(
            "❌ Schedule time must be in the future!\n\n"
            "Please choose a time that hasn't passed yet."
        )
        return SHARE_SCHEDULE_TIME
    
    context.user_data['share_schedule_time'] = schedule_time
    
    await update.message.reply_text(
        f"✅ Schedule time set!\n\n"
        f"⏰ Will send at: {schedule_time.strftime('%Y-%m-%d %H:%M:%S')}\n\n"
        f"Ready to confirm the sharing.",
        parse_mode='HTML'
    )
    
    await show_share_confirmation(update, context)
    
    return SHARE_CONFIRM

async def show_share_confirmation(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show final confirmation for sharing"""
    share_type = context.user_data.get('share_type', 'unknown')
    selected_groups = context.user_data.get('share_selected_groups', [])
    caption = context.user_data.get('share_caption', '')
    schedule_time = context.user_data.get('share_schedule_time')
    
    # Get group details
    all_groups = get_authorized_groups()
    target_groups = [g for g in all_groups if g['group_id'] in selected_groups]
    
    confirm_message = f"📋 <b>Confirm Sharing</b>\n\n"
    confirm_message += f"📤 <b>Content Type:</b> {share_type.title()}\n"
    confirm_message += f"🎯 <b>Target Groups:</b> {len(target_groups)}\n\n"
    
    # Show target groups
    for group in target_groups[:3]:  # Show first 3
        title = group.get('group_title', 'Unknown')[:20]
        confirm_message += f"📢 {title}\n"
    
    if len(target_groups) > 3:
        confirm_message += f"... and {len(target_groups) - 3} more groups\n"
    
    confirm_message += "\n"
    
    if caption:
        confirm_message += f"📝 <b>Caption:</b>\n{caption[:100]}{'...' if len(caption) > 100 else ''}\n\n"
    
    if schedule_time:
        confirm_message += f"⏰ <b>Scheduled:</b> {schedule_time.strftime('%Y-%m-%d %H:%M:%S')}\n\n"
    else:
        confirm_message += f"🚀 <b>Delivery:</b> Immediate\n\n"
    
    # Content summary
    if share_type == 'logs':
        logs = context.user_data.get('share_logs', [])
        log_title = context.user_data.get('share_log_title', 'Unknown')
        confirm_message += f"📊 <b>Content:</b> {len(logs)} {log_title} entries\n"
    
    confirm_message += f"\n❓ Proceed with sharing?"
    
    keyboard = [
        [
            InlineKeyboardButton("✅ Confirm & Send", callback_data="share_execute"),
            InlineKeyboardButton("✏️ Edit Caption", callback_data="share_add_caption")
        ],
        [
            InlineKeyboardButton("⏰ Change Time", callback_data="share_schedule_later"),
            InlineKeyboardButton("🎯 Change Groups", callback_data="share_select_groups")
        ],
        [InlineKeyboardButton("❌ Cancel", callback_data="share_cancel")]
    ]
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    if update.callback_query:
        await update.callback_query.edit_message_text(
            confirm_message,
            parse_mode='HTML',
            reply_markup=reply_markup
        )
    else:
        await update.message.reply_text(
            confirm_message,
            parse_mode='HTML',
            reply_markup=reply_markup
        )

async def execute_share(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Execute the sharing process"""
    user_id = update.effective_user.id
    share_type = context.user_data.get('share_type', 'unknown')
    selected_groups = context.user_data.get('share_selected_groups', [])
    caption = context.user_data.get('share_caption', '')
    schedule_time = context.user_data.get('share_schedule_time')
    
    if not selected_groups:
        await update.callback_query.answer("❌ No groups selected")
        return
    
    await update.callback_query.answer("Starting share process...")
    
    if schedule_time:
        # Schedule for later
        await schedule_share_task(update, context)
    else:
        # Send immediately
        await send_immediate_share(update, context)

async def send_immediate_share(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Send share immediately"""
    user_id = update.effective_user.id
    share_type = context.user_data.get('share_type', 'unknown')
    selected_groups = context.user_data.get('share_selected_groups', [])
    caption = context.user_data.get('share_caption', '')
    
    # Progress message
    progress_message = f"📤 <b>Sharing in Progress</b>\n\n"
    progress_message += f"🎯 Groups: {len(selected_groups)}\n"
    progress_message += f"✅ Sent: 0\n"
    progress_message += f"❌ Failed: 0\n"
    progress_message += f"📊 Progress: 0%"
    
    progress_msg = await update.callback_query.edit_message_text(
        progress_message,
        parse_mode='HTML'
    )
    
    success_count = 0
    fail_count = 0
    
    try:
        if share_type == 'logs':
            # Share logs
            logs = context.user_data.get('share_logs', [])
            log_title = context.user_data.get('share_log_title', 'Logs')
            
            # Create log content
            log_content = create_log_share_content(logs, log_title, caption)
            
            for i, group_id in enumerate(selected_groups):
                try:
                    await context.bot.send_message(
                        chat_id=group_id,
                        text=log_content,
                        parse_mode='HTML'
                    )
                    success_count += 1
                    
                except Exception as e:
                    logger.error(f"Failed to share to group {group_id}: {e}")
                    fail_count += 1
                
                # Update progress
                progress = ((i + 1) / len(selected_groups)) * 100
                updated_message = f"📤 <b>Sharing in Progress</b>\n\n"
                updated_message += f"🎯 Groups: {len(selected_groups)}\n"
                updated_message += f"✅ Sent: {success_count}\n"
                updated_message += f"❌ Failed: {fail_count}\n"
                updated_message += f"📊 Progress: {progress:.1f}%"
                
                try:
                    await progress_msg.edit_text(updated_message, parse_mode='HTML')
                except:
                    pass
                
                # Delay between sends
                await asyncio.sleep(1)
        
        # Final result
        result_message = f"📤 <b>Sharing Completed!</b>\n\n"
        result_message += f"🎯 Total groups: {len(selected_groups)}\n"
        result_message += f"✅ Successfully sent: {success_count}\n"
        result_message += f"❌ Failed: {fail_count}\n"
        result_message += f"📈 Success rate: {(success_count/len(selected_groups)*100) if selected_groups else 0:.1f}%\n\n"
        result_message += f"⏰ Completed at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
        
        keyboard = [
            [InlineKeyboardButton("📤 Share More", callback_data="share_menu")],
            [InlineKeyboardButton("📋 Share History", callback_data="share_history")],
            [InlineKeyboardButton("🏠 Admin Panel", callback_data="admin_back_main")]
        ]
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await progress_msg.edit_text(result_message, parse_mode='HTML', reply_markup=reply_markup)
        
        # Log the sharing activity
        log_activity(
            user_id=user_id,
            action="group_share",
            details=f"Shared {share_type} to {success_count}/{len(selected_groups)} groups"
        )
        
    except Exception as e:
        logger.error(f"Error in immediate share: {e}")
        await progress_msg.edit_text(
            f"❌ <b>Share Failed</b>\n\n"
            f"Error: {str(e)}\n\n"
            f"Please try again or contact support.",
            parse_mode='HTML',
            reply_markup=InlineKeyboardMarkup([[
                InlineKeyboardButton("🔄 Try Again", callback_data="share_menu")
            ]])
        )
    
    finally:
        # Clear share data
        clear_share_data(context)

async def schedule_share_task(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Schedule share task for later"""
    from scheduler import BotScheduler
    
    user_id = update.effective_user.id
    share_type = context.user_data.get('share_type', 'unknown')
    selected_groups = context.user_data.get('share_selected_groups', [])
    caption = context.user_data.get('share_caption', '')
    schedule_time = context.user_data.get('share_schedule_time')
    
    # Prepare task data
    task_data = {
        'share_type': share_type,
        'groups': selected_groups,
        'caption': caption,
        'created_by': user_id
    }
    
    if share_type == 'logs':
        # Store log data for scheduled sharing
        logs = context.user_data.get('share_logs', [])
        log_title = context.user_data.get('share_log_title', 'Logs')
        task_data['logs'] = logs
        task_data['log_title'] = log_title
    
    # Add to scheduler
    try:
        # Get scheduler instance (assuming it's available in context)
        if hasattr(context, 'application') and hasattr(context.application, 'scheduler'):
            scheduler = context.application.scheduler
            task_id = scheduler.add_scheduled_group_share(
                group_id=0,  # Will be processed from task_data
                message=json.dumps(task_data),
                scheduled_time=schedule_time,
                created_by=user_id
            )
            
            if task_id:
                success_message = f"⏰ <b>Share Scheduled!</b>\n\n"
                success_message += f"📅 <b>Scheduled for:</b> {schedule_time.strftime('%Y-%m-%d %H:%M:%S')}\n"
                success_message += f"🎯 <b>Target groups:</b> {len(selected_groups)}\n"
                success_message += f"📋 <b>Content:</b> {share_type.title()}\n"
                success_message += f"🆔 <b>Task ID:</b> <code>{task_id}</code>\n\n"
                success_message += f"✅ The content will be automatically shared at the scheduled time."
                
                keyboard = [
                    [InlineKeyboardButton("⏰ View Scheduled", callback_data="share_scheduled")],
                    [InlineKeyboardButton("📤 Share More", callback_data="share_menu")],
                    [InlineKeyboardButton("🏠 Admin Panel", callback_data="admin_back_main")]
                ]
                
                reply_markup = InlineKeyboardMarkup(keyboard)
                
                await update.callback_query.edit_message_text(
                    success_message,
                    parse_mode='HTML',
                    reply_markup=reply_markup
                )
                
                # Log scheduling
                log_activity(
                    user_id=user_id,
                    action="schedule_share",
                    details=f"Scheduled {share_type} share to {len(selected_groups)} groups for {schedule_time}"
                )
            else:
                raise Exception("Failed to create scheduled task")
        else:
            raise Exception("Scheduler not available")
            
    except Exception as e:
        logger.error(f"Error scheduling share: {e}")
        await update.callback_query.edit_message_text(
            f"❌ <b>Scheduling Failed</b>\n\n"
            f"Error: {str(e)}\n\n"
            f"You can try sending immediately instead.",
            parse_mode='HTML',
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🚀 Send Now", callback_data="share_send_now")],
                [InlineKeyboardButton("🔙 Back", callback_data="share_menu")]
            ])
        )
    
    finally:
        # Clear share data
        clear_share_data(context)

def create_log_share_content(logs: list, log_title: str, caption: str = "") -> str:
    """Create formatted content for log sharing"""
    content = f"📊 <b>{log_title} Report</b>\n\n"
    
    if caption:
        content += f"📝 {caption}\n\n"
    
    content += f"📈 <b>Summary:</b>\n"
    content += f"📋 Total entries: {len(logs)}\n"
    
    if logs:
        # Date range
        content += f"📅 From: {logs[-1]['created_at'][:10]}\n"
        content += f"📅 To: {logs[0]['created_at'][:10]}\n\n"
        
        # Status breakdown
        status_counts = {}
        for log in logs:
            status = log.get('status', 'unknown')
            status_counts[status] = status_counts.get(status, 0) + 1
        
        content += f"📊 <b>Status Breakdown:</b>\n"
        for status, count in status_counts.items():
            emoji = "✅" if status == 'success' else "❌" if status == 'failed' else "⏳"
            content += f"{emoji} {status.title()}: {count}\n"
        
        content += f"\n📋 <b>Recent Entries:</b>\n\n"
        
        # Show recent entries (sanitized)
        for log in logs[:5]:  # Show first 5
            formatted_log = format_log_entry(log)
            sanitized_log = sanitize_log_for_sharing(formatted_log)
            content += f"{sanitized_log}\n\n"
        
        if len(logs) > 5:
            content += f"... and {len(logs) - 5} more entries\n\n"
    
    content += f"⏰ Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"
    content += f"🤖 TelegramDriveSync Bot"
    
    return content

def sanitize_log_for_sharing(log_text: str) -> str:
    """Sanitize log text for group sharing (remove sensitive info)"""
    import re
    
    # Remove user IDs (replace with [USER_ID])
    log_text = re.sub(r'\b\d{8,}\b', '[USER_ID]', log_text)
    
    # Remove email addresses (replace with [EMAIL])
    log_text = re.sub(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b', '[EMAIL]', log_text)
    
    # Remove file paths (replace with [PATH])
    log_text = re.sub(r'/[^\s]+', '[PATH]', log_text)
    
    # Remove IP addresses (replace with [IP])
    log_text = re.sub(r'\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b', '[IP]', log_text)
    
    return log_text

def clear_share_data(context: ContextTypes.DEFAULT_TYPE):
    """Clear sharing-related data from context"""
    keys_to_clear = [
        'share_type', 'share_logs', 'share_log_type', 'share_log_title',
        'share_selected_groups', 'share_caption', 'share_schedule_time'
    ]
    
    for key in keys_to_clear:
        context.user_data.pop(key, None)

async def cancel_share(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Cancel share process"""
    clear_share_data(context)
    
    await update.callback_query.edit_message_text(
        "❌ Share process cancelled.",
        reply_markup=InlineKeyboardMarkup([[
            InlineKeyboardButton("📤 Start New Share", callback_data="share_menu"),
            InlineKeyboardButton("🏠 Admin Panel", callback_data="admin_back_main")
        ]])
    )

async def handle_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle share-related callback queries"""
    query = update.callback_query
    data = query.data
    
    if data == "share_menu":
        await show_group_share_menu(update, context)
    elif data == "share_files":
        await start_file_share(update, context)
    elif data == "share_logs":
        await start_log_share(update, context)
    elif data == "share_logs_all":
        await share_all_logs(update, context)
    elif data == "share_logs_users":
        await share_user_logs(update, context)
    elif data == "share_logs_uploads":
        await share_upload_logs(update, context)
    elif data == "share_logs_scraping":
        await share_scraping_logs(update, context)
    elif data == "share_logs_errors":
        await share_error_logs(update, context)
    elif data == "share_logs_payments":
        await share_payment_logs(update, context)
    elif data == "share_select_groups":
        await select_target_groups(update, context)
    elif data.startswith("share_toggle_group_"):
        group_id = int(data.split("_")[-1])
        await toggle_group_selection(update, context, group_id)
    elif data == "share_select_all_groups":
        groups = get_authorized_groups()
        context.user_data['share_selected_groups'] = [g['group_id'] for g in groups]
        await select_target_groups(update, context)
    elif data == "share_clear_all_groups":
        context.user_data['share_selected_groups'] = []
        await select_target_groups(update, context)
    elif data == "share_add_caption":
        await add_share_caption(update, context)
    elif data == "share_skip_caption":
        context.user_data['share_caption'] = ''
        await show_schedule_options(update, context)
    elif data == "share_send_now":
        context.user_data.pop('share_schedule_time', None)
        await show_share_confirmation(update, context)
    elif data == "share_schedule_later":
        await request_schedule_time(update, context)
    elif data == "share_execute":
        await execute_share(update, context)
    elif data == "share_cancel":
        await cancel_share(update, context)

def get_conversation_handler():
    """Get conversation handler for share operations"""
    return ConversationHandler(
        entry_points=[],
        states={
            SHARE_SELECT_GROUPS: [],
            SHARE_ADD_CAPTION: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, handle_caption_input)
            ],
            SHARE_SCHEDULE_TIME: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, handle_schedule_time_input)
            ],
            SHARE_CONFIRM: []
        },
        fallbacks=[
            MessageHandler(filters.Regex("^/cancel$"), cancel_share)
        ],
        allow_reentry=True
    )
