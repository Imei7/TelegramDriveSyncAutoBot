"""
TelegramDriveSync Bot - Upload Handler
Upload file, link massal, preview, streaming
"""

import logging
import os
import asyncio
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from database import get_primary_gdrive_account, log_activity
from config import Config
from utils import (
    format_file_size, get_file_type_emoji, sanitize_filename, 
    extract_urls_from_text, validate_url, create_progress_bar
)
from handlers.gdrive_handler import GoogleDriveManager, auto_switch_account
import requests
from urllib.parse import urlparse

logger = logging.getLogger(__name__)

# Upload states
UPLOAD_URLS, UPLOAD_CONFIRM = range(2)

async def show_upload_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show upload options menu"""
    user_id = update.effective_user.id
    primary_account = get_primary_gdrive_account(user_id)
    
    upload_message = f"📤 <b>Upload File/Link</b>\n\n"
    
    if not primary_account:
        upload_message += (
            f"❌ Tidak ada akun Google Drive yang terhubung.\n"
            f"Silakan hubungkan akun terlebih dahulu."
        )
        keyboard = [
            [InlineKeyboardButton("🔐 Hubungkan GDrive", callback_data="oauth_start")],
            [InlineKeyboardButton("🔙 Back", callback_data="show_main_menu")]
        ]
    else:
        upload_message += (
            f"📧 <b>Active Account:</b> {primary_account['account_email']}\n\n"
            f"📋 <b>Upload Options:</b>\n"
            f"📁 Send files directly to this chat\n"
            f"🔗 Upload from URLs (batch supported)\n"
            f"📋 Paste multiple links at once\n\n"
            f"📏 <b>Limits:</b>\n"
            f"• Max file size: {format_file_size(Config.MAX_FILE_SIZE)}\n"
            f"• Max uploads/hour: {Config.MAX_UPLOADS_PER_HOUR}\n"
            f"• Auto-switch accounts when quota full"
        )
        
        keyboard = [
            [
                InlineKeyboardButton("🔗 Upload URLs", callback_data="upload_urls"),
                InlineKeyboardButton("📁 Direct Upload", callback_data="upload_direct")
            ],
            [
                InlineKeyboardButton("📋 Batch URLs", callback_data="upload_batch_urls"),
                InlineKeyboardButton("⚙️ Upload Settings", callback_data="upload_settings")
            ],
            [
                InlineKeyboardButton("📊 Upload History", callback_data="upload_history"),
                InlineKeyboardButton("🔙 Back", callback_data="show_main_menu")
            ]
        ]
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    if update.callback_query:
        await update.callback_query.edit_message_text(
            upload_message,
            parse_mode='HTML',
            reply_markup=reply_markup
        )
    else:
        await update.message.reply_text(
            upload_message,
            parse_mode='HTML',
            reply_markup=reply_markup
        )

async def start_url_upload(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Start URL upload process"""
    context.user_data['upload_mode'] = 'single_url'
    
    url_message = (
        f"🔗 <b>Upload from URL</b>\n\n"
        f"📝 Kirim URL file yang ingin diupload ke Google Drive.\n\n"
        f"✅ <b>Supported:</b>\n"
        f"• Direct download links\n"
        f"• Image URLs\n"
        f"• Video/Audio URLs\n"
        f"• Document URLs\n\n"
        f"💡 <b>Tips:</b>\n"
        f"• Pastikan URL bisa diakses langsung\n"
        f"• Bot akan otomatis download dan upload\n"
        f"• Progress akan ditampilkan real-time\n\n"
        f"✍️ <i>Kirim URL file:</i>"
    )
    
    keyboard = [[InlineKeyboardButton("❌ Cancel", callback_data="upload_cancel")]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.callback_query.edit_message_text(
        url_message,
        parse_mode='HTML',
        reply_markup=reply_markup
    )
    
    return UPLOAD_URLS

async def start_batch_url_upload(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Start batch URL upload process"""
    context.user_data['upload_mode'] = 'batch_urls'
    
    batch_message = (
        f"📋 <b>Batch Upload URLs</b>\n\n"
        f"📝 Kirim multiple URLs (satu per baris) untuk diupload ke Google Drive.\n\n"
        f"📋 <b>Format:</b>\n"
        f"https://example.com/file1.pdf\n"
        f"https://example.com/file2.jpg\n"
        f"https://example.com/file3.mp4\n\n"
        f"⚡ <b>Features:</b>\n"
        f"• Upload parallel untuk kecepatan\n"
        f"• Progress tracking per file\n"
        f"• Auto-retry jika gagal\n"
        f"• Summary report setelah selesai\n\n"
        f"💡 <b>Tips:</b>\n"
        f"• Maksimal 10 URLs per batch\n"
        f"• Pastikan semua URL valid\n"
        f"• Bot akan validasi sebelum mulai\n\n"
        f"✍️ <i>Kirim daftar URLs:</i>"
    )
    
    keyboard = [[InlineKeyboardButton("❌ Cancel", callback_data="upload_cancel")]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.callback_query.edit_message_text(
        batch_message,
        parse_mode='HTML',
        reply_markup=reply_markup
    )
    
    return UPLOAD_URLS

async def handle_url_input(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle URL input for upload"""
    text = update.message.text
    upload_mode = context.user_data.get('upload_mode', 'single_url')
    
    if text == "/cancel":
        await update.message.reply_text("❌ Upload dibatalkan.")
        await show_upload_menu(update, context)
        return
    
    if upload_mode == 'single_url':
        # Single URL processing
        if not validate_url(text):
            await update.message.reply_text(
                "❌ URL tidak valid. Silakan kirim URL yang benar.\n"
                "Format: https://example.com/file.ext"
            )
            return UPLOAD_URLS
        
        urls = [text.strip()]
    else:
        # Batch URLs processing
        urls = extract_urls_from_text(text)
        
        if not urls:
            await update.message.reply_text(
                "❌ Tidak ada URL valid ditemukan.\n"
                "Pastikan format URL benar (https://...)"
            )
            return UPLOAD_URLS
        
        if len(urls) > 10:
            await update.message.reply_text(
                f"❌ Terlalu banyak URLs ({len(urls)}).\n"
                f"Maksimal 10 URLs per batch."
            )
            return UPLOAD_URLS
    
    # Store URLs and show confirmation
    context.user_data['upload_urls'] = urls
    
    confirm_message = f"🔗 <b>Konfirmasi Upload</b>\n\n"
    confirm_message += f"📋 <b>URLs to upload:</b> {len(urls)}\n\n"
    
    for i, url in enumerate(urls[:5], 1):  # Show first 5
        filename = os.path.basename(urlparse(url).path) or f"file_{i}"
        confirm_message += f"{i}. {filename}\n"
    
    if len(urls) > 5:
        confirm_message += f"... and {len(urls) - 5} more files\n"
    
    confirm_message += f"\n❓ Mulai upload ke Google Drive?"
    
    keyboard = [
        [
            InlineKeyboardButton("✅ Start Upload", callback_data="upload_confirm"),
            InlineKeyboardButton("❌ Cancel", callback_data="upload_cancel")
        ]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.message.reply_text(
        confirm_message,
        parse_mode='HTML',
        reply_markup=reply_markup
    )
    
    return UPLOAD_CONFIRM

async def execute_url_upload(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Execute the URL upload process"""
    user_id = update.effective_user.id
    urls = context.user_data.get('upload_urls', [])
    
    if not urls:
        await update.callback_query.answer("No URLs to upload")
        return
    
    primary_account = get_primary_gdrive_account(user_id)
    if not primary_account:
        await update.callback_query.answer("No Google Drive account connected")
        return
    
    await update.callback_query.answer("Starting upload...")
    
    # Initialize progress message
    progress_message = f"📤 <b>Upload Progress</b>\n\n"
    progress_message += f"📋 Total files: {len(urls)}\n"
    progress_message += f"✅ Completed: 0\n"
    progress_message += f"❌ Failed: 0\n"
    progress_message += f"📊 Progress: 0%"
    
    progress_msg = await update.callback_query.edit_message_text(
        progress_message,
        parse_mode='HTML'
    )
    
    # Start upload process
    successful_uploads = []
    failed_uploads = []
    
    drive_manager = GoogleDriveManager(primary_account['credentials_json'])
    
    for i, url in enumerate(urls):
        try:
            # Update progress
            progress = ((i) / len(urls)) * 100
            updated_message = f"📤 <b>Upload Progress</b>\n\n"
            updated_message += f"📋 Total files: {len(urls)}\n"
            updated_message += f"✅ Completed: {len(successful_uploads)}\n"
            updated_message += f"❌ Failed: {len(failed_uploads)}\n"
            updated_message += f"📊 Progress: {progress:.1f}%\n\n"
            updated_message += f"🔄 Current: {os.path.basename(urlparse(url).path) or f'file_{i+1}'}"
            
            try:
                await progress_msg.edit_text(updated_message, parse_mode='HTML')
            except:
                pass
            
            # Download file from URL
            download_result = await download_file_from_url(url)
            if not download_result:
                failed_uploads.append({
                    'url': url,
                    'error': 'Download failed'
                })
                continue
            
            file_path, filename = download_result
            
            # Upload to Google Drive
            upload_result = drive_manager.upload_file(file_path, filename)
            if upload_result:
                successful_uploads.append({
                    'url': url,
                    'filename': filename,
                    'gdrive_id': upload_result['id'],
                    'gdrive_link': upload_result.get('webViewLink', '')
                })
                
                # Log successful upload
                log_activity(
                    user_id=user_id,
                    action="url_upload",
                    details=f"Uploaded from URL: {url}",
                    file_name=filename,
                    file_size=os.path.getsize(file_path),
                    gdrive_account_id=primary_account['id']
                )
            else:
                failed_uploads.append({
                    'url': url,
                    'error': 'Google Drive upload failed'
                })
            
            # Clean up temporary file
            try:
                os.remove(file_path)
            except:
                pass
            
        except Exception as e:
            logger.error(f"Error uploading URL {url}: {e}")
            failed_uploads.append({
                'url': url,
                'error': str(e)
            })
        
        # Small delay between uploads
        await asyncio.sleep(1)
    
    # Final result message
    result_message = f"📤 <b>Upload Completed!</b>\n\n"
    result_message += f"📋 Total files: {len(urls)}\n"
    result_message += f"✅ Successful: {len(successful_uploads)}\n"
    result_message += f"❌ Failed: {len(failed_uploads)}\n"
    result_message += f"📈 Success rate: {(len(successful_uploads)/len(urls)*100) if urls else 0:.1f}%\n\n"
    
    if successful_uploads:
        result_message += f"✅ <b>Successful uploads:</b>\n"
        for upload in successful_uploads[:3]:  # Show first 3
            result_message += f"📁 {upload['filename']}\n"
        
        if len(successful_uploads) > 3:
            result_message += f"... and {len(successful_uploads) - 3} more files\n"
    
    if failed_uploads:
        result_message += f"\n❌ <b>Failed uploads:</b>\n"
        for fail in failed_uploads[:2]:  # Show first 2
            result_message += f"🔗 {fail['url'][:30]}...\n"
            result_message += f"   Error: {fail['error']}\n"
    
    keyboard = [
        [InlineKeyboardButton("📊 View Details", callback_data="upload_view_details")],
        [InlineKeyboardButton("🔄 Upload More", callback_data="upload_urls")],
        [InlineKeyboardButton("🏠 Main Menu", callback_data="show_main_menu")]
    ]
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await progress_msg.edit_text(result_message, parse_mode='HTML', reply_markup=reply_markup)
    
    # Store results for detailed view
    context.user_data['last_upload_results'] = {
        'successful': successful_uploads,
        'failed': failed_uploads
    }
    
    # Clear upload data
    context.user_data.pop('upload_urls', None)
    context.user_data.pop('upload_mode', None)

async def handle_document_upload(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle document upload from user"""
    user_id = update.effective_user.id
    document = update.message.document
    
    # Check file size
    if document.file_size > Config.MAX_FILE_SIZE:
        await update.message.reply_text(
            f"❌ File terlalu besar!\n"
            f"📏 Size: {format_file_size(document.file_size)}\n"
            f"📏 Maximum: {format_file_size(Config.MAX_FILE_SIZE)}"
        )
        return
    
    # Get primary account
    primary_account = get_primary_gdrive_account(user_id)
    if not primary_account:
        await update.message.reply_text(
            "❌ Tidak ada akun Google Drive terhubung.\n"
            "Gunakan /gdrive untuk menghubungkan akun."
        )
        return
    
    # Start upload process
    file_emoji = get_file_type_emoji(document.file_name)
    upload_message = f"{file_emoji} <b>Uploading...</b>\n\n"
    upload_message += f"📁 {document.file_name}\n"
    upload_message += f"📏 {format_file_size(document.file_size)}\n"
    upload_message += f"📤 Uploading to Google Drive...\n\n"
    upload_message += create_progress_bar(0)
    
    progress_msg = await update.message.reply_text(upload_message, parse_mode='HTML')
    
    try:
        # Download file from Telegram
        file = await context.bot.get_file(document.file_id)
        file_path = os.path.join(Config.STORAGE_PATH, sanitize_filename(document.file_name))
        
        # Ensure storage directory exists
        os.makedirs(Config.STORAGE_PATH, exist_ok=True)
        
        await file.download_to_drive(file_path)
        
        # Update progress
        upload_message = f"{file_emoji} <b>Uploading...</b>\n\n"
        upload_message += f"📁 {document.file_name}\n"
        upload_message += f"📏 {format_file_size(document.file_size)}\n"
        upload_message += f"📤 Processing...\n\n"
        upload_message += create_progress_bar(50)
        
        await progress_msg.edit_text(upload_message, parse_mode='HTML')
        
        # Upload to Google Drive
        drive_manager = GoogleDriveManager(primary_account['credentials_json'])
        upload_result = drive_manager.upload_file(file_path, document.file_name)
        
        if upload_result:
            # Success
            success_message = f"✅ <b>Upload Berhasil!</b>\n\n"
            success_message += f"{file_emoji} {document.file_name}\n"
            success_message += f"📏 {format_file_size(document.file_size)}\n"
            success_message += f"📧 Account: {primary_account['account_email']}\n"
            success_message += f"🔗 GDrive ID: <code>{upload_result['id']}</code>\n\n"
            success_message += f"📈 Upload completed successfully!"
            
            keyboard = []
            if upload_result.get('webViewLink'):
                keyboard.append([InlineKeyboardButton("🔗 Open in GDrive", url=upload_result['webViewLink'])])
            
            keyboard.extend([
                [InlineKeyboardButton("📤 Share", callback_data=f"share_file_{upload_result['id']}")],
                [InlineKeyboardButton("📤 Upload More", callback_data="upload_direct")]
            ])
            
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            await progress_msg.edit_text(success_message, parse_mode='HTML', reply_markup=reply_markup)
            
            # Log successful upload
            log_activity(
                user_id=user_id,
                action="document_upload",
                details=f"Uploaded document: {document.file_name}",
                file_name=document.file_name,
                file_size=document.file_size,
                gdrive_account_id=primary_account['id']
            )
            
        else:
            # Upload failed - try auto-switch
            switched = await auto_switch_account(user_id)
            if switched:
                await update.message.reply_text(
                    "🔄 Quota penuh! Auto-switching ke akun lain...\n"
                    "Silakan coba upload ulang."
                )
            else:
                await progress_msg.edit_text(
                    "❌ Upload gagal ke Google Drive.\n"
                    "Semua akun mungkin penuh atau error."
                )
        
        # Clean up temporary file
        try:
            os.remove(file_path)
        except:
            pass
            
    except Exception as e:
        logger.error(f"Error uploading document: {e}")
        await progress_msg.edit_text(
            f"❌ <b>Upload Error</b>\n\n"
            f"Error: {str(e)}\n"
            f"Silakan coba lagi atau hubungi admin."
        )

async def handle_photo_upload(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle photo upload from user"""
    user_id = update.effective_user.id
    photo = update.message.photo[-1]  # Get highest resolution
    
    # Generate filename
    filename = f"photo_{photo.file_id}.jpg"
    
    await _handle_media_upload(update, context, photo, filename, "🖼️")

async def handle_video_upload(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle video upload from user"""
    user_id = update.effective_user.id
    video = update.message.video
    
    filename = video.file_name or f"video_{video.file_id}.mp4"
    
    await _handle_media_upload(update, context, video, filename, "🎥")

async def _handle_media_upload(update: Update, context: ContextTypes.DEFAULT_TYPE, 
                             media, filename: str, emoji: str):
    """Generic media upload handler"""
    user_id = update.effective_user.id
    
    # Check file size
    if media.file_size > Config.MAX_FILE_SIZE:
        await update.message.reply_text(
            f"❌ File terlalu besar!\n"
            f"📏 Size: {format_file_size(media.file_size)}\n"
            f"📏 Maximum: {format_file_size(Config.MAX_FILE_SIZE)}"
        )
        return
    
    # Get primary account
    primary_account = get_primary_gdrive_account(user_id)
    if not primary_account:
        await update.message.reply_text(
            "❌ Tidak ada akun Google Drive terhubung.\n"
            "Gunakan menu untuk menghubungkan akun."
        )
        return
    
    # Start upload process
    upload_message = f"{emoji} <b>Uploading Media...</b>\n\n"
    upload_message += f"📁 {filename}\n"
    upload_message += f"📏 {format_file_size(media.file_size)}\n"
    upload_message += f"📤 Processing...\n\n"
    upload_message += create_progress_bar(0)
    
    progress_msg = await update.message.reply_text(upload_message, parse_mode='HTML')
    
    try:
        # Download file from Telegram
        file = await context.bot.get_file(media.file_id)
        file_path = os.path.join(Config.STORAGE_PATH, sanitize_filename(filename))
        
        # Ensure storage directory exists
        os.makedirs(Config.STORAGE_PATH, exist_ok=True)
        
        await file.download_to_drive(file_path)
        
        # Update progress
        upload_message = f"{emoji} <b>Uploading Media...</b>\n\n"
        upload_message += f"📁 {filename}\n"
        upload_message += f"📏 {format_file_size(media.file_size)}\n"
        upload_message += f"📤 Uploading to Google Drive...\n\n"
        upload_message += create_progress_bar(75)
        
        await progress_msg.edit_text(upload_message, parse_mode='HTML')
        
        # Upload to Google Drive
        drive_manager = GoogleDriveManager(primary_account['credentials_json'])
        upload_result = drive_manager.upload_file(file_path, filename)
        
        if upload_result:
            # Success
            success_message = f"✅ <b>Upload Berhasil!</b>\n\n"
            success_message += f"{emoji} {filename}\n"
            success_message += f"📏 {format_file_size(media.file_size)}\n"
            success_message += f"📧 Account: {primary_account['account_email']}\n\n"
            
            if emoji == "🎥":
                success_message += f"📽️ Video ready for streaming!"
            elif emoji == "🖼️":
                success_message += f"🖼️ Image uploaded successfully!"
            
            keyboard = []
            if upload_result.get('webViewLink'):
                keyboard.append([InlineKeyboardButton("🔗 Open in GDrive", url=upload_result['webViewLink'])])
            
            if emoji == "🎥":
                keyboard.append([InlineKeyboardButton("📽️ Stream Video", callback_data=f"gdrive_stream_{upload_result['id']}")])
            
            keyboard.extend([
                [InlineKeyboardButton("📤 Share", callback_data=f"share_file_{upload_result['id']}")],
                [InlineKeyboardButton("📤 Upload More", callback_data="upload_direct")]
            ])
            
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            await progress_msg.edit_text(success_message, parse_mode='HTML', reply_markup=reply_markup)
            
            # Log successful upload
            log_activity(
                user_id=user_id,
                action="media_upload",
                details=f"Uploaded {emoji} media: {filename}",
                file_name=filename,
                file_size=media.file_size,
                gdrive_account_id=primary_account['id']
            )
            
        else:
            # Try auto-switch if upload failed
            switched = await auto_switch_account(user_id)
            if switched:
                await update.message.reply_text(
                    "🔄 Quota penuh! Auto-switching ke akun lain...\n"
                    "Silakan coba upload ulang."
                )
            else:
                await progress_msg.edit_text(
                    "❌ Upload gagal ke Google Drive.\n"
                    "Semua akun mungkin penuh atau error."
                )
        
        # Clean up temporary file
        try:
            os.remove(file_path)
        except:
            pass
            
    except Exception as e:
        logger.error(f"Error uploading media: {e}")
        await progress_msg.edit_text(
            f"❌ <b>Upload Error</b>\n\n"
            f"Error: {str(e)}\n"
            f"Silakan coba lagi atau hubungi admin."
        )

async def download_file_from_url(url: str):
    """Download file from URL"""
    try:
        # Get filename from URL
        parsed_url = urlparse(url)
        filename = os.path.basename(parsed_url.path)
        
        if not filename or '.' not in filename:
            filename = f"download_{hash(url) % 10000}"
        
        filename = sanitize_filename(filename)
        
        # Download file
        response = requests.get(url, stream=True, timeout=30)
        response.raise_for_status()
        
        # Save to storage
        file_path = os.path.join(Config.STORAGE_PATH, filename)
        
        with open(file_path, 'wb') as f:
            for chunk in response.iter_content(chunk_size=8192):
                f.write(chunk)
        
        return file_path, filename
        
    except Exception as e:
        logger.error(f"Error downloading from URL {url}: {e}")
        return None

async def show_upload_history(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show upload history"""
    user_id = update.effective_user.id
    
    from database import get_user_logs
    logs = get_user_logs(user_id, limit=10)
    
    # Filter upload logs
    upload_logs = [log for log in logs if 'upload' in log.get('action', '').lower()]
    
    history_message = f"📊 <b>Upload History</b>\n\n"
    
    if not upload_logs:
        history_message += "📝 Belum ada riwayat upload."
    else:
        history_message += f"📋 Recent uploads ({len(upload_logs)}):\n\n"
        
        for log in upload_logs[:5]:
            emoji = get_file_type_emoji(log.get('file_name', ''))
            timestamp = log['created_at'][:16]  # YYYY-MM-DD HH:MM
            filename = log.get('file_name', 'Unknown')[:20]
            size = format_file_size(log.get('file_size', 0)) if log.get('file_size') else 'N/A'
            status = "✅" if log.get('status') == 'success' else "❌"
            
            history_message += f"{status} {emoji} {filename}\n"
            history_message += f"   📅 {timestamp} | 📏 {size}\n\n"
    
    keyboard = [
        [InlineKeyboardButton("🔄 Refresh", callback_data="upload_history")],
        [InlineKeyboardButton("📤 Upload More", callback_data="upload_urls")],
        [InlineKeyboardButton("🔙 Back", callback_data="upload_menu")]
    ]
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    if update.callback_query:
        await update.callback_query.edit_message_text(
            history_message,
            parse_mode='HTML',
            reply_markup=reply_markup
        )
    else:
        await update.message.reply_text(
            history_message,
            parse_mode='HTML',
            reply_markup=reply_markup
        )

async def handle_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle upload-related callbacks"""
    query = update.callback_query
    data = query.data
    
    if data == "upload_menu":
        await show_upload_menu(update, context)
    elif data == "upload_urls":
        await start_url_upload(update, context)
    elif data == "upload_batch_urls":
        await start_batch_url_upload(update, context)
    elif data == "upload_direct":
        await show_direct_upload_info(update, context)
    elif data == "upload_confirm":
        await execute_url_upload(update, context)
    elif data == "upload_cancel":
        context.user_data.pop('upload_urls', None)
        context.user_data.pop('upload_mode', None)
        await update.callback_query.edit_message_text(
            "❌ Upload dibatalkan.",
            reply_markup=InlineKeyboardMarkup([[
                InlineKeyboardButton("🔙 Back to Upload", callback_data="upload_menu")
            ]])
        )
    elif data == "upload_history":
        await show_upload_history(update, context)
    elif data == "upload_settings":
        await show_upload_settings(update, context)

async def show_direct_upload_info(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show information about direct upload"""
    info_message = (
        f"📁 <b>Direct Upload</b>\n\n"
        f"📤 <b>Cara Upload:</b>\n"
        f"1️⃣ Kirim file langsung ke chat ini\n"
        f"2️⃣ Bot akan otomatis upload ke GDrive\n"
        f"3️⃣ Progress ditampilkan real-time\n"
        f"4️⃣ Link GDrive dikirim setelah selesai\n\n"
        f"✅ <b>Supported Types:</b>\n"
        f"📄 Documents (PDF, DOC, TXT, etc.)\n"
        f"🖼️ Images (JPG, PNG, GIF, etc.)\n"
        f"🎥 Videos (MP4, AVI, MKV, etc.)\n"
        f"🎵 Audio (MP3, WAV, etc.)\n"
        f"📦 Archives (ZIP, RAR, etc.)\n\n"
        f"📏 <b>Limits:</b>\n"
        f"• Max size: {format_file_size(Config.MAX_FILE_SIZE)}\n"
        f"• Max per hour: {Config.MAX_UPLOADS_PER_HOUR}\n\n"
        f"💡 <b>Tips:</b>\n"
        f"• File akan auto-upload ke akun primary\n"
        f"• Auto-switch jika quota penuh\n"
        f"• Progress bar real-time\n"
        f"• Streaming ready untuk video"
    )
    
    keyboard = [
        [InlineKeyboardButton("📤 Start Uploading", callback_data="upload_ready")],
        [InlineKeyboardButton("🔙 Back", callback_data="upload_menu")]
    ]
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.callback_query.edit_message_text(
        info_message,
        parse_mode='HTML',
        reply_markup=reply_markup
    )

async def show_upload_settings(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show upload settings"""
    settings_message = (
        f"⚙️ <b>Upload Settings</b>\n\n"
        f"📊 <b>Current Settings:</b>\n"
        f"📏 Max file size: {format_file_size(Config.MAX_FILE_SIZE)}\n"
        f"📈 Max uploads/hour: {Config.MAX_UPLOADS_PER_HOUR}\n"
        f"🔄 Auto-switch accounts: Enabled\n"
        f"📱 Progress notifications: Enabled\n"
        f"🗂️ Auto-organize: Disabled\n\n"
        f"🎯 <b>Upload Preferences:</b>\n"
        f"📁 Default folder: Root\n"
        f"🏷️ Auto-tagging: Disabled\n"
        f"🔐 Privacy mode: Normal\n"
        f"💾 Keep local copy: Disabled"
    )
    
    keyboard = [
        [
            InlineKeyboardButton("🔄 Toggle Auto-Switch", callback_data="setting_auto_switch"),
            InlineKeyboardButton("📁 Set Default Folder", callback_data="setting_default_folder")
        ],
        [
            InlineKeyboardButton("🏷️ Auto-Tagging", callback_data="setting_auto_tag"),
            InlineKeyboardButton("📱 Notifications", callback_data="setting_notifications")
        ],
        [InlineKeyboardButton("🔙 Back", callback_data="upload_menu")]
    ]
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.callback_query.edit_message_text(
        settings_message,
        parse_mode='HTML',
        reply_markup=reply_markup
    )
