"""
TelegramDriveSync Bot - Contact Admin Handler
Hubungi admin, proxy chat end-to-end, ticket log
"""

import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, ReplyKeyboardMarkup, KeyboardButton
from telegram.ext import ContextTypes, ConversationHandler, MessageHandler, filters
from database import (
    create_support_ticket, add_support_message, get_user_tickets, 
    get_ticket_messages, log_activity, get_user_by_id
)
from config import Config
from utils import paginate_items, create_pagination_keyboard, format_ticket_info, get_time_ago
from datetime import datetime
import uuid

logger = logging.getLogger(__name__)

# Contact conversation states
CONTACT_CATEGORY, CONTACT_MESSAGE, CONTACT_REPLY = range(3)

# Contact categories
CONTACT_CATEGORIES = {
    'technical': {
        'title': '🔧 Technical Issue',
        'description': 'Bot errors, upload problems, OAuth issues'
    },
    'payment': {
        'title': '💳 Payment Support',
        'description': 'Payment problems, refunds, billing questions'
    },
    'feature': {
        'title': '💡 Feature Request',
        'description': 'Suggest new features or improvements'
    },
    'group': {
        'title': '📢 Group Request',
        'description': 'Add bot to group, group management'
    },
    'account': {
        'title': '👤 Account Issues',
        'description': 'Profile problems, Google Drive issues'
    },
    'general': {
        'title': '❓ General Question',
        'description': 'Any other questions or feedback'
    }
}

async def start_contact_admin(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Start contact admin process"""
    user_id = update.effective_user.id
    
    # Check if there's a specific reason from previous context
    contact_reason = context.user_data.get('contact_reason')
    
    contact_message = (
        f"💬 <b>Contact Admin Support</b>\n\n"
        f"👋 Hello {update.effective_user.first_name}!\n\n"
        f"🎯 <b>Support Features:</b>\n"
        f"🎫 Ticket system for tracking\n"
        f"🔄 Real-time admin responses\n"
        f"📝 Chat history preservation\n"
        f"🏷️ Category-based routing\n"
        f"⚡ Priority support for premium users\n\n"
        f"📋 <b>How it works:</b>\n"
        f"1️⃣ Choose your issue category\n"
        f"2️⃣ Describe your problem/question\n"
        f"3️⃣ Get instant ticket ID\n"
        f"4️⃣ Receive admin response here\n"
        f"5️⃣ Continue conversation as needed\n\n"
        f"💡 <b>Tips for faster support:</b>\n"
        f"• Be specific about your issue\n"
        f"• Include error messages if any\n"
        f"• Mention what you were trying to do\n"
        f"• Attach screenshots if helpful"
    )
    
    # If there's a specific reason, auto-select category
    if contact_reason == 'payment_issue':
        context.user_data['contact_category'] = 'payment'
        await start_contact_message(update, context)
        return CONTACT_MESSAGE
    
    keyboard = []
    
    # Category buttons
    for category_id, category_info in CONTACT_CATEGORIES.items():
        keyboard.append([InlineKeyboardButton(
            category_info['title'],
            callback_data=f"contact_category_{category_id}"
        )])
    
    # Additional options
    keyboard.extend([
        [InlineKeyboardButton("📋 My Tickets", callback_data="contact_my_tickets")],
        [InlineKeyboardButton("❌ Cancel", callback_data="contact_cancel")]
    ])
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    if update.callback_query:
        await update.callback_query.edit_message_text(
            contact_message,
            parse_mode='HTML',
            reply_markup=reply_markup
        )
    else:
        await update.message.reply_text(
            contact_message,
            parse_mode='HTML',
            reply_markup=reply_markup
        )
    
    return CONTACT_CATEGORY

async def select_contact_category(update: Update, context: ContextTypes.DEFAULT_TYPE, category: str):
    """Select contact category"""
    category_info = CONTACT_CATEGORIES.get(category)
    
    if not category_info:
        await update.callback_query.answer("❌ Invalid category")
        return
    
    context.user_data['contact_category'] = category
    
    category_message = (
        f"🏷️ <b>Category Selected</b>\n\n"
        f"📂 <b>{category_info['title']}</b>\n"
        f"📝 {category_info['description']}\n\n"
        f"💡 <b>For {category_info['title'].lower()}:</b>\n"
    )
    
    # Category-specific tips
    if category == 'technical':
        category_message += (
            f"• Describe the exact error message\n"
            f"• Mention what you were doing when it happened\n"
            f"• Include bot response screenshots\n"
            f"• Specify if it's upload, OAuth, or other feature"
        )
    elif category == 'payment':
        category_message += (
            f"• Include payment ID if you have it\n"
            f"• Mention payment method used\n"
            f"• Describe the specific issue\n"
            f"• Include transaction screenshots if needed"
        )
    elif category == 'feature':
        category_message += (
            f"• Explain the feature you'd like to see\n"
            f"• Describe how it would help you\n"
            f"• Mention if you've seen it in other bots\n"
            f"• Be specific about functionality"
        )
    elif category == 'group':
        category_message += (
            f"• Provide group ID or username\n"
            f"• Explain the group's purpose\n"
            f"• Mention how many members\n"
            f"• Describe intended bot usage"
        )
    elif category == 'account':
        category_message += (
            f"• Describe the specific account issue\n"
            f"• Mention if it's subscription or OAuth related\n"
            f"• Include any error messages\n"
            f"• Specify what's not working"
        )
    else:  # general
        category_message += (
            f"• Be as detailed as possible\n"
            f"• Include relevant context\n"
            f"• Mention your goal or what you're trying to achieve\n"
            f"• Ask specific questions"
        )
    
    category_message += f"\n\n✍️ <i>Now, please describe your {category_info['title'].lower()}:</i>"
    
    keyboard = [
        [InlineKeyboardButton("🔙 Change Category", callback_data="contact_start")],
        [InlineKeyboardButton("❌ Cancel", callback_data="contact_cancel")]
    ]
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.callback_query.edit_message_text(
        category_message,
        parse_mode='HTML',
        reply_markup=reply_markup
    )
    
    return CONTACT_MESSAGE

async def start_contact_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Start message input for contact"""
    category = context.user_data.get('contact_category', 'general')
    category_info = CONTACT_CATEGORIES.get(category, CONTACT_CATEGORIES['general'])
    
    message_prompt = (
        f"✍️ <b>Describe Your {category_info['title']}</b>\n\n"
        f"📝 Please type your message describing your issue, question, or request.\n\n"
        f"💡 <b>Include:</b>\n"
        f"• Detailed description\n"
        f"• What you expected to happen\n"
        f"• What actually happened\n"
        f"• Any error messages\n"
        f"• Steps you've already tried\n\n"
        f"📎 You can also send:\n"
        f"• Screenshots of errors\n"
        f"• Files related to the issue\n"
        f"• Multiple messages if needed\n\n"
        f"🎫 A support ticket will be created automatically.\n\n"
        f"<i>Type your message below:</i>"
    )
    
    # Use reply keyboard for easier typing
    keyboard = [
        [KeyboardButton("❌ Cancel Contact")]
    ]
    reply_markup = ReplyKeyboardMarkup(keyboard, resize_keyboard=True, one_time_keyboard=True)
    
    if update.callback_query:
        await update.callback_query.edit_message_text(
            message_prompt,
            parse_mode='HTML'
        )
        await update.callback_query.message.reply_text(
            "👇 Use the keyboard below or type your message:",
            reply_markup=reply_markup
        )
    else:
        await update.message.reply_text(
            message_prompt,
            parse_mode='HTML',
            reply_markup=reply_markup
        )
    
    return CONTACT_MESSAGE

async def handle_contact_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle contact message from user"""
    user_id = update.effective_user.id
    message_text = update.message.text
    
    if message_text == "❌ Cancel Contact" or message_text == "/cancel":
        await update.message.reply_text(
            "❌ Contact process cancelled.",
            reply_markup=None
        )
        return ConversationHandler.END
    
    category = context.user_data.get('contact_category', 'general')
    category_info = CONTACT_CATEGORIES.get(category, CONTACT_CATEGORIES['general'])
    
    try:
        # Create support ticket
        ticket_id = create_support_ticket(
            user_id=user_id,
            category=category,
            subject=category_info['title']
        )
        
        if not ticket_id:
            raise Exception("Failed to create support ticket")
        
        # Add initial message
        message_id = add_support_message(
            ticket_id=ticket_id,
            sender_id=user_id,
            sender_type='user',
            message_text=message_text
        )
        
        if not message_id:
            raise Exception("Failed to save support message")
        
        # Store ticket ID in context for follow-up messages
        context.user_data['active_ticket_id'] = ticket_id
        
        # Get user info for admin notification
        user_info = get_user_by_id(user_id)
        user_name = user_info.get('first_name', 'Unknown') if user_info else 'Unknown'
        user_username = f"@{user_info.get('username')}" if user_info and user_info.get('username') else "No username"
        
        # Success message to user
        success_message = (
            f"🎫 <b>Support Ticket Created!</b>\n\n"
            f"✅ <b>Ticket ID:</b> <code>{ticket_id}</code>\n"
            f"🏷️ <b>Category:</b> {category_info['title']}\n"
            f"📅 <b>Created:</b> {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n"
            f"💬 <b>Your message has been sent to admins!</b>\n\n"
            f"🔔 <b>What happens next:</b>\n"
            f"• Admins will receive your message\n"
            f"• You'll get responses right here in this chat\n"
            f"• Continue the conversation as needed\n"
            f"• Your ticket is tracked until resolved\n\n"
            f"⏰ <b>Response time:</b>\n"
            f"• Premium users: Within 1 hour\n"
            f"• Free users: Within 24 hours\n"
            f"• Urgent issues: Immediate attention\n\n"
            f"💡 You can continue typing messages - they'll be added to this ticket automatically."
        )
        
        keyboard = [
            [
                InlineKeyboardButton("📋 View Ticket", callback_data=f"contact_view_ticket_{ticket_id}"),
                InlineKeyboardButton("📝 My Tickets", callback_data="contact_my_tickets")
            ],
            [InlineKeyboardButton("🏠 Main Menu", callback_data="show_main_menu")]
        ]
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await update.message.reply_text(
            success_message,
            parse_mode='HTML',
            reply_markup=reply_markup
        )
        
        # Notify all admins about new ticket
        admin_notification = (
            f"🎫 <b>New Support Ticket</b>\n\n"
            f"🆔 <b>Ticket:</b> <code>{ticket_id}</code>\n"
            f"👤 <b>User:</b> {user_name} ({user_id})\n"
            f"📝 <b>Username:</b> {user_username}\n"
            f"🏷️ <b>Category:</b> {category_info['title']}\n"
            f"💳 <b>Status:</b> {'Premium' if user_info and user_info.get('is_paid') else 'Free'}\n"
            f"📅 <b>Created:</b> {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n"
            f"💬 <b>Message:</b>\n{message_text}\n\n"
            f"Reply to this message to respond to the user."
        )
        
        keyboard = [
            [InlineKeyboardButton("💬 Reply", callback_data=f"admin_reply_ticket_{ticket_id}")],
            [InlineKeyboardButton("📋 View Full Ticket", callback_data=f"admin_view_ticket_{ticket_id}")],
            [InlineKeyboardButton("✅ Mark Resolved", callback_data=f"admin_resolve_ticket_{ticket_id}")]
        ]
        
        admin_reply_markup = InlineKeyboardMarkup(keyboard)
        
        for admin_id in Config.ADMIN_IDS:
            try:
                await context.bot.send_message(
                    chat_id=admin_id,
                    text=admin_notification,
                    parse_mode='HTML',
                    reply_markup=admin_reply_markup
                )
            except Exception as e:
                logger.error(f"Failed to notify admin {admin_id} about ticket {ticket_id}: {e}")
        
        # Log ticket creation
        log_activity(
            user_id=user_id,
            action="ticket_created",
            details=f"Created support ticket {ticket_id} - Category: {category}"
        )
        
        # Set state to receive follow-up messages
        context.user_data['awaiting_contact_message'] = True
        return CONTACT_REPLY
        
    except Exception as e:
        logger.error(f"Error creating support ticket for user {user_id}: {e}")
        
        error_message = (
            f"❌ <b>Failed to Create Ticket</b>\n\n"
            f"Sorry, there was an error creating your support ticket.\n\n"
            f"🔄 <b>Please try again or:</b>\n"
            f"• Wait a moment and retry\n"
            f"• Contact admin directly if urgent\n"
            f"• Check your internet connection"
        )
        
        keyboard = [
            [InlineKeyboardButton("🔄 Try Again", callback_data="contact_start")],
            [InlineKeyboardButton("🏠 Main Menu", callback_data="show_main_menu")]
        ]
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await update.message.reply_text(
            error_message,
            parse_mode='HTML',
            reply_markup=reply_markup
        )
        
        return ConversationHandler.END

async def handle_follow_up_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle follow-up messages in active ticket"""
    user_id = update.effective_user.id
    message_text = update.message.text
    ticket_id = context.user_data.get('active_ticket_id')
    
    if not ticket_id:
        # No active ticket, treat as regular message
        return
    
    if message_text == "/cancel" or message_text == "❌ Cancel Contact":
        context.user_data.pop('active_ticket_id', None)
        context.user_data.pop('awaiting_contact_message', None)
        await update.message.reply_text(
            "✅ Conversation ended. Your ticket remains open for admin responses.",
            reply_markup=None
        )
        return ConversationHandler.END
    
    try:
        # Add message to ticket
        message_id = add_support_message(
            ticket_id=ticket_id,
            sender_id=user_id,
            sender_type='user',
            message_text=message_text
        )
        
        if message_id:
            # Confirm message received
            await update.message.reply_text(
                f"✅ Message added to ticket <code>{ticket_id}</code>\n"
                f"Admins will be notified of your update.",
                parse_mode='HTML'
            )
            
            # Notify admins of follow-up message
            user_info = get_user_by_id(user_id)
            user_name = user_info.get('first_name', 'Unknown') if user_info else 'Unknown'
            
            admin_notification = (
                f"💬 <b>Ticket Update</b>\n\n"
                f"🆔 <b>Ticket:</b> <code>{ticket_id}</code>\n"
                f"👤 <b>User:</b> {user_name} ({user_id})\n"
                f"📅 <b>Time:</b> {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n"
                f"💬 <b>New Message:</b>\n{message_text}"
            )
            
            keyboard = [
                [InlineKeyboardButton("💬 Reply", callback_data=f"admin_reply_ticket_{ticket_id}")],
                [InlineKeyboardButton("📋 View Ticket", callback_data=f"admin_view_ticket_{ticket_id}")]
            ]
            
            admin_reply_markup = InlineKeyboardMarkup(keyboard)
            
            for admin_id in Config.ADMIN_IDS:
                try:
                    await context.bot.send_message(
                        chat_id=admin_id,
                        text=admin_notification,
                        parse_mode='HTML',
                        reply_markup=admin_reply_markup
                    )
                except Exception as e:
                    logger.error(f"Failed to notify admin {admin_id} about ticket update {ticket_id}: {e}")
        
        else:
            await update.message.reply_text(
                "❌ Failed to add message to ticket. Please try again."
            )
        
    except Exception as e:
        logger.error(f"Error handling follow-up message for ticket {ticket_id}: {e}")
        await update.message.reply_text(
            "❌ Error processing your message. Please try again."
        )

async def handle_user_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle messages when user is in contact admin flow"""
    # Check if user is in contact flow
    if context.user_data.get('awaiting_contact_message'):
        await handle_follow_up_message(update, context)
    else:
        # Regular message handling
        pass

async def show_user_tickets(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show user's support tickets"""
    user_id = update.effective_user.id
    page = context.user_data.get('tickets_page', 1)
    
    tickets = get_user_tickets(user_id, limit=20)
    paginated_tickets, pagination_info = paginate_items(tickets, page, 5)
    
    tickets_message = f"📋 <b>My Support Tickets</b>\n\n"
    
    if not tickets:
        tickets_message += (
            f"📝 You haven't created any support tickets yet.\n\n"
            f"Use the 'Contact Admin' feature to get help with any issues."
        )
        
        keyboard = [
            [InlineKeyboardButton("💬 Contact Admin", callback_data="contact_start")],
            [InlineKeyboardButton("🏠 Main Menu", callback_data="show_main_menu")]
        ]
    else:
        tickets_message += f"📊 Total tickets: {len(tickets)}\n"
        tickets_message += f"📋 Page {pagination_info['current_page']}/{pagination_info['total_pages']}\n\n"
        
        for ticket in paginated_tickets:
            ticket_info = format_ticket_info(ticket)
            tickets_message += f"{ticket_info}\n\n"
        
        # Create keyboard
        keyboard = []
        
        # Ticket action buttons
        for ticket in paginated_tickets:
            keyboard.append([InlineKeyboardButton(
                f"📋 Ticket #{ticket['ticket_id']}",
                callback_data=f"contact_view_ticket_{ticket['ticket_id']}"
            )])
        
        # Pagination
        if pagination_info['total_pages'] > 1:
            pagination_keyboard = create_pagination_keyboard('contact_tickets', 
                                                           pagination_info['current_page'],
                                                           pagination_info['total_pages'])
            keyboard.extend(pagination_keyboard.inline_keyboard)
        
        # Action buttons
        keyboard.extend([
            [InlineKeyboardButton("💬 New Ticket", callback_data="contact_start")],
            [InlineKeyboardButton("🔄 Refresh", callback_data="contact_my_tickets")],
            [InlineKeyboardButton("🏠 Main Menu", callback_data="show_main_menu")]
        ])
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    if update.callback_query:
        await update.callback_query.edit_message_text(
            tickets_message,
            parse_mode='HTML',
            reply_markup=reply_markup
        )
    else:
        await update.message.reply_text(
            tickets_message,
            parse_mode='HTML',
            reply_markup=reply_markup
        )

async def show_ticket_details(update: Update, context: ContextTypes.DEFAULT_TYPE, ticket_id: str):
    """Show detailed ticket information and messages"""
    user_id = update.effective_user.id
    
    # Get ticket messages
    messages = get_ticket_messages(ticket_id)
    
    if not messages:
        await update.callback_query.answer("❌ Ticket not found or no messages")
        return
    
    # Verify user owns this ticket
    first_message = messages[0]
    if first_message['sender_id'] != user_id and user_id not in Config.ADMIN_IDS:
        await update.callback_query.answer("❌ Access denied")
        return
    
    ticket_details = f"🎫 <b>Ticket #{ticket_id}</b>\n\n"
    
    # Show conversation
    ticket_details += f"💬 <b>Conversation:</b>\n\n"
    
    for message in messages:
        sender_type = message['sender_type']
        sender_id = message['sender_id']
        message_text = message['message_text']
        timestamp = datetime.fromisoformat(message['created_at']).strftime('%m/%d %H:%M')
        
        if sender_type == 'user':
            if sender_id == user_id:
                sender_name = "You"
            else:
                sender_name = f"User {sender_id}"
            emoji = "👤"
        else:  # admin
            sender_name = "Admin"
            emoji = "👑"
        
        ticket_details += f"{emoji} <b>{sender_name}</b> ({timestamp}):\n"
        ticket_details += f"{message_text}\n\n"
    
    # If conversation is long, truncate
    if len(ticket_details) > 3000:
        ticket_details = ticket_details[:3000] + "...\n\n[Conversation truncated - use full view for complete history]"
    
    keyboard = []
    
    # User can add more messages if ticket is still open
    if user_id not in Config.ADMIN_IDS:  # Regular user
        keyboard.extend([
            [InlineKeyboardButton("💬 Add Message", callback_data=f"contact_add_message_{ticket_id}")],
            [InlineKeyboardButton("📋 My Tickets", callback_data="contact_my_tickets")],
            [InlineKeyboardButton("🏠 Main Menu", callback_data="show_main_menu")]
        ])
    else:  # Admin view
        keyboard.extend([
            [InlineKeyboardButton("💬 Reply", callback_data=f"admin_reply_ticket_{ticket_id}")],
            [InlineKeyboardButton("✅ Resolve", callback_data=f"admin_resolve_ticket_{ticket_id}")],
            [InlineKeyboardButton("🔙 Back", callback_data="admin_tickets")]
        ])
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.callback_query.edit_message_text(
        ticket_details,
        parse_mode='HTML',
        reply_markup=reply_markup
    )

async def add_message_to_ticket(update: Update, context: ContextTypes.DEFAULT_TYPE, ticket_id: str):
    """Add new message to existing ticket"""
    context.user_data['active_ticket_id'] = ticket_id
    context.user_data['awaiting_contact_message'] = True
    
    add_message_prompt = (
        f"💬 <b>Add Message to Ticket #{ticket_id}</b>\n\n"
        f"✍️ Type your additional message or question below.\n\n"
        f"This will be added to your existing support ticket and admins will be notified.\n\n"
        f"<i>Type your message:</i>"
    )
    
    keyboard = [
        [KeyboardButton("❌ Cancel")]
    ]
    reply_markup = ReplyKeyboardMarkup(keyboard, resize_keyboard=True, one_time_keyboard=True)
    
    await update.callback_query.edit_message_text(
        add_message_prompt,
        parse_mode='HTML'
    )
    
    await update.callback_query.message.reply_text(
        "👇 Type your message below:",
        reply_markup=reply_markup
    )
    
    return CONTACT_REPLY

async def cancel_contact(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Cancel contact process"""
    # Clear contact-related data
    context.user_data.pop('contact_category', None)
    context.user_data.pop('active_ticket_id', None)
    context.user_data.pop('awaiting_contact_message', None)
    context.user_data.pop('contact_reason', None)
    
    await update.callback_query.edit_message_text(
        "❌ Contact process cancelled.\n\n"
        "You can start a new support request anytime.",
        reply_markup=InlineKeyboardMarkup([[
            InlineKeyboardButton("💬 Contact Admin", callback_data="contact_start"),
            InlineKeyboardButton("🏠 Main Menu", callback_data="show_main_menu")
        ]])
    )

async def handle_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle contact admin callback queries"""
    query = update.callback_query
    data = query.data
    
    if data == "contact_start" or data == "contact_admin_start":
        await start_contact_admin(update, context)
    elif data.startswith("contact_category_"):
        category = data.split("_", 2)[2]
        await select_contact_category(update, context, category)
    elif data == "contact_my_tickets":
        await show_user_tickets(update, context)
    elif data.startswith("contact_tickets_page_"):
        page = int(data.split("_")[-1])
        context.user_data['tickets_page'] = page
        await show_user_tickets(update, context)
    elif data.startswith("contact_view_ticket_"):
        ticket_id = data.split("_", 3)[3]
        await show_ticket_details(update, context, ticket_id)
    elif data.startswith("contact_add_message_"):
        ticket_id = data.split("_", 3)[3]
        await add_message_to_ticket(update, context, ticket_id)
    elif data == "contact_cancel":
        await cancel_contact(update, context)

def get_conversation_handler():
    """Get conversation handler for contact admin process"""
    return ConversationHandler(
        entry_points=[],
        states={
            CONTACT_CATEGORY: [],
            CONTACT_MESSAGE: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, handle_contact_message)
            ],
            CONTACT_REPLY: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, handle_follow_up_message)
            ]
        },
        fallbacks=[
            MessageHandler(filters.Regex("^/cancel$"), cancel_contact),
            MessageHandler(filters.Regex("^❌ Cancel"), cancel_contact)
        ],
        allow_reentry=True
    )

# Admin-side functions for handling ticket responses

async def admin_reply_to_ticket(update: Update, context: ContextTypes.DEFAULT_TYPE, ticket_id: str):
    """Admin reply to support ticket"""
    admin_id = update.effective_user.id
    
    if admin_id not in Config.ADMIN_IDS:
        await update.callback_query.answer("❌ Admin access required")
        return
    
    context.user_data['admin_replying_ticket'] = ticket_id
    
    reply_prompt = (
        f"💬 <b>Reply to Ticket #{ticket_id}</b>\n\n"
        f"✍️ Type your response to the user.\n\n"
        f"💡 <b>Tips:</b>\n"
        f"• Be helpful and specific\n"
        f"• Provide clear instructions\n"
        f"• Ask for clarification if needed\n"
        f"• Be professional and friendly\n\n"
        f"<i>Type your reply:</i>"
    )
    
    keyboard = [
        [KeyboardButton("❌ Cancel Reply")]
    ]
    reply_markup = ReplyKeyboardMarkup(keyboard, resize_keyboard=True, one_time_keyboard=True)
    
    await update.callback_query.edit_message_text(
        reply_prompt,
        parse_mode='HTML'
    )
    
    await update.callback_query.message.reply_text(
        "👇 Type your admin response:",
        reply_markup=reply_markup
    )

async def handle_admin_ticket_reply(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle admin reply to ticket"""
    admin_id = update.effective_user.id
    reply_text = update.message.text
    ticket_id = context.user_data.get('admin_replying_ticket')
    
    if not ticket_id or reply_text == "❌ Cancel Reply":
        context.user_data.pop('admin_replying_ticket', None)
        await update.message.reply_text(
            "❌ Reply cancelled.",
            reply_markup=None
        )
        return
    
    try:
        # Add admin message to ticket
        message_id = add_support_message(
            ticket_id=ticket_id,
            sender_id=admin_id,
            sender_type='admin',
            message_text=reply_text
        )
        
        if message_id:
            # Get ticket messages to find user ID
            messages = get_ticket_messages(ticket_id)
            if messages:
                # Find user ID from first message
                user_message = next((m for m in messages if m['sender_type'] == 'user'), None)
                if user_message:
                    user_id = user_message['sender_id']
                    
                    # Send reply to user
                    user_notification = (
                        f"💬 <b>Admin Response</b>\n\n"
                        f"🎫 <b>Ticket:</b> <code>{ticket_id}</code>\n"
                        f"👑 <b>Admin Reply:</b>\n\n{reply_text}\n\n"
                        f"💡 You can continue the conversation by replying to this message."
                    )
                    
                    keyboard = [
                        [InlineKeyboardButton("💬 Reply", callback_data=f"contact_add_message_{ticket_id}")],
                        [InlineKeyboardButton("📋 View Ticket", callback_data=f"contact_view_ticket_{ticket_id}")]
                    ]
                    
                    user_reply_markup = InlineKeyboardMarkup(keyboard)
                    
                    try:
                        await context.bot.send_message(
                            chat_id=user_id,
                            text=user_notification,
                            parse_mode='HTML',
                            reply_markup=user_reply_markup
                        )
                        
                        await update.message.reply_text(
                            f"✅ Reply sent to user for ticket <code>{ticket_id}</code>",
                            parse_mode='HTML',
                            reply_markup=None
                        )
                        
                    except Exception as e:
                        logger.error(f"Failed to send reply to user {user_id}: {e}")
                        await update.message.reply_text(
                            f"✅ Reply saved to ticket, but failed to notify user directly.",
                            reply_markup=None
                        )
                
                else:
                    await update.message.reply_text(
                        "❌ Could not find user for this ticket.",
                        reply_markup=None
                    )
            else:
                await update.message.reply_text(
                    "❌ Could not find ticket messages.",
                    reply_markup=None
                )
        else:
            await update.message.reply_text(
                "❌ Failed to save reply to ticket.",
                reply_markup=None
            )
    
    except Exception as e:
        logger.error(f"Error handling admin reply to ticket {ticket_id}: {e}")
        await update.message.reply_text(
            f"❌ Error processing reply: {str(e)}",
            reply_markup=None
        )
    
    finally:
        context.user_data.pop('admin_replying_ticket', None)
