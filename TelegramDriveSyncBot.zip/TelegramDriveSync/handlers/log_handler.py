"""
TelegramDriveSync Bot - Log Handler
Log aktivitas user & admin, pagination, download
"""

import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from database import get_user_logs, get_all_logs, log_activity
from config import Config
from utils import (
    paginate_items, create_pagination_keyboard, format_log_entry,
    get_status_emoji, format_datetime, get_time_ago
)
from datetime import datetime, timedelta
import json

logger = logging.getLogger(__name__)

async def show_user_logs(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show user's activity logs"""
    user_id = update.effective_user.id
    page = context.user_data.get('log_page', 1)
    
    logs = get_user_logs(user_id, limit=50)
    paginated_logs, pagination_info = paginate_items(logs, page, 5)
    
    log_message = f"📑 <b>Log Aktivitas Saya</b>\n\n"
    
    if not logs:
        log_message += (
            f"📝 Belum ada aktivitas tercatat.\n\n"
            f"Mulai gunakan bot untuk melihat log aktivitas Anda!"
        )
        keyboard = [
            [InlineKeyboardButton("📤 Upload File", callback_data="upload_menu")],
            [InlineKeyboardButton("🔗 Scrape Twitter", callback_data="twitter_menu")],
            [InlineKeyboardButton("🔙 Main Menu", callback_data="show_main_menu")]
        ]
    else:
        log_message += f"📊 Total aktivitas: {len(logs)}\n"
        log_message += f"📋 Page {pagination_info['current_page']}/{pagination_info['total_pages']}\n\n"
        
        for log in paginated_logs:
            formatted_log = format_log_entry(log)
            log_message += f"{formatted_log}\n\n"
        
        # Create keyboard with pagination
        keyboard = []
        
        # Action buttons
        action_buttons = [
            InlineKeyboardButton("🔄 Refresh", callback_data="log_refresh"),
            InlineKeyboardButton("📊 Statistik", callback_data="log_stats")
        ]
        keyboard.append(action_buttons)
        
        # Filter buttons
        filter_buttons = [
            InlineKeyboardButton("📤 Upload Only", callback_data="log_filter_upload"),
            InlineKeyboardButton("🔗 Scraping Only", callback_data="log_filter_scraping")
        ]
        keyboard.append(filter_buttons)
        
        # Pagination
        if pagination_info['total_pages'] > 1:
            pagination_keyboard = create_pagination_keyboard('log', 
                                                           pagination_info['current_page'],
                                                           pagination_info['total_pages'])
            keyboard.extend(pagination_keyboard.inline_keyboard)
        
        # Export and clear buttons
        manage_buttons = [
            InlineKeyboardButton("📥 Export Logs", callback_data="log_export"),
            InlineKeyboardButton("🗑️ Clear Old", callback_data="log_clear_old")
        ]
        keyboard.append(manage_buttons)
        
        keyboard.append([InlineKeyboardButton("🔙 Main Menu", callback_data="show_main_menu")])
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    if update.callback_query:
        await update.callback_query.edit_message_text(
            log_message,
            parse_mode='HTML',
            reply_markup=reply_markup
        )
    else:
        await update.message.reply_text(
            log_message,
            parse_mode='HTML',
            reply_markup=reply_markup
        )

async def show_user_statistics(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show user activity statistics"""
    user_id = update.effective_user.id
    logs = get_user_logs(user_id, limit=1000)  # Get more logs for stats
    
    if not logs:
        await update.callback_query.answer("No activity logs found")
        return
    
    # Calculate statistics
    stats = {
        'total_activities': len(logs),
        'uploads': len([l for l in logs if 'upload' in l.get('action', '').lower()]),
        'scraping': len([l for l in logs if 'scrape' in l.get('action', '').lower()]),
        'successful': len([l for l in logs if l.get('status') == 'success']),
        'failed': len([l for l in logs if l.get('status') == 'failed']),
        'total_files': len([l for l in logs if l.get('file_name')]),
        'total_size': sum([l.get('file_size', 0) for l in logs if l.get('file_size')])
    }
    
    # Recent activity (last 7 days)
    week_ago = datetime.now() - timedelta(days=7)
    recent_logs = [l for l in logs if datetime.fromisoformat(l['created_at']) > week_ago]
    
    # Success rate
    success_rate = (stats['successful'] / stats['total_activities'] * 100) if stats['total_activities'] > 0 else 0
    
    stats_message = (
        f"📊 <b>Statistik Aktivitas</b>\n\n"
        f"📈 <b>Total Overview:</b>\n"
        f"🔄 Total aktivitas: {stats['total_activities']}\n"
        f"📤 Upload: {stats['uploads']}\n"
        f"🔗 Scraping: {stats['scraping']}\n"
        f"📁 Total file: {stats['total_files']}\n"
        f"📏 Total size: {format_file_size(stats['total_size'])}\n\n"
        f"✅ <b>Success Rate:</b>\n"
        f"✅ Berhasil: {stats['successful']}\n"
        f"❌ Gagal: {stats['failed']}\n"
        f"📈 Rate: {success_rate:.1f}%\n\n"
        f"📅 <b>Last 7 Days:</b>\n"
        f"🔄 Activities: {len(recent_logs)}\n"
        f"📈 Daily average: {len(recent_logs)/7:.1f}\n\n"
    )
    
    # Most active hours
    if logs:
        hours = [datetime.fromisoformat(l['created_at']).hour for l in logs]
        most_active_hour = max(set(hours), key=hours.count) if hours else 0
        stats_message += f"⏰ Most active hour: {most_active_hour:02d}:00\n"
    
    # Top actions
    actions = [l.get('action', 'unknown') for l in logs]
    if actions:
        top_action = max(set(actions), key=actions.count)
        stats_message += f"🎯 Top activity: {top_action}\n"
    
    keyboard = [
        [
            InlineKeyboardButton("📊 Detailed Report", callback_data="log_detailed_report"),
            InlineKeyboardButton("📥 Export Stats", callback_data="log_export_stats")
        ],
        [
            InlineKeyboardButton("🔄 Refresh", callback_data="log_stats"),
            InlineKeyboardButton("🔙 Back", callback_data="log_refresh")
        ]
    ]
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.callback_query.edit_message_text(
        stats_message,
        parse_mode='HTML',
        reply_markup=reply_markup
    )

async def show_filtered_logs(update: Update, context: ContextTypes.DEFAULT_TYPE, filter_type: str):
    """Show filtered activity logs"""
    user_id = update.effective_user.id
    page = context.user_data.get('filtered_log_page', 1)
    
    # Get all logs and filter
    all_logs = get_user_logs(user_id, limit=200)
    
    if filter_type == 'upload':
        filtered_logs = [l for l in all_logs if 'upload' in l.get('action', '').lower()]
        title = "📤 Upload Logs"
    elif filter_type == 'scraping':
        filtered_logs = [l for l in all_logs if 'scrape' in l.get('action', '').lower()]
        title = "🔗 Scraping Logs"
    elif filter_type == 'success':
        filtered_logs = [l for l in all_logs if l.get('status') == 'success']
        title = "✅ Successful Activities"
    elif filter_type == 'failed':
        filtered_logs = [l for l in all_logs if l.get('status') == 'failed']
        title = "❌ Failed Activities"
    else:
        filtered_logs = all_logs
        title = "📑 All Logs"
    
    paginated_logs, pagination_info = paginate_items(filtered_logs, page, 5)
    
    log_message = f"{title}\n\n"
    
    if not filtered_logs:
        log_message += f"📝 Tidak ada log untuk filter '{filter_type}'."
    else:
        log_message += f"📊 Found: {len(filtered_logs)} entries\n"
        log_message += f"📋 Page {pagination_info['current_page']}/{pagination_info['total_pages']}\n\n"
        
        for log in paginated_logs:
            formatted_log = format_log_entry(log)
            log_message += f"{formatted_log}\n\n"
    
    # Create keyboard
    keyboard = []
    
    # Filter buttons
    filter_buttons = [
        InlineKeyboardButton("📤 Upload", callback_data="log_filter_upload"),
        InlineKeyboardButton("🔗 Scraping", callback_data="log_filter_scraping")
    ]
    keyboard.append(filter_buttons)
    
    status_buttons = [
        InlineKeyboardButton("✅ Success", callback_data="log_filter_success"),
        InlineKeyboardButton("❌ Failed", callback_data="log_filter_failed")
    ]
    keyboard.append(status_buttons)
    
    # Pagination
    if pagination_info['total_pages'] > 1:
        pagination_keyboard = create_pagination_keyboard('log_filtered', 
                                                       pagination_info['current_page'],
                                                       pagination_info['total_pages'],
                                                       f"_{filter_type}")
        keyboard.extend(pagination_keyboard.inline_keyboard)
    
    keyboard.append([
        InlineKeyboardButton("📑 All Logs", callback_data="log_refresh"),
        InlineKeyboardButton("🔙 Main Menu", callback_data="show_main_menu")
    ])
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.callback_query.edit_message_text(
        log_message,
        parse_mode='HTML',
        reply_markup=reply_markup
    )

async def export_user_logs(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Export user logs to file"""
    user_id = update.effective_user.id
    logs = get_user_logs(user_id, limit=1000)
    
    if not logs:
        await update.callback_query.answer("No logs to export")
        return
    
    await update.callback_query.answer("Preparing export...")
    
    # Create export data
    export_data = {
        'user_id': user_id,
        'export_date': datetime.now().isoformat(),
        'total_logs': len(logs),
        'logs': logs
    }
    
    # Generate filename
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    filename = f"user_logs_{user_id}_{timestamp}.json"
    
    # Save to storage
    import os
    file_path = os.path.join(Config.STORAGE_PATH, filename)
    
    try:
        with open(file_path, 'w', encoding='utf-8') as f:
            json.dump(export_data, f, indent=2, ensure_ascii=False)
        
        # Send file to user
        with open(file_path, 'rb') as f:
            await context.bot.send_document(
                chat_id=user_id,
                document=f,
                filename=filename,
                caption=f"📥 <b>Log Export</b>\n\n"
                       f"📊 Total logs: {len(logs)}\n"
                       f"📅 Export date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"
                       f"📁 Format: JSON",
                parse_mode='HTML'
            )
        
        # Clean up file
        os.remove(file_path)
        
        # Log the export
        log_activity(
            user_id=user_id,
            action="log_export",
            details=f"Exported {len(logs)} log entries"
        )
        
        await update.callback_query.edit_message_text(
            f"✅ <b>Export Completed!</b>\n\n"
            f"📊 Exported {len(logs)} log entries\n"
            f"📁 File sent to your chat\n\n"
            f"File contains all your activity history in JSON format.",
            parse_mode='HTML',
            reply_markup=InlineKeyboardMarkup([[
                InlineKeyboardButton("🔙 Back to Logs", callback_data="log_refresh")
            ]])
        )
        
    except Exception as e:
        logger.error(f"Error exporting logs for user {user_id}: {e}")
        await update.callback_query.edit_message_text(
            f"❌ <b>Export Failed</b>\n\n"
            f"Error: {str(e)}\n"
            f"Please try again or contact admin.",
            parse_mode='HTML',
            reply_markup=InlineKeyboardMarkup([[
                InlineKeyboardButton("🔙 Back to Logs", callback_data="log_refresh")
            ]])
        )

async def clear_old_logs(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Clear old user logs"""
    user_id = update.effective_user.id
    
    clear_message = (
        f"🗑️ <b>Clear Old Logs</b>\n\n"
        f"⚠️ <b>WARNING:</b> This will permanently delete old log entries!\n\n"
        f"📅 <b>Options:</b>\n"
        f"• Clear logs older than 30 days\n"
        f"• Clear logs older than 90 days\n"
        f"• Clear failed logs only\n"
        f"• Clear all logs\n\n"
        f"💡 <b>Recommendation:</b> Export logs first before clearing."
    )
    
    keyboard = [
        [
            InlineKeyboardButton("📥 Export First", callback_data="log_export"),
            InlineKeyboardButton("30 Days", callback_data="log_clear_30")
        ],
        [
            InlineKeyboardButton("90 Days", callback_data="log_clear_90"),
            InlineKeyboardButton("❌ Failed Only", callback_data="log_clear_failed")
        ],
        [
            InlineKeyboardButton("🗑️ Clear All", callback_data="log_clear_all"),
            InlineKeyboardButton("🔙 Cancel", callback_data="log_refresh")
        ]
    ]
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.callback_query.edit_message_text(
        clear_message,
        parse_mode='HTML',
        reply_markup=reply_markup
    )

async def execute_log_clear(update: Update, context: ContextTypes.DEFAULT_TYPE, clear_type: str):
    """Execute log clearing operation"""
    user_id = update.effective_user.id
    
    from database import get_db_connection
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        if clear_type == '30':
            cutoff_date = datetime.now() - timedelta(days=30)
            cursor.execute('''
                DELETE FROM activity_logs 
                WHERE user_id = ? AND created_at < ?
            ''', (user_id, cutoff_date))
        elif clear_type == '90':
            cutoff_date = datetime.now() - timedelta(days=90)
            cursor.execute('''
                DELETE FROM activity_logs 
                WHERE user_id = ? AND created_at < ?
            ''', (user_id, cutoff_date))
        elif clear_type == 'failed':
            cursor.execute('''
                DELETE FROM activity_logs 
                WHERE user_id = ? AND status = 'failed'
            ''', (user_id,))
        elif clear_type == 'all':
            cursor.execute('''
                DELETE FROM activity_logs 
                WHERE user_id = ?
            ''', (user_id,))
        
        deleted_count = cursor.rowcount
        conn.commit()
        
        # Log the clearing action
        log_activity(
            user_id=user_id,
            action="log_clear",
            details=f"Cleared {deleted_count} log entries ({clear_type})"
        )
        
        result_message = (
            f"✅ <b>Logs Cleared Successfully!</b>\n\n"
            f"🗑️ Deleted entries: {deleted_count}\n"
            f"📋 Clear type: {clear_type}\n"
            f"📅 Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n"
            f"Your log history has been cleaned up."
        )
        
    except Exception as e:
        logger.error(f"Error clearing logs for user {user_id}: {e}")
        conn.rollback()
        result_message = (
            f"❌ <b>Clear Operation Failed</b>\n\n"
            f"Error: {str(e)}\n"
            f"Please try again or contact admin."
        )
    
    finally:
        conn.close()
    
    keyboard = [[InlineKeyboardButton("🔙 Back to Logs", callback_data="log_refresh")]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.callback_query.edit_message_text(
        result_message,
        parse_mode='HTML',
        reply_markup=reply_markup
    )

async def show_detailed_report(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show detailed activity report"""
    user_id = update.effective_user.id
    logs = get_user_logs(user_id, limit=1000)
    
    if not logs:
        await update.callback_query.answer("No data for report")
        return
    
    # Detailed analysis
    daily_activity = {}
    action_counts = {}
    hourly_activity = [0] * 24
    file_types = {}
    
    for log in logs:
        # Daily activity
        date = log['created_at'][:10]
        daily_activity[date] = daily_activity.get(date, 0) + 1
        
        # Action counts
        action = log.get('action', 'unknown')
        action_counts[action] = action_counts.get(action, 0) + 1
        
        # Hourly activity
        hour = datetime.fromisoformat(log['created_at']).hour
        hourly_activity[hour] += 1
        
        # File types
        if log.get('file_name'):
            ext = log['file_name'].split('.')[-1].lower() if '.' in log['file_name'] else 'unknown'
            file_types[ext] = file_types.get(ext, 0) + 1
    
    # Top statistics
    most_active_day = max(daily_activity.items(), key=lambda x: x[1]) if daily_activity else ('N/A', 0)
    most_active_hour = hourly_activity.index(max(hourly_activity))
    top_action = max(action_counts.items(), key=lambda x: x[1]) if action_counts else ('N/A', 0)
    top_file_type = max(file_types.items(), key=lambda x: x[1]) if file_types else ('N/A', 0)
    
    report_message = (
        f"📊 <b>Detailed Activity Report</b>\n\n"
        f"📈 <b>Activity Patterns:</b>\n"
        f"🏆 Most active day: {most_active_day[0]} ({most_active_day[1]} activities)\n"
        f"⏰ Most active hour: {most_active_hour:02d}:00\n"
        f"🎯 Top action: {top_action[0]} ({top_action[1]} times)\n"
        f"📁 Top file type: .{top_file_type[0]} ({top_file_type[1]} files)\n\n"
        f"📅 <b>Recent Activity (Last 7 days):</b>\n"
    )
    
    # Last 7 days breakdown
    recent_days = []
    for i in range(7):
        date = (datetime.now() - timedelta(days=i)).strftime('%Y-%m-%d')
        count = daily_activity.get(date, 0)
        recent_days.append(f"📅 {date}: {count} activities")
    
    report_message += '\n'.join(recent_days[:5])  # Show last 5 days
    
    if len(action_counts) > 1:
        report_message += f"\n\n🔄 <b>Action Breakdown:</b>\n"
        for action, count in sorted(action_counts.items(), key=lambda x: x[1], reverse=True)[:5]:
            percentage = (count / len(logs)) * 100
            report_message += f"• {action}: {count} ({percentage:.1f}%)\n"
    
    keyboard = [
        [
            InlineKeyboardButton("📥 Export Report", callback_data="log_export_detailed"),
            InlineKeyboardButton("📊 Back to Stats", callback_data="log_stats")
        ],
        [InlineKeyboardButton("🔙 Back to Logs", callback_data="log_refresh")]
    ]
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.callback_query.edit_message_text(
        report_message,
        parse_mode='HTML',
        reply_markup=reply_markup
    )

async def handle_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle log-related callback queries"""
    query = update.callback_query
    data = query.data
    
    if data == "log_refresh":
        context.user_data['log_page'] = 1
        await show_user_logs(update, context)
    elif data == "log_stats":
        await show_user_statistics(update, context)
    elif data.startswith("log_page_"):
        page = int(data.split("_")[-1])
        context.user_data['log_page'] = page
        await show_user_logs(update, context)
    elif data.startswith("log_filter_"):
        filter_type = data.split("_", 2)[2]
        context.user_data['filtered_log_page'] = 1
        await show_filtered_logs(update, context, filter_type)
    elif data.startswith("log_filtered_page_"):
        parts = data.split("_")
        page = int(parts[3])
        filter_type = parts[4] if len(parts) > 4 else 'all'
        context.user_data['filtered_log_page'] = page
        await show_filtered_logs(update, context, filter_type)
    elif data == "log_export":
        await export_user_logs(update, context)
    elif data == "log_clear_old":
        await clear_old_logs(update, context)
    elif data.startswith("log_clear_"):
        clear_type = data.split("_", 2)[2]
        await execute_log_clear(update, context, clear_type)
    elif data == "log_detailed_report":
        await show_detailed_report(update, context)
    elif data == "log_export_stats":
        await export_user_logs(update, context)  # Same as regular export for now
    elif data == "log_export_detailed":
        await export_user_logs(update, context)  # Same as regular export for now

# Import required utilities
from utils import format_file_size
