"""
TelegramDriveSync Bot - OAuth Handler
Proses OAuth (multi-akun, auto-switch)
"""

import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes, ConversationHandler, MessageHandler, filters
from database import add_gdrive_account, get_user_gdrive_accounts, update_user_oauth, log_activity
from config import Config
import json
import secrets
import base64

logger = logging.getLogger(__name__)

# OAuth conversation states
OAUTH_WAITING_CODE, OAUTH_ACCOUNT_NAME = range(2)

# Simulated OAuth flow for demo purposes
class GoogleOAuthManager:
    def __init__(self):
        self.client_id = Config.GOOGLE_CLIENT_ID
        self.client_secret = Config.GOOGLE_CLIENT_SECRET
        self.redirect_uri = Config.GOOGLE_REDIRECT_URI
        self.scope = "https://www.googleapis.com/auth/drive"
    
    def generate_auth_url(self, state: str) -> str:
        """Generate OAuth authorization URL"""
        # In real implementation, use Google OAuth2 library
        # For demo, return a simulated URL
        return (
            f"https://accounts.google.com/o/oauth2/auth?"
            f"client_id={self.client_id}&"
            f"redirect_uri={self.redirect_uri}&"
            f"scope={self.scope}&"
            f"response_type=code&"
            f"access_type=offline&"
            f"state={state}"
        )
    
    def exchange_code_for_tokens(self, code: str) -> dict:
        """Exchange authorization code for access tokens"""
        # In real implementation, make POST request to Google's token endpoint
        # For demo, return simulated tokens
        return {
            "access_token": f"ya29.{secrets.token_urlsafe(32)}",
            "refresh_token": f"1//{secrets.token_urlsafe(16)}",
            "expires_in": 3600,
            "token_type": "Bearer",
            "scope": self.scope
        }
    
    def get_user_info(self, access_token: str) -> dict:
        """Get user information from Google"""
        # In real implementation, call Google's userinfo API
        # For demo, return simulated user info
        return {
            "email": f"user{secrets.randbelow(1000)}@gmail.com",
            "name": "Demo User",
            "verified_email": True
        }

oauth_manager = GoogleOAuthManager()

async def start_oauth_process(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Start OAuth process for Google Drive"""
    user_id = update.effective_user.id
    
    # Generate state parameter for security
    state = secrets.token_urlsafe(16)
    context.user_data['oauth_state'] = state
    
    # Generate authorization URL
    auth_url = oauth_manager.generate_auth_url(state)
    
    oauth_message = (
        f"🔐 <b>Google Drive OAuth</b>\n\n"
        f"📋 <b>Langkah-langkah:</b>\n"
        f"1️⃣ Klik tombol 'Authorize' di bawah\n"
        f"2️⃣ Login ke akun Google Drive Anda\n"
        f"3️⃣ Berikan izin akses ke bot\n"
        f"4️⃣ Copy kode yang diberikan\n"
        f"5️⃣ Paste kode di chat ini\n\n"
        f"🔒 <b>Keamanan:</b>\n"
        f"✅ Bot hanya butuh akses upload\n"
        f"✅ Tidak ada akses ke file pribadi\n"
        f"✅ Token terenkripsi aman\n"
        f"✅ Bisa dicabut kapan saja\n\n"
        f"💡 <b>Tips:</b>\n"
        f"• Gunakan akun Google dengan storage kosong\n"
        f"• Anda bisa menambah multiple akun\n"
        f"• Auto-switch saat quota penuh"
    )
    
    keyboard = [
        [InlineKeyboardButton("🔐 Authorize Google Drive", url=auth_url)],
        [InlineKeyboardButton("❓ Help", callback_data="oauth_help")],
        [InlineKeyboardButton("❌ Cancel", callback_data="oauth_cancel")]
    ]
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    if update.callback_query:
        await update.callback_query.edit_message_text(
            oauth_message,
            parse_mode='HTML',
            reply_markup=reply_markup
        )
    else:
        await update.message.reply_text(
            oauth_message,
            parse_mode='HTML',
            reply_markup=reply_markup
        )
    
    # Set conversation state
    context.user_data['oauth_mode'] = 'new_account'
    
    return OAUTH_WAITING_CODE

async def start_add_account_oauth(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Start OAuth process for adding additional account"""
    user_id = update.effective_user.id
    existing_accounts = get_user_gdrive_accounts(user_id)
    
    # Generate state parameter for security
    state = secrets.token_urlsafe(16)
    context.user_data['oauth_state'] = state
    
    # Generate authorization URL
    auth_url = oauth_manager.generate_auth_url(state)
    
    oauth_message = (
        f"➕ <b>Tambah Akun Google Drive</b>\n\n"
        f"📊 Akun saat ini: {len(existing_accounts)}\n\n"
        f"🔐 <b>Menambah akun baru:</b>\n"
        f"• Akun akan menjadi secondary (backup)\n"
        f"• Auto-switch saat primary penuh\n"
        f"• Bisa diatur jadi primary nanti\n\n"
        f"📋 <b>Proses sama dengan sebelumnya:</b>\n"
        f"1️⃣ Klik 'Authorize' → Login Google\n"
        f"2️⃣ Copy authorization code\n"
        f"3️⃣ Paste di chat ini\n\n"
        f"💡 <b>Rekomendasi:</b>\n"
        f"• Gunakan akun Google berbeda\n"
        f"• Pastikan punya storage kosong\n"
        f"• Catat email untuk identifikasi"
    )
    
    keyboard = [
        [InlineKeyboardButton("🔐 Authorize New Account", url=auth_url)],
        [InlineKeyboardButton("⚙️ Manage Existing", callback_data="gdrive_manage")],
        [InlineKeyboardButton("❌ Cancel", callback_data="gdrive_menu")]
    ]
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.callback_query.edit_message_text(
        oauth_message,
        parse_mode='HTML',
        reply_markup=reply_markup
    )
    
    # Set conversation state
    context.user_data['oauth_mode'] = 'add_account'
    
    return OAUTH_WAITING_CODE

async def handle_oauth_code(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle OAuth authorization code from user"""
    user_id = update.effective_user.id
    code = update.message.text.strip()
    
    if code == "/cancel":
        await update.message.reply_text("❌ OAuth dibatalkan.")
        return ConversationHandler.END
    
    # Validate code format (basic check)
    if len(code) < 10:
        await update.message.reply_text(
            "❌ Kode tidak valid. Silakan paste authorization code yang benar.\n"
            "Format kode biasanya panjang (30+ karakter)."
        )
        return OAUTH_WAITING_CODE
    
    # Show processing message
    processing_msg = await update.message.reply_text(
        f"🔄 <b>Processing OAuth...</b>\n\n"
        f"⏳ Mengverifikasi kode...\n"
        f"🔐 Menukar dengan access token...\n"
        f"👤 Mengambil info akun...",
        parse_mode='HTML'
    )
    
    try:
        # Exchange code for tokens
        tokens = oauth_manager.exchange_code_for_tokens(code)
        
        if not tokens.get('access_token'):
            raise Exception("Failed to get access token")
        
        # Update processing message
        await processing_msg.edit_text(
            f"🔄 <b>Processing OAuth...</b>\n\n"
            f"✅ Kode diverifikasi\n"
            f"✅ Token diperoleh\n"
            f"⏳ Mengambil info akun...",
            parse_mode='HTML'
        )
        
        # Get user info
        user_info = oauth_manager.get_user_info(tokens['access_token'])
        
        if not user_info.get('email'):
            raise Exception("Failed to get user email")
        
        # Update processing message
        await processing_msg.edit_text(
            f"🔄 <b>Processing OAuth...</b>\n\n"
            f"✅ Kode diverifikasi\n"
            f"✅ Token diperoleh\n"
            f"✅ Info akun: {user_info['email']}\n"
            f"⏳ Menyimpan ke database...",
            parse_mode='HTML'
        )
        
        # Check if account already exists
        existing_accounts = get_user_gdrive_accounts(user_id)
        account_exists = any(acc['account_email'] == user_info['email'] for acc in existing_accounts)
        
        if account_exists:
            await processing_msg.edit_text(
                f"❌ <b>Akun sudah terhubung!</b>\n\n"
                f"📧 {user_info['email']}\n\n"
                f"Akun ini sudah ada di database Anda.\n"
                f"Gunakan menu kelola akun untuk mengatur.",
                parse_mode='HTML',
                reply_markup=InlineKeyboardMarkup([[
                    InlineKeyboardButton("⚙️ Kelola Akun", callback_data="gdrive_manage")
                ]])
            )
            return ConversationHandler.END
        
        # Prepare credentials JSON
        credentials_data = {
            'access_token': tokens['access_token'],
            'refresh_token': tokens.get('refresh_token'),
            'token_uri': 'https://oauth2.googleapis.com/token',
            'client_id': oauth_manager.client_id,
            'client_secret': oauth_manager.client_secret,
            'scopes': [oauth_manager.scope]
        }
        
        # Determine if this should be primary account
        oauth_mode = context.user_data.get('oauth_mode', 'new_account')
        is_primary = len(existing_accounts) == 0 or oauth_mode == 'new_account'
        
        # Add account to database
        account_id = add_gdrive_account(
            user_id=user_id,
            account_email=user_info['email'],
            credentials_json=json.dumps(credentials_data),
            is_primary=is_primary
        )
        
        if account_id:
            # Update user OAuth status if this is first account
            if len(existing_accounts) == 0:
                update_user_oauth(user_id, True)
            
            # Log successful OAuth
            log_activity(
                user_id=user_id,
                action="oauth_success",
                details=f"Connected Google Drive: {user_info['email']}",
                gdrive_account_id=account_id
            )
            
            # Success message
            success_message = (
                f"✅ <b>Google Drive Terhubung!</b>\n\n"
                f"📧 <b>Account:</b> {user_info['email']}\n"
                f"🎯 <b>Status:</b> {'Primary' if is_primary else 'Secondary'}\n"
                f"🔐 <b>Access:</b> Upload & File Management\n"
                f"💾 <b>Storage:</b> Ready to use\n\n"
            )
            
            if len(existing_accounts) == 0:
                success_message += f"🚀 <b>Selamat!</b> Semua fitur bot sekarang tersedia!"
            else:
                success_message += f"➕ <b>Akun ditambahkan!</b> Total akun: {len(existing_accounts) + 1}"
            
            keyboard = []
            
            if len(existing_accounts) == 0:
                # First account - show main features
                keyboard.extend([
                    [InlineKeyboardButton("📤 Upload File", callback_data="upload_menu")],
                    [InlineKeyboardButton("🗂️ Browse GDrive", callback_data="gdrive_browse")],
                    [InlineKeyboardButton("🔗 Scrape Twitter", callback_data="twitter_menu")],
                    [InlineKeyboardButton("🏠 Main Menu", callback_data="show_main_menu")]
                ])
            else:
                # Additional account - show management options
                keyboard.extend([
                    [InlineKeyboardButton("🎯 Set as Primary", callback_data=f"gdrive_set_primary_{account_id}")],
                    [InlineKeyboardButton("⚙️ Manage Accounts", callback_data="gdrive_manage")],
                    [InlineKeyboardButton("📊 Check Storage", callback_data="gdrive_storage")],
                    [InlineKeyboardButton("🏠 Main Menu", callback_data="show_main_menu")]
                ])
            
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            await processing_msg.edit_text(
                success_message,
                parse_mode='HTML',
                reply_markup=reply_markup
            )
            
        else:
            raise Exception("Failed to save account to database")
        
    except Exception as e:
        logger.error(f"OAuth error for user {user_id}: {e}")
        
        error_message = (
            f"❌ <b>OAuth Failed</b>\n\n"
            f"💥 Error: {str(e)}\n\n"
            f"🔄 <b>Possible solutions:</b>\n"
            f"• Pastikan kode authorization benar\n"
            f"• Coba generate kode baru\n"
            f"• Pastikan koneksi internet stabil\n"
            f"• Hubungi admin jika masih error"
        )
        
        keyboard = [
            [InlineKeyboardButton("🔄 Try Again", callback_data="oauth_start")],
            [InlineKeyboardButton("💬 Contact Admin", callback_data="contact_admin_start")],
            [InlineKeyboardButton("🏠 Main Menu", callback_data="show_main_menu")]
        ]
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await processing_msg.edit_text(
            error_message,
            parse_mode='HTML',
            reply_markup=reply_markup
        )
    
    finally:
        # Clear OAuth data
        context.user_data.pop('oauth_state', None)
        context.user_data.pop('oauth_mode', None)
    
    return ConversationHandler.END

async def show_oauth_help(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show OAuth help information"""
    help_message = (
        f"❓ <b>Google Drive OAuth Help</b>\n\n"
        f"🔐 <b>Apa itu OAuth?</b>\n"
        f"OAuth adalah sistem keamanan yang memungkinkan bot mengakses Google Drive Anda tanpa perlu password.\n\n"
        f"📋 <b>Langkah Detail:</b>\n"
        f"1️⃣ <b>Klik 'Authorize'</b>\n"
        f"   → Akan buka halaman Google\n\n"
        f"2️⃣ <b>Login Google</b>\n"
        f"   → Gunakan akun dengan storage kosong\n\n"
        f"3️⃣ <b>Berikan Izin</b>\n"
        f"   → Bot hanya minta akses upload\n\n"
        f"4️⃣ <b>Copy Kode</b>\n"
        f"   → Google akan tampilkan kode panjang\n\n"
        f"5️⃣ <b>Paste di Chat</b>\n"
        f"   → Kirim kode ke bot di sini\n\n"
        f"🛡️ <b>Keamanan:</b>\n"
        f"✅ Bot tidak bisa lihat file pribadi\n"
        f"✅ Hanya izin upload dan manage file bot\n"
        f"✅ Bisa dicabut dari Google Account settings\n"
        f"✅ Token dienkripsi di database\n\n"
        f"❓ <b>Troubleshooting:</b>\n"
        f"• Kode tidak valid → Generate ulang\n"
        f"• Login gagal → Cek koneksi internet\n"
        f"• Access denied → Pastikan berikan semua izin\n"
        f"• Error lain → Hubungi admin"
    )
    
    keyboard = [
        [InlineKeyboardButton("🔐 Start OAuth", callback_data="oauth_start")],
        [InlineKeyboardButton("💬 Contact Admin", callback_data="contact_admin_start")],
        [InlineKeyboardButton("🔙 Back", callback_data="show_main_menu")]
    ]
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.callback_query.edit_message_text(
        help_message,
        parse_mode='HTML',
        reply_markup=reply_markup
    )

async def revoke_account_access(update: Update, context: ContextTypes.DEFAULT_TYPE, account_id: int):
    """Revoke access for a specific account"""
    user_id = update.effective_user.id
    
    from database import get_db_connection
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        # Get account info
        cursor.execute('SELECT * FROM gdrive_accounts WHERE id = ? AND user_id = ?', (account_id, user_id))
        account = cursor.fetchone()
        
        if not account:
            await update.callback_query.answer("Account not found")
            return
        
        account_email = account['account_email']
        
        # Deactivate account
        cursor.execute('''
            UPDATE gdrive_accounts 
            SET is_active = FALSE 
            WHERE id = ?
        ''', (account_id,))
        
        conn.commit()
        
        # Log the revocation
        log_activity(
            user_id=user_id,
            action="oauth_revoke",
            details=f"Revoked access for: {account_email}",
            gdrive_account_id=account_id
        )
        
        # Check if user still has active accounts
        cursor.execute('''
            SELECT COUNT(*) as count FROM gdrive_accounts 
            WHERE user_id = ? AND is_active = TRUE
        ''', (user_id,))
        
        active_count = cursor.fetchone()['count']
        
        # If no active accounts, update OAuth status
        if active_count == 0:
            update_user_oauth(user_id, False)
        
        success_message = (
            f"✅ <b>Access Revoked</b>\n\n"
            f"📧 Account: {account_email}\n"
            f"🔐 Status: Deactivated\n"
            f"💾 Data: Preserved in database\n\n"
        )
        
        if active_count == 0:
            success_message += (
                f"⚠️ <b>Warning:</b> No active accounts remaining!\n"
                f"You'll need to reconnect an account to use upload features."
            )
        else:
            success_message += f"📊 Active accounts remaining: {active_count}"
        
        keyboard = []
        
        if active_count == 0:
            keyboard.append([InlineKeyboardButton("🔐 Reconnect Account", callback_data="oauth_start")])
        
        keyboard.extend([
            [InlineKeyboardButton("⚙️ Manage Accounts", callback_data="gdrive_manage")],
            [InlineKeyboardButton("🏠 Main Menu", callback_data="show_main_menu")]
        ])
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await update.callback_query.edit_message_text(
            success_message,
            parse_mode='HTML',
            reply_markup=reply_markup
        )
        
    except Exception as e:
        logger.error(f"Error revoking account {account_id}: {e}")
        conn.rollback()
        await update.callback_query.answer("❌ Failed to revoke access")
    
    finally:
        conn.close()

async def handle_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle OAuth-related callback queries"""
    query = update.callback_query
    data = query.data
    
    if data == "oauth_start":
        await start_oauth_process(update, context)
    elif data == "oauth_add_account":
        await start_add_account_oauth(update, context)
    elif data == "oauth_help":
        await show_oauth_help(update, context)
    elif data == "oauth_cancel":
        context.user_data.pop('oauth_state', None)
        context.user_data.pop('oauth_mode', None)
        
        await update.callback_query.edit_message_text(
            "❌ OAuth dibatalkan.\n\n"
            "Anda bisa mulai OAuth kapan saja dari menu utama.",
            reply_markup=InlineKeyboardMarkup([[
                InlineKeyboardButton("🏠 Main Menu", callback_data="show_main_menu")
            ]])
        )
    elif data.startswith("oauth_revoke_"):
        account_id = int(data.split("_", 2)[2])
        await revoke_account_access(update, context, account_id)

def get_conversation_handler():
    """Get conversation handler for OAuth process"""
    return ConversationHandler(
        entry_points=[],
        states={
            OAUTH_WAITING_CODE: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, handle_oauth_code)
            ],
        },
        fallbacks=[
            MessageHandler(filters.Regex("^/cancel$"), lambda u, c: ConversationHandler.END)
        ],
        allow_reentry=True
    )
