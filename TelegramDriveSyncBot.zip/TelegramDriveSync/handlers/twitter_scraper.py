"""
TelegramDriveSync Bot - Twitter Scraper Handler
Handler scraping akun X
"""

import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes, ConversationHandler, MessageHandler, filters
from database import get_primary_gdrive_account, log_activity
from config import Config
from utils import (
    extract_twitter_usernames, validate_twitter_username, 
    create_progress_bar, format_file_size, get_file_type_emoji
)
from x_scraper_engine import twitter_scraper
from handlers.gdrive_handler import GoogleDriveManager
import asyncio
import os

logger = logging.getLogger(__name__)

# Twitter scraper conversation states
TWITTER_USERNAMES, TWITTER_CONFIRM = range(2)

async def show_twitter_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show Twitter scraping menu"""
    user_id = update.effective_user.id
    primary_account = get_primary_gdrive_account(user_id)
    
    twitter_message = f"🔗 <b>Twitter/X Scraper</b>\n\n"
    
    if not primary_account:
        twitter_message += (
            f"❌ Tidak ada akun Google Drive terhubung.\n"
            f"Silakan hubungkan akun terlebih dahulu untuk menyimpan hasil scraping."
        )
        keyboard = [
            [InlineKeyboardButton("🔐 Hubungkan GDrive", callback_data="oauth_start")],
            [InlineKeyboardButton("🔙 Back", callback_data="show_main_menu")]
        ]
    else:
        twitter_message += (
            f"📧 <b>Storage Account:</b> {primary_account['account_email']}\n\n"
            f"🎯 <b>Scraping Features:</b>\n"
            f"📸 Download semua media (foto, video, GIF)\n"
            f"📝 Extract tweet text dan metadata\n"
            f"📁 Auto-upload ke Google Drive\n"
            f"📊 Progress tracking real-time\n"
            f"📋 Detailed scraping report\n\n"
            f"⚡ <b>Scraping Options:</b>\n"
            f"👤 Single username scraping\n"
            f"📋 Batch multiple usernames\n"
            f"🎯 Media-only mode\n"
            f"📝 Text + Media mode\n\n"
            f"📏 <b>Limits:</b>\n"
            f"• Max {Config.MAX_SCRAPING_PER_DAY} scrapes/day\n"
            f"• Max 10 usernames per batch\n"
            f"• Max 50 tweets per username\n"
            f"• Auto rate limit handling"
        )
        
        keyboard = [
            [
                InlineKeyboardButton("👤 Single User", callback_data="twitter_single"),
                InlineKeyboardButton("📋 Batch Users", callback_data="twitter_batch")
            ],
            [
                InlineKeyboardButton("🎥 Media Only", callback_data="twitter_media_only"),
                InlineKeyboardButton("📝 Full Scrape", callback_data="twitter_full")
            ],
            [
                InlineKeyboardButton("📊 Scrape History", callback_data="twitter_history"),
                InlineKeyboardButton("⚙️ Settings", callback_data="twitter_settings")
            ],
            [InlineKeyboardButton("🔙 Back", callback_data="show_main_menu")]
        ]
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    if update.callback_query:
        await update.callback_query.edit_message_text(
            twitter_message,
            parse_mode='HTML',
            reply_markup=reply_markup
        )
    else:
        await update.message.reply_text(
            twitter_message,
            parse_mode='HTML',
            reply_markup=reply_markup
        )

async def start_single_user_scrape(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Start single user scraping process"""
    context.user_data['twitter_mode'] = 'single'
    context.user_data['twitter_settings'] = {
        'include_tweets': True,
        'include_media': True,
        'tweet_count': 20
    }
    
    single_message = (
        f"👤 <b>Single User Scraping</b>\n\n"
        f"📝 Kirim username Twitter/X yang ingin di-scrape.\n\n"
        f"📋 <b>Format yang didukung:</b>\n"
        f"• @username\n"
        f"• username (tanpa @)\n"
        f"• https://twitter.com/username\n"
        f"• https://x.com/username\n\n"
        f"⚙️ <b>Default Settings:</b>\n"
        f"📝 Include tweets: Yes\n"
        f"🖼️ Include media: Yes\n"
        f"📊 Max tweets: 20\n\n"
        f"💡 <b>Tips:</b>\n"
        f"• Pastikan akun public atau accessible\n"
        f"• Bot akan download semua media\n"
        f"• Progress ditampilkan real-time\n"
        f"• Hasil auto-upload ke Google Drive\n\n"
        f"✍️ <i>Kirim username:</i>"
    )
    
    keyboard = [[InlineKeyboardButton("❌ Cancel", callback_data="twitter_cancel")]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.callback_query.edit_message_text(
        single_message,
        parse_mode='HTML',
        reply_markup=reply_markup
    )
    
    return TWITTER_USERNAMES

async def start_batch_user_scrape(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Start batch user scraping process"""
    context.user_data['twitter_mode'] = 'batch'
    context.user_data['twitter_settings'] = {
        'include_tweets': True,
        'include_media': True,
        'tweet_count': 10  # Lower for batch
    }
    
    batch_message = (
        f"📋 <b>Batch User Scraping</b>\n\n"
        f"📝 Kirim daftar username (satu per baris) untuk di-scrape.\n\n"
        f"📋 <b>Format:</b>\n"
        f"username1\n"
        f"@username2\n"
        f"username3\n"
        f"...\n\n"
        f"📊 <b>Batch Limits:</b>\n"
        f"• Maksimal 10 usernames\n"
        f"• 10 tweets per username\n"
        f"• Parallel processing\n"
        f"• Smart rate limiting\n\n"
        f"⚡ <b>Batch Benefits:</b>\n"
        f"• Faster processing\n"
        f"• Combined report\n"
        f"• Bulk upload to GDrive\n"
        f"• Error handling per user\n\n"
        f"💡 <b>Example:</b>\n"
        f"elonmusk\n"
        f"@sundarpichai\n"
        f"tim_cook\n\n"
        f"✍️ <i>Kirim daftar usernames:</i>"
    )
    
    keyboard = [[InlineKeyboardButton("❌ Cancel", callback_data="twitter_cancel")]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.callback_query.edit_message_text(
        batch_message,
        parse_mode='HTML',
        reply_markup=reply_markup
    )
    
    return TWITTER_USERNAMES

async def set_media_only_mode(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Set scraping to media-only mode"""
    context.user_data['twitter_mode'] = 'single'
    context.user_data['twitter_settings'] = {
        'include_tweets': False,
        'include_media': True,
        'tweet_count': 50  # More tweets for media search
    }
    
    media_message = (
        f"🎥 <b>Media-Only Scraping</b>\n\n"
        f"📝 Mode ini hanya download media (foto, video, GIF) tanpa text tweet.\n\n"
        f"⚙️ <b>Settings:</b>\n"
        f"📝 Include tweets: No\n"
        f"🖼️ Include media: Yes\n"
        f"📊 Max tweets to scan: 50\n\n"
        f"💡 <b>Perfect for:</b>\n"
        f"• Collecting photos/videos\n"
        f"• Creating media archives\n"
        f"• Faster download (no text processing)\n"
        f"• Saving storage space\n\n"
        f"✍️ <i>Kirim username:</i>"
    )
    
    keyboard = [[InlineKeyboardButton("❌ Cancel", callback_data="twitter_cancel")]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.callback_query.edit_message_text(
        media_message,
        parse_mode='HTML',
        reply_markup=reply_markup
    )
    
    return TWITTER_USERNAMES

async def set_full_scrape_mode(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Set scraping to full mode"""
    context.user_data['twitter_mode'] = 'single'
    context.user_data['twitter_settings'] = {
        'include_tweets': True,
        'include_media': True,
        'tweet_count': 30
    }
    
    full_message = (
        f"📝 <b>Full Scraping Mode</b>\n\n"
        f"📋 Mode ini download semua: text tweets + media files.\n\n"
        f"⚙️ <b>Settings:</b>\n"
        f"📝 Include tweets: Yes\n"
        f"🖼️ Include media: Yes\n"
        f"📊 Max tweets: 30\n\n"
        f"💡 <b>You'll get:</b>\n"
        f"• Complete tweet text\n"
        f"• All photos and videos\n"
        f"• Tweet metadata (likes, retweets, etc.)\n"
        f"• Organized file structure\n"
        f"• Detailed JSON report\n\n"
        f"✍️ <i>Kirim username:</i>"
    )
    
    keyboard = [[InlineKeyboardButton("❌ Cancel", callback_data="twitter_cancel")]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.callback_query.edit_message_text(
        media_message,
        parse_mode='HTML',
        reply_markup=reply_markup
    )
    
    return TWITTER_USERNAMES

async def handle_username_input(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle username input for scraping"""
    text = update.message.text
    twitter_mode = context.user_data.get('twitter_mode', 'single')
    
    if text == "/cancel":
        await update.message.reply_text("❌ Twitter scraping dibatalkan.")
        await show_twitter_menu(update, context)
        return ConversationHandler.END
    
    if twitter_mode == 'single':
        # Single username processing
        usernames = extract_twitter_usernames(text)
        if not usernames:
            await update.message.reply_text(
                "❌ Username tidak valid. Silakan kirim username yang benar.\n"
                "Format: username atau @username"
            )
            return TWITTER_USERNAMES
        
        usernames = [usernames[0]]  # Take first one only
    else:
        # Batch usernames processing
        usernames = extract_twitter_usernames(text)
        
        if not usernames:
            await update.message.reply_text(
                "❌ Tidak ada username valid ditemukan.\n"
                "Pastikan format username benar."
            )
            return TWITTER_USERNAMES
        
        if len(usernames) > 10:
            await update.message.reply_text(
                f"❌ Terlalu banyak usernames ({len(usernames)}).\n"
                f"Maksimal 10 usernames per batch."
            )
            return TWITTER_USERNAMES
    
    # Store usernames and settings
    context.user_data['twitter_usernames'] = usernames
    
    # Show confirmation
    settings = context.user_data.get('twitter_settings', {})
    
    confirm_message = f"🔗 <b>Konfirmasi Twitter Scraping</b>\n\n"
    confirm_message += f"👥 <b>Usernames:</b> {len(usernames)}\n"
    
    for i, username in enumerate(usernames[:5], 1):  # Show first 5
        confirm_message += f"{i}. @{username}\n"
    
    if len(usernames) > 5:
        confirm_message += f"... and {len(usernames) - 5} more\n"
    
    confirm_message += f"\n⚙️ <b>Settings:</b>\n"
    confirm_message += f"📝 Include tweets: {'Yes' if settings.get('include_tweets') else 'No'}\n"
    confirm_message += f"🖼️ Include media: {'Yes' if settings.get('include_media') else 'No'}\n"
    confirm_message += f"📊 Max tweets per user: {settings.get('tweet_count', 20)}\n\n"
    
    # Estimate what will be downloaded
    total_tweets = len(usernames) * settings.get('tweet_count', 20)
    confirm_message += f"📈 <b>Estimation:</b>\n"
    confirm_message += f"📝 Max tweets to scan: {total_tweets}\n"
    confirm_message += f"🖼️ Expected media files: 10-50 per user\n"
    confirm_message += f"⏱️ Estimated time: {len(usernames) * 2}-{len(usernames) * 5} minutes\n\n"
    confirm_message += f"❓ Start scraping?"
    
    keyboard = [
        [
            InlineKeyboardButton("✅ Start Scraping", callback_data="twitter_start_scrape"),
            InlineKeyboardButton("⚙️ Change Settings", callback_data="twitter_change_settings")
        ],
        [InlineKeyboardButton("❌ Cancel", callback_data="twitter_cancel")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.message.reply_text(
        confirm_message,
        parse_mode='HTML',
        reply_markup=reply_markup
    )
    
    return TWITTER_CONFIRM

async def execute_twitter_scraping(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Execute Twitter scraping process"""
    user_id = update.effective_user.id
    usernames = context.user_data.get('twitter_usernames', [])
    settings = context.user_data.get('twitter_settings', {})
    
    if not usernames:
        await update.callback_query.answer("No usernames to scrape")
        return
    
    primary_account = get_primary_gdrive_account(user_id)
    if not primary_account:
        await update.callback_query.answer("No Google Drive account connected")
        return
    
    await update.callback_query.answer("Starting Twitter scraping...")
    
    # Initialize progress message
    progress_message = f"🔗 <b>Twitter Scraping Progress</b>\n\n"
    progress_message += f"👥 Users to scrape: {len(usernames)}\n"
    progress_message += f"✅ Completed: 0\n"
    progress_message += f"❌ Failed: 0\n"
    progress_message += f"📊 Progress: 0%\n"
    progress_message += f"🔄 Current: Initializing..."
    
    progress_msg = await update.callback_query.edit_message_text(
        progress_message,
        parse_mode='HTML'
    )
    
    try:
        # Execute scraping
        if len(usernames) == 1:
            # Single user scraping
            result = twitter_scraper.scrape_user_profile(
                usernames[0],
                include_tweets=settings.get('include_tweets', True),
                include_media=settings.get('include_media', True),
                tweet_count=settings.get('tweet_count', 20)
            )
            results = [result] if result.get('success') else []
            errors = [{'username': usernames[0], 'error': result.get('error', 'Unknown error')}] if not result.get('success') else []
        else:
            # Batch scraping
            batch_result = twitter_scraper.batch_scrape_users(
                usernames,
                include_tweets=settings.get('include_tweets', True),
                include_media=settings.get('include_media', True),
                tweet_count=settings.get('tweet_count', 10)
            )
            results = batch_result.get('results', [])
            errors = batch_result.get('errors', [])
        
        # Update progress during scraping (simplified for demo)
        for i in range(len(usernames)):
            progress = ((i + 1) / len(usernames)) * 50  # 50% for scraping
            current_user = usernames[i] if i < len(usernames) else "Finishing..."
            
            updated_message = f"🔗 <b>Twitter Scraping Progress</b>\n\n"
            updated_message += f"👥 Users to scrape: {len(usernames)}\n"
            updated_message += f"✅ Completed: {i}\n"
            updated_message += f"❌ Failed: 0\n"
            updated_message += f"📊 Progress: {progress:.1f}%\n"
            updated_message += f"🔄 Current: @{current_user}"
            
            try:
                await progress_msg.edit_text(updated_message, parse_mode='HTML')
                await asyncio.sleep(2)  # Simulate processing time
            except:
                pass
        
        # Upload files to Google Drive
        drive_manager = GoogleDriveManager(primary_account['credentials_json'])
        uploaded_files = []
        
        for result in results:
            if result['status'] == 'success':
                user_data = result['data']
                media_files = user_data.get('media_files', [])
                
                for media in media_files:
                    file_path = media.get('local_path')
                    if file_path and os.path.exists(file_path):
                        filename = f"{result['username']}_{os.path.basename(file_path)}"
                        
                        upload_result = drive_manager.upload_file(file_path, filename)
                        if upload_result:
                            uploaded_files.append({
                                'username': result['username'],
                                'filename': filename,
                                'gdrive_id': upload_result['id'],
                                'original_path': file_path
                            })
                        
                        # Clean up local file
                        try:
                            os.remove(file_path)
                        except:
                            pass
        
        # Final result message
        success_count = len([r for r in results if r.get('status') == 'success'])
        fail_count = len(errors)
        
        result_message = f"🔗 <b>Twitter Scraping Completed!</b>\n\n"
        result_message += f"📊 <b>Summary:</b>\n"
        result_message += f"👥 Total users: {len(usernames)}\n"
        result_message += f"✅ Successful: {success_count}\n"
        result_message += f"❌ Failed: {fail_count}\n"
        result_message += f"📁 Files uploaded: {len(uploaded_files)}\n"
        result_message += f"📈 Success rate: {(success_count/len(usernames)*100) if usernames else 0:.1f}%\n\n"
        
        if uploaded_files:
            result_message += f"✅ <b>Successfully scraped:</b>\n"
            scraped_users = list(set([f['username'] for f in uploaded_files]))
            for username in scraped_users[:5]:  # Show first 5
                user_files = [f for f in uploaded_files if f['username'] == username]
                result_message += f"📁 @{username}: {len(user_files)} files\n"
            
            if len(scraped_users) > 5:
                result_message += f"... and {len(scraped_users) - 5} more users\n"
        
        if errors:
            result_message += f"\n❌ <b>Failed users:</b>\n"
            for error in errors[:3]:  # Show first 3
                result_message += f"👤 @{error['username']}: {error['error'][:30]}...\n"
        
        result_message += f"\n📧 Files uploaded to: {primary_account['account_email']}"
        
        keyboard = [
            [InlineKeyboardButton("📊 View Details", callback_data="twitter_view_results")],
            [InlineKeyboardButton("🗂️ Browse GDrive", callback_data="gdrive_browse")],
            [InlineKeyboardButton("🔄 Scrape More", callback_data="twitter_single")],
            [InlineKeyboardButton("🏠 Main Menu", callback_data="show_main_menu")]
        ]
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await progress_msg.edit_text(result_message, parse_mode='HTML', reply_markup=reply_markup)
        
        # Log the scraping activity
        log_activity(
            user_id=user_id,
            action="twitter_scrape",
            details=f"Scraped {success_count}/{len(usernames)} users, {len(uploaded_files)} files uploaded",
            gdrive_account_id=primary_account['id']
        )
        
        # Store results for detailed view
        context.user_data['last_scrape_results'] = {
            'usernames': usernames,
            'results': results,
            'errors': errors,
            'uploaded_files': uploaded_files
        }
        
    except Exception as e:
        logger.error(f"Error in Twitter scraping for user {user_id}: {e}")
        
        error_message = f"❌ <b>Scraping Failed</b>\n\n"
        error_message += f"Error: {str(e)}\n\n"
        error_message += f"🔄 Please try again or contact admin if issue persists."
        
        keyboard = [
            [InlineKeyboardButton("🔄 Try Again", callback_data="twitter_single")],
            [InlineKeyboardButton("💬 Contact Admin", callback_data="contact_admin_start")],
            [InlineKeyboardButton("🏠 Main Menu", callback_data="show_main_menu")]
        ]
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await progress_msg.edit_text(error_message, parse_mode='HTML', reply_markup=reply_markup)
    
    finally:
        # Clear scraping data
        context.user_data.pop('twitter_usernames', None)
        context.user_data.pop('twitter_settings', None)
        context.user_data.pop('twitter_mode', None)

async def show_scraping_history(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show Twitter scraping history"""
    user_id = update.effective_user.id
    
    from database import get_user_logs
    logs = get_user_logs(user_id, limit=20)
    
    # Filter Twitter scraping logs
    scrape_logs = [log for log in logs if 'twitter' in log.get('action', '').lower() or 'scrape' in log.get('action', '').lower()]
    
    history_message = f"📊 <b>Twitter Scraping History</b>\n\n"
    
    if not scrape_logs:
        history_message += "📝 Belum ada riwayat scraping."
        
        keyboard = [
            [InlineKeyboardButton("🔗 Start Scraping", callback_data="twitter_single")],
            [InlineKeyboardButton("🔙 Back", callback_data="twitter_menu")]
        ]
    else:
        history_message += f"📋 Recent scraping activity ({len(scrape_logs)}):\n\n"
        
        for log in scrape_logs[:5]:
            timestamp = log['created_at'][:16]  # YYYY-MM-DD HH:MM
            details = log.get('details', 'Unknown')[:30]
            status = "✅" if log.get('status') == 'success' else "❌"
            
            history_message += f"{status} {timestamp}\n"
            history_message += f"   📝 {details}\n\n"
        
        keyboard = [
            [
                InlineKeyboardButton("🔄 Refresh", callback_data="twitter_history"),
                InlineKeyboardButton("📥 Export History", callback_data="twitter_export_history")
            ],
            [
                InlineKeyboardButton("🔗 New Scraping", callback_data="twitter_single"),
                InlineKeyboardButton("🔙 Back", callback_data="twitter_menu")
            ]
        ]
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.callback_query.edit_message_text(
        history_message,
        parse_mode='HTML',
        reply_markup=reply_markup
    )

async def show_twitter_settings(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show Twitter scraping settings"""
    settings_message = (
        f"⚙️ <b>Twitter Scraper Settings</b>\n\n"
        f"📊 <b>Current Limits:</b>\n"
        f"📈 Max scrapes per day: {Config.MAX_SCRAPING_PER_DAY}\n"
        f"📋 Max usernames per batch: 10\n"
        f"📝 Max tweets per user: 50\n"
        f"⏱️ Rate limit delay: 2 seconds\n\n"
        f"🎯 <b>Default Settings:</b>\n"
        f"📝 Include tweets: Enabled\n"
        f"🖼️ Include media: Enabled\n"
        f"📊 Tweet count: 20 (single) / 10 (batch)\n"
        f"🔄 Auto-retry: Enabled\n"
        f"📁 Auto-upload: Enabled\n\n"
        f"🛡️ <b>Rate Limiting:</b>\n"
        f"✅ Twitter API compliance\n"
        f"✅ Smart delay between requests\n"
        f"✅ Error handling and retry\n"
        f"✅ Account protection\n\n"
        f"💡 <b>Tips for Better Results:</b>\n"
        f"• Use public accounts for best results\n"
        f"• Avoid scraping too frequently\n"
        f"• Check account quota before scraping\n"
        f"• Monitor Google Drive storage"
    )
    
    keyboard = [
        [
            InlineKeyboardButton("📊 Check Quota", callback_data="gdrive_storage"),
            InlineKeyboardButton("📝 View Limits", callback_data="twitter_view_limits")
        ],
        [
            InlineKeyboardButton("🔧 Advanced Settings", callback_data="twitter_advanced_settings"),
            InlineKeyboardButton("❓ Help", callback_data="twitter_help")
        ],
        [InlineKeyboardButton("🔙 Back", callback_data="twitter_menu")]
    ]
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.callback_query.edit_message_text(
        settings_message,
        parse_mode='HTML',
        reply_markup=reply_markup
    )

async def show_scrape_results(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show detailed scraping results"""
    results_data = context.user_data.get('last_scrape_results')
    
    if not results_data:
        await update.callback_query.answer("No recent scraping results")
        return
    
    usernames = results_data.get('usernames', [])
    results = results_data.get('results', [])
    errors = results_data.get('errors', [])
    uploaded_files = results_data.get('uploaded_files', [])
    
    details_message = f"📊 <b>Detailed Scraping Results</b>\n\n"
    
    # Overall stats
    success_count = len([r for r in results if r.get('status') == 'success'])
    details_message += f"📈 <b>Overview:</b>\n"
    details_message += f"👥 Total users: {len(usernames)}\n"
    details_message += f"✅ Successful: {success_count}\n"
    details_message += f"❌ Failed: {len(errors)}\n"
    details_message += f"📁 Files uploaded: {len(uploaded_files)}\n\n"
    
    # Successful users breakdown
    if results:
        details_message += f"✅ <b>Successful Scrapes:</b>\n"
        for result in results[:3]:  # Show first 3
            if result.get('status') == 'success':
                username = result['username']
                data = result['data']
                tweets = len(data.get('tweets', []))
                media = len(data.get('media_files', []))
                
                details_message += f"👤 @{username}\n"
                details_message += f"   📝 Tweets: {tweets}\n"
                details_message += f"   🖼️ Media: {media}\n\n"
        
        if len(results) > 3:
            details_message += f"... and {len(results) - 3} more users\n\n"
    
    # Failed users
    if errors:
        details_message += f"❌ <b>Failed Scrapes:</b>\n"
        for error in errors[:3]:  # Show first 3
            details_message += f"👤 @{error['username']}\n"
            details_message += f"   Error: {error['error'][:40]}...\n\n"
        
        if len(errors) > 3:
            details_message += f"... and {len(errors) - 3} more failures\n\n"
    
    # File breakdown
    if uploaded_files:
        file_types = {}
        total_size = 0
        
        for file in uploaded_files:
            ext = file['filename'].split('.')[-1].lower() if '.' in file['filename'] else 'unknown'
            file_types[ext] = file_types.get(ext, 0) + 1
            
            # Try to get file size (simplified)
            try:
                size = os.path.getsize(file.get('original_path', ''))
                total_size += size
            except:
                pass
        
        details_message += f"📁 <b>File Breakdown:</b>\n"
        for ext, count in sorted(file_types.items(), key=lambda x: x[1], reverse=True):
            details_message += f"📄 .{ext}: {count} files\n"
        
        if total_size > 0:
            details_message += f"\n📏 Total size: {format_file_size(total_size)}"
    
    keyboard = [
        [
            InlineKeyboardButton("🗂️ Browse Files", callback_data="gdrive_browse"),
            InlineKeyboardButton("📥 Export Report", callback_data="twitter_export_results")
        ],
        [
            InlineKeyboardButton("🔄 Scrape More", callback_data="twitter_single"),
            InlineKeyboardButton("🔙 Back", callback_data="twitter_menu")
        ]
    ]
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.callback_query.edit_message_text(
        details_message,
        parse_mode='HTML',
        reply_markup=reply_markup
    )

async def handle_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle Twitter scraper callback queries"""
    query = update.callback_query
    data = query.data
    
    if data == "twitter_menu":
        await show_twitter_menu(update, context)
    elif data == "twitter_single":
        await start_single_user_scrape(update, context)
    elif data == "twitter_batch":
        await start_batch_user_scrape(update, context)
    elif data == "twitter_media_only":
        await set_media_only_mode(update, context)
    elif data == "twitter_full":
        await set_full_scrape_mode(update, context)
    elif data == "twitter_start_scrape":
        await execute_twitter_scraping(update, context)
    elif data == "twitter_cancel":
        context.user_data.pop('twitter_usernames', None)
        context.user_data.pop('twitter_settings', None)
        context.user_data.pop('twitter_mode', None)
        
        await update.callback_query.edit_message_text(
            "❌ Twitter scraping dibatalkan.",
            reply_markup=InlineKeyboardMarkup([[
                InlineKeyboardButton("🔙 Back to Twitter", callback_data="twitter_menu")
            ]])
        )
    elif data == "twitter_history":
        await show_scraping_history(update, context)
    elif data == "twitter_settings":
        await show_twitter_settings(update, context)
    elif data == "twitter_view_results":
        await show_scrape_results(update, context)

def get_conversation_handler():
    """Get conversation handler for Twitter scraping"""
    return ConversationHandler(
        entry_points=[],
        states={
            TWITTER_USERNAMES: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, handle_username_input)
            ],
            TWITTER_CONFIRM: []
        },
        fallbacks=[
            MessageHandler(filters.Regex("^/cancel$"), lambda u, c: ConversationHandler.END)
        ],
        allow_reentry=True
    )
