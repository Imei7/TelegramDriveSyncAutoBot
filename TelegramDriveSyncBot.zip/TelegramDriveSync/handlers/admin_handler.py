"""
TelegramDriveSync Bot - Admin Handler
Panel admin, kelola user, broadcast, share file/log
"""

import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes, ConversationHandler
from database import (
    get_all_users, get_database_stats, get_all_logs, get_authorized_groups,
    add_authorized_group, log_activity, get_user_by_id, update_user_payment
)
from config import Config
from utils import (
    create_admin_menu_keyboard, create_pagination_keyboard, paginate_items,
    format_user_info, format_log_entry, create_yes_no_keyboard
)
from datetime import datetime
import json

logger = logging.getLogger(__name__)

# Conversation states
BROADCAST_MESSAGE, BROADCAST_CONFIRM, ADD_GROUP, EDIT_MESSAGE = range(4)

async def show_admin_panel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show main admin panel"""
    user_id = update.effective_user.id
    
    if user_id not in Config.ADMIN_IDS:
        await update.message.reply_text("❌ Akses ditolak. Anda bukan admin.")
        return
    
    # Get database stats
    stats = get_database_stats()
    
    panel_message = (
        f"👑 <b>Panel Admin TelegramDriveSync</b>\n\n"
        f"📊 <b>Statistik:</b>\n"
        f"👥 Total Users: {stats.get('users', {}).get('total', 0)}\n"
        f"💳 Paid Users: {stats.get('users', {}).get('paid', 0)}\n"
        f"📁 GDrive Accounts: {stats.get('gdrive_accounts', 0)}\n"
        f"📝 Activity Logs: {stats.get('activity_logs', 0)}\n"
        f"🎫 Support Tickets: {stats.get('support_tickets', {}).get('total', 0)} "
        f"({stats.get('support_tickets', {}).get('open', 0)} open)\n\n"
        f"⏰ <i>Last updated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</i>"
    )
    
    keyboard = create_admin_menu_keyboard()
    
    await update.message.reply_text(
        panel_message,
        parse_mode='HTML',
        reply_markup=keyboard
    )

async def handle_text_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle admin text messages"""
    text = update.message.text
    user_id = update.effective_user.id
    
    if user_id not in Config.ADMIN_IDS:
        return
    
    if text == "👥 Kelola User":
        await show_user_management(update, context)
    elif text == "💳 Kelola Paket":
        await show_package_management(update, context)
    elif text == "📊 Statistik":
        await show_detailed_statistics(update, context)
    elif text == "📄 Laporan":
        await show_reports_menu(update, context)
    elif text == "🧼 Pembersihan":
        await show_cleanup_menu(update, context)
    elif text == "📢 Broadcast":
        await start_broadcast(update, context)
    elif text == "📤 Share ke Grup":
        await show_group_share_menu(update, context)
    elif text == "🔗 Kelola Grup":
        await show_group_management(update, context)
    elif text == "⚙️ Pengaturan Bot":
        await show_bot_settings(update, context)
    elif text == "🏠 Menu Utama":
        await show_admin_panel(update, context)

async def show_user_management(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show user management interface"""
    page = context.user_data.get('user_page', 1)
    
    users = get_all_users()
    paginated_users, pagination_info = paginate_items(users, page, 5)
    
    message = f"👥 <b>Kelola User</b> (Page {pagination_info['current_page']}/{pagination_info['total_pages']})\n\n"
    
    keyboard = []
    
    for user in paginated_users:
        user_info = f"👤 {user.get('first_name', 'Unknown')} "
        if user.get('username'):
            user_info += f"(@{user['username']})"
        
        status = "💳" if user.get('is_paid') else "🆓"
        oauth = "🔐" if user.get('oauth_complete') else "❌"
        
        message += f"{status}{oauth} {user_info}\n"
        message += f"   ID: <code>{user['user_id']}</code>\n\n"
        
        # Add inline buttons for each user
        keyboard.append([
            InlineKeyboardButton(f"👤 {user['first_name'][:15]}...", 
                               callback_data=f"admin_user_{user['user_id']}")
        ])
    
    # Add pagination
    if pagination_info['total_pages'] > 1:
        pagination_keyboard = create_pagination_keyboard('admin_users', 
                                                       pagination_info['current_page'],
                                                       pagination_info['total_pages'])
        keyboard.extend(pagination_keyboard.inline_keyboard)
    
    # Add action buttons
    keyboard.append([
        InlineKeyboardButton("🔍 Search User", callback_data="admin_search_user"),
        InlineKeyboardButton("📊 Export Data", callback_data="admin_export_users")
    ])
    
    keyboard.append([InlineKeyboardButton("🔙 Back", callback_data="admin_back_main")])
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    if update.callback_query:
        await update.callback_query.edit_message_text(
            message, parse_mode='HTML', reply_markup=reply_markup
        )
    else:
        await update.message.reply_text(
            message, parse_mode='HTML', reply_markup=reply_markup
        )

async def show_detailed_statistics(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show detailed bot statistics"""
    stats = get_database_stats()
    
    # Get recent activity
    recent_logs = get_all_logs(limit=10)
    
    stats_message = (
        f"📊 <b>Detailed Statistics</b>\n\n"
        f"👥 <b>Users:</b>\n"
        f"   Total: {stats.get('users', {}).get('total', 0)}\n"
        f"   Paid: {stats.get('users', {}).get('paid', 0)}\n"
        f"   Free: {stats.get('users', {}).get('total', 0) - stats.get('users', {}).get('paid', 0)}\n\n"
        f"📁 <b>Google Drive:</b>\n"
        f"   Connected Accounts: {stats.get('gdrive_accounts', 0)}\n\n"
        f"📝 <b>Activity:</b>\n"
        f"   Total Logs: {stats.get('activity_logs', 0)}\n"
        f"   Recent Activities: {len(recent_logs)}\n\n"
        f"🎫 <b>Support:</b>\n"
        f"   Total Tickets: {stats.get('support_tickets', {}).get('total', 0)}\n"
        f"   Open Tickets: {stats.get('support_tickets', {}).get('open', 0)}\n\n"
    )
    
    # Add recent activity summary
    if recent_logs:
        stats_message += f"📋 <b>Recent Activity:</b>\n"
        for log in recent_logs[:5]:
            user_name = log.get('first_name', 'Unknown')[:10]
            action = log.get('action', 'Unknown')[:15]
            timestamp = datetime.fromisoformat(log['created_at']).strftime('%m/%d %H:%M')
            stats_message += f"   {timestamp} - {user_name}: {action}\n"
    
    keyboard = [
        [InlineKeyboardButton("📈 Refresh Stats", callback_data="admin_refresh_stats")],
        [InlineKeyboardButton("📊 Export Report", callback_data="admin_export_stats")],
        [InlineKeyboardButton("🔙 Back", callback_data="admin_back_main")]
    ]
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    if update.callback_query:
        await update.callback_query.edit_message_text(
            stats_message, parse_mode='HTML', reply_markup=reply_markup
        )
    else:
        await update.message.reply_text(
            stats_message, parse_mode='HTML', reply_markup=reply_markup
        )

async def start_broadcast(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Start broadcast message flow"""
    context.user_data['broadcast_step'] = 'message'
    
    message = (
        f"📢 <b>Broadcast Message</b>\n\n"
        f"Silakan ketik pesan yang ingin Anda broadcast ke semua user.\n\n"
        f"💡 <b>Tips:</b>\n"
        f"   • Gunakan HTML formatting jika diperlukan\n"
        f"   • Pesan akan dikirim ke semua user yang sudah bayar\n"
        f"   • Ketik /cancel untuk membatalkan\n\n"
        f"✍️ <i>Ketik pesan Anda:</i>"
    )
    
    keyboard = [[InlineKeyboardButton("❌ Cancel", callback_data="admin_cancel_broadcast")]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    if update.callback_query:
        await update.callback_query.edit_message_text(
            message, parse_mode='HTML', reply_markup=reply_markup
        )
    else:
        await update.message.reply_text(
            message, parse_mode='HTML', reply_markup=reply_markup
        )
    
    return BROADCAST_MESSAGE

async def handle_broadcast_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle broadcast message input"""
    message = update.message.text
    
    if message == "/cancel":
        await update.message.reply_text("❌ Broadcast dibatalkan.")
        return ConversationHandler.END
    
    context.user_data['broadcast_message'] = message
    
    # Get user count for confirmation
    users = get_all_users()
    paid_users = [u for u in users if u.get('is_paid')]
    
    confirmation_message = (
        f"📢 <b>Konfirmasi Broadcast</b>\n\n"
        f"📝 <b>Pesan:</b>\n"
        f"{message}\n\n"
        f"👥 <b>Target:</b> {len(paid_users)} paid users\n\n"
        f"❓ Apakah Anda yakin ingin mengirim broadcast ini?"
    )
    
    keyboard = [
        [
            InlineKeyboardButton("✅ Send Now", callback_data="admin_confirm_broadcast"),
            InlineKeyboardButton("⏰ Schedule", callback_data="admin_schedule_broadcast")
        ],
        [InlineKeyboardButton("❌ Cancel", callback_data="admin_cancel_broadcast")]
    ]
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.message.reply_text(
        confirmation_message, parse_mode='HTML', reply_markup=reply_markup
    )
    
    return BROADCAST_CONFIRM

async def show_group_management(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show group management interface"""
    groups = get_authorized_groups()
    
    message = f"🔗 <b>Kelola Grup</b>\n\n"
    
    if not groups:
        message += "📝 Belum ada grup yang diotorisasi.\n\n"
    else:
        message += f"📊 Total grup: {len(groups)}\n\n"
        
        for group in groups[-5:]:  # Show last 5 groups
            title = group.get('group_title', 'Unknown')[:20]
            status = "✅" if group.get('status') == 'approved' else "⏳"
            message += f"{status} {title}\n"
            message += f"   ID: <code>{group['group_id']}</code>\n\n"
    
    keyboard = [
        [InlineKeyboardButton("➕ Add Group", callback_data="admin_add_group")],
        [InlineKeyboardButton("📋 View All", callback_data="admin_view_groups")],
        [InlineKeyboardButton("🔄 Refresh", callback_data="admin_refresh_groups")],
        [InlineKeyboardButton("🔙 Back", callback_data="admin_back_main")]
    ]
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    if update.callback_query:
        await update.callback_query.edit_message_text(
            message, parse_mode='HTML', reply_markup=reply_markup
        )
    else:
        await update.message.reply_text(
            message, parse_mode='HTML', reply_markup=reply_markup
        )

async def show_bot_settings(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show bot settings menu"""
    settings_message = (
        f"⚙️ <b>Bot Settings</b>\n\n"
        f"🔧 <b>Current Configuration:</b>\n"
        f"   Max File Size: {Config.MAX_FILE_SIZE // (1024*1024)} MB\n"
        f"   Items Per Page: {Config.ITEMS_PER_PAGE}\n"
        f"   Max Uploads/Hour: {Config.MAX_UPLOADS_PER_HOUR}\n"
        f"   Log Retention: {Config.LOG_RETENTION_DAYS} days\n"
        f"   Auto Cleanup: {Config.AUTO_CLEANUP_DAYS} days\n\n"
        f"📢 <b>Broadcast Settings:</b>\n"
        f"   Chunk Size: {Config.BROADCAST_CHUNK_SIZE}\n"
        f"   Delay: {Config.BROADCAST_DELAY_SECONDS}s\n\n"
        f"🔄 <b>Retry Settings:</b>\n"
        f"   Max Retries: {Config.MAX_RETRIES}\n"
        f"   Retry Delay: {Config.RETRY_DELAY_SECONDS}s"
    )
    
    keyboard = [
        [InlineKeyboardButton("📝 Edit Messages", callback_data="admin_edit_messages")],
        [InlineKeyboardButton("🔄 Restart Bot", callback_data="admin_restart_bot")],
        [InlineKeyboardButton("📊 System Info", callback_data="admin_system_info")],
        [InlineKeyboardButton("🔙 Back", callback_data="admin_back_main")]
    ]
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    if update.callback_query:
        await update.callback_query.edit_message_text(
            settings_message, parse_mode='HTML', reply_markup=reply_markup
        )
    else:
        await update.message.reply_text(
            settings_message, parse_mode='HTML', reply_markup=reply_markup
        )

async def handle_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle admin callback queries"""
    query = update.callback_query
    data = query.data
    
    if data == "admin_back_main":
        await show_admin_panel(update, context)
    elif data.startswith("admin_users_page_"):
        page = int(data.split("_")[-1])
        context.user_data['user_page'] = page
        await show_user_management(update, context)
    elif data == "admin_refresh_stats":
        await show_detailed_statistics(update, context)
    elif data.startswith("admin_user_"):
        user_id = int(data.split("_")[-1])
        await show_user_details(update, context, user_id)
    elif data == "admin_confirm_broadcast":
        await execute_broadcast(update, context)
    elif data == "admin_cancel_broadcast":
        await cancel_broadcast(update, context)
    elif data == "admin_schedule_broadcast":
        await schedule_broadcast_menu(update, context)
    elif data == "admin_add_group":
        await start_add_group(update, context)
    elif data == "admin_view_groups":
        await show_all_groups(update, context)
    elif data == "admin_refresh_groups":
        await show_group_management(update, context)
    elif data == "admin_edit_messages":
        await show_message_editor(update, context)
    elif data == "admin_system_info":
        await show_system_info(update, context)

async def show_user_details(update: Update, context: ContextTypes.DEFAULT_TYPE, user_id: int):
    """Show detailed user information"""
    user = get_user_by_id(user_id)
    if not user:
        await update.callback_query.answer("User not found")
        return
    
    user_info = format_user_info(user)
    
    # Get user's recent activity
    from database import get_user_logs
    recent_logs = get_user_logs(user_id, limit=5)
    
    if recent_logs:
        user_info += f"\n\n📋 <b>Recent Activity:</b>\n"
        for log in recent_logs:
            timestamp = datetime.fromisoformat(log['created_at']).strftime('%m/%d %H:%M')
            action = log.get('action', 'Unknown')[:20]
            user_info += f"   {timestamp}: {action}\n"
    
    keyboard = [
        [
            InlineKeyboardButton("💳 Toggle Payment", callback_data=f"admin_toggle_payment_{user_id}"),
            InlineKeyboardButton("🔐 Reset OAuth", callback_data=f"admin_reset_oauth_{user_id}")
        ],
        [
            InlineKeyboardButton("📝 View Logs", callback_data=f"admin_user_logs_{user_id}"),
            InlineKeyboardButton("🎫 View Tickets", callback_data=f"admin_user_tickets_{user_id}")
        ],
        [
            InlineKeyboardButton("❌ Ban User", callback_data=f"admin_ban_user_{user_id}"),
            InlineKeyboardButton("💬 Message User", callback_data=f"admin_message_user_{user_id}")
        ],
        [InlineKeyboardButton("🔙 Back", callback_data="admin_users_page_1")]
    ]
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.callback_query.edit_message_text(
        user_info, parse_mode='HTML', reply_markup=reply_markup
    )

async def execute_broadcast(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Execute immediate broadcast"""
    message = context.user_data.get('broadcast_message')
    if not message:
        await update.callback_query.answer("No message to broadcast")
        return
    
    await update.callback_query.answer("Starting broadcast...")
    
    # Get all paid users
    users = get_all_users()
    paid_users = [u for u in users if u.get('is_paid')]
    
    # Start broadcast process
    success_count = 0
    fail_count = 0
    
    progress_message = f"📢 <b>Broadcasting...</b>\n\n"
    progress_message += f"👥 Target users: {len(paid_users)}\n"
    progress_message += f"✅ Sent: {success_count}\n"
    progress_message += f"❌ Failed: {fail_count}\n"
    progress_message += f"📊 Progress: 0%"
    
    progress_msg = await update.callback_query.edit_message_text(
        progress_message, parse_mode='HTML'
    )
    
    import asyncio
    
    for i, user in enumerate(paid_users):
        try:
            await context.bot.send_message(
                chat_id=user['user_id'],
                text=message,
                parse_mode='HTML'
            )
            success_count += 1
        except Exception as e:
            logger.error(f"Failed to broadcast to user {user['user_id']}: {e}")
            fail_count += 1
        
        # Update progress every 5 users
        if (i + 1) % 5 == 0 or i == len(paid_users) - 1:
            progress = ((i + 1) / len(paid_users)) * 100
            updated_message = f"📢 <b>Broadcasting...</b>\n\n"
            updated_message += f"👥 Target users: {len(paid_users)}\n"
            updated_message += f"✅ Sent: {success_count}\n"
            updated_message += f"❌ Failed: {fail_count}\n"
            updated_message += f"📊 Progress: {progress:.1f}%"
            
            try:
                await progress_msg.edit_text(updated_message, parse_mode='HTML')
            except:
                pass
        
        # Add delay to avoid rate limiting
        await asyncio.sleep(Config.BROADCAST_DELAY_SECONDS)
    
    # Final result
    final_message = (
        f"📢 <b>Broadcast Completed!</b>\n\n"
        f"👥 Target users: {len(paid_users)}\n"
        f"✅ Successfully sent: {success_count}\n"
        f"❌ Failed: {fail_count}\n"
        f"📈 Success rate: {(success_count/len(paid_users)*100) if paid_users else 0:.1f}%\n\n"
        f"⏰ Completed at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
    )
    
    keyboard = [[InlineKeyboardButton("🔙 Back to Admin", callback_data="admin_back_main")]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await progress_msg.edit_text(final_message, parse_mode='HTML', reply_markup=reply_markup)
    
    # Log the broadcast
    log_activity(
        user_id=update.effective_user.id,
        action="admin_broadcast",
        details=f"Broadcast sent to {success_count}/{len(paid_users)} users"
    )
    
    # Clear the broadcast data
    context.user_data.pop('broadcast_message', None)

async def cancel_broadcast(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Cancel broadcast operation"""
    context.user_data.pop('broadcast_message', None)
    
    await update.callback_query.edit_message_text(
        "❌ Broadcast dibatalkan.",
        reply_markup=InlineKeyboardMarkup([[
            InlineKeyboardButton("🔙 Back to Admin", callback_data="admin_back_main")
        ]])
    )

async def show_reports_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show reports and export menu"""
    message = (
        f"📄 <b>Laporan & Export</b>\n\n"
        f"📊 Pilih jenis laporan yang ingin Anda export:\n\n"
        f"👥 User Reports - Data semua user\n"
        f"📝 Activity Reports - Log aktivitas\n"
        f"💳 Payment Reports - Riwayat pembayaran\n"
        f"🎫 Support Reports - Tiket support\n"
        f"📁 GDrive Reports - Akun Google Drive"
    )
    
    keyboard = [
        [
            InlineKeyboardButton("👥 Users", callback_data="admin_export_users"),
            InlineKeyboardButton("📝 Activity", callback_data="admin_export_activity")
        ],
        [
            InlineKeyboardButton("💳 Payments", callback_data="admin_export_payments"),
            InlineKeyboardButton("🎫 Support", callback_data="admin_export_support")
        ],
        [
            InlineKeyboardButton("📁 GDrive", callback_data="admin_export_gdrive"),
            InlineKeyboardButton("📊 Full Report", callback_data="admin_export_full")
        ],
        [InlineKeyboardButton("🔙 Back", callback_data="admin_back_main")]
    ]
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    if update.callback_query:
        await update.callback_query.edit_message_text(
            message, parse_mode='HTML', reply_markup=reply_markup
        )
    else:
        await update.message.reply_text(
            message, parse_mode='HTML', reply_markup=reply_markup
        )

async def show_cleanup_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show cleanup options"""
    message = (
        f"🧼 <b>Pembersihan Data</b>\n\n"
        f"⚠️ <b>PERINGATAN:</b> Operasi ini akan menghapus data secara permanen!\n\n"
        f"📝 Log lama (>90 hari)\n"
        f"📁 File temporary (>24 jam)\n"
        f"🗑️ Data user yang tidak aktif\n"
        f"📧 Pesan support yang sudah ditutup\n\n"
        f"💡 Backup database sebelum melakukan cleanup!"
    )
    
    keyboard = [
        [
            InlineKeyboardButton("📝 Clean Logs", callback_data="admin_cleanup_logs"),
            InlineKeyboardButton("📁 Clean Files", callback_data="admin_cleanup_files")
        ],
        [
            InlineKeyboardButton("🗑️ Clean Inactive", callback_data="admin_cleanup_inactive"),
            InlineKeyboardButton("🧹 Full Cleanup", callback_data="admin_cleanup_all")
        ],
        [InlineKeyboardButton("🔙 Back", callback_data="admin_back_main")]
    ]
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    if update.callback_query:
        await update.callback_query.edit_message_text(
            message, parse_mode='HTML', reply_markup=reply_markup
        )
    else:
        await update.message.reply_text(
            message, parse_mode='HTML', reply_markup=reply_markup
        )

def get_conversation_handler():
    """Get conversation handler for admin operations"""
    return ConversationHandler(
        entry_points=[],
        states={
            BROADCAST_MESSAGE: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, handle_broadcast_message)
            ],
            BROADCAST_CONFIRM: [
                CallbackQueryHandler(handle_callback, pattern="^admin_(confirm|cancel|schedule)_broadcast$")
            ]
        },
        fallbacks=[
            CommandHandler('cancel', cancel_broadcast),
            CallbackQueryHandler(handle_callback, pattern="^admin_cancel")
        ]
    )
