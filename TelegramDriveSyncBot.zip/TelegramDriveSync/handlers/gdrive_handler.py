"""
TelegramDriveSync Bot - Google Drive Handler
Upload, browse, cek storage, auto-switch GDrive
"""

import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from database import (
    get_user_gdrive_accounts, get_primary_gdrive_account, update_gdrive_storage, log_activity
)
from config import Config
from utils import create_storage_progress, format_file_size, create_pagination_keyboard, paginate_items
import json
import asyncio

logger = logging.getLogger(__name__)

# Google Drive API setup (simplified for basic functionality)
class GoogleDriveManager:
    def __init__(self, credentials_json: str):
        self.credentials = json.loads(credentials_json)
        self.service = None
        self._setup_service()
    
    def _setup_service(self):
        """Setup Google Drive service (simplified)"""
        try:
            # In a real implementation, you would use google-api-python-client
            # For now, this is a placeholder structure
            self.service = {
                'authenticated': True,
                'quota_info': {
                    'used': 5000000000,  # 5GB
                    'total': 15000000000  # 15GB
                }
            }
            logger.info("Google Drive service initialized")
        except Exception as e:
            logger.error(f"Failed to setup Google Drive service: {e}")
            self.service = None
    
    def get_quota_info(self):
        """Get storage quota information"""
        if not self.service:
            return None
        
        # Simulated quota info - in real implementation, use drive.about().get()
        return self.service.get('quota_info', {})
    
    def list_files(self, folder_id='root', page_size=10):
        """List files in a folder"""
        if not self.service:
            return []
        
        # Simulated file list - in real implementation, use drive.files().list()
        return [
            {
                'id': 'file1',
                'name': 'Example Document.pdf',
                'mimeType': 'application/pdf',
                'size': '1024000',
                'modifiedTime': '2024-01-01T00:00:00.000Z'
            },
            {
                'id': 'file2', 
                'name': 'Sample Video.mp4',
                'mimeType': 'video/mp4',
                'size': '50000000',
                'modifiedTime': '2024-01-02T00:00:00.000Z'
            }
        ]
    
    def create_folder(self, name: str, parent_id='root'):
        """Create a new folder"""
        if not self.service:
            return None
        
        # Simulated folder creation
        return {
            'id': f'folder_{name}',
            'name': name,
            'mimeType': 'application/vnd.google-apps.folder'
        }
    
    def upload_file(self, file_path: str, filename: str, parent_id='root'):
        """Upload a file to Google Drive"""
        if not self.service:
            return None
        
        # Simulated file upload
        import os
        file_size = os.path.getsize(file_path) if os.path.exists(file_path) else 0
        
        return {
            'id': f'uploaded_{filename}',
            'name': filename,
            'size': str(file_size),
            'webViewLink': f'https://drive.google.com/file/d/uploaded_{filename}/view'
        }
    
    def get_file_stream_url(self, file_id: str):
        """Get streaming URL for a file"""
        if not self.service:
            return None
        
        # Simulated streaming URL
        return f'https://drive.google.com/uc?id={file_id}&export=download'

async def show_gdrive_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show Google Drive management menu"""
    user_id = update.effective_user.id
    accounts = get_user_gdrive_accounts(user_id)
    
    menu_message = f"🗂️ <b>Kelola Google Drive</b>\n\n"
    
    if not accounts:
        menu_message += (
            f"❌ Belum ada akun Google Drive terhubung.\n\n"
            f"Hubungkan akun Google Drive untuk mulai menggunakan fitur ini."
        )
        keyboard = [
            [InlineKeyboardButton("🔐 Hubungkan Akun", callback_data="oauth_start")],
            [InlineKeyboardButton("🔙 Back", callback_data="show_main_menu")]
        ]
    else:
        menu_message += f"📊 <b>Akun Terhubung:</b> {len(accounts)}\n\n"
        
        # Show primary account info
        primary = get_primary_gdrive_account(user_id)
        if primary:
            quota_info = await get_account_quota(primary)
            storage_progress = create_storage_progress(
                quota_info.get('used', 0),
                quota_info.get('total', 15000000000)
            )
            
            menu_message += (
                f"🎯 <b>Akun Utama:</b>\n"
                f"📧 {primary['account_email']}\n"
                f"{storage_progress}\n\n"
            )
        
        keyboard = [
            [
                InlineKeyboardButton("📁 Browse Files", callback_data="gdrive_browse"),
                InlineKeyboardButton("📊 Cek Storage", callback_data="gdrive_storage")
            ],
            [
                InlineKeyboardButton("🔄 Switch Akun", callback_data="gdrive_switch"),
                InlineKeyboardButton("➕ Tambah Akun", callback_data="oauth_add_account")
            ],
            [
                InlineKeyboardButton("📋 Kelola Akun", callback_data="gdrive_manage"),
                InlineKeyboardButton("🗂️ Buat Folder", callback_data="gdrive_create_folder")
            ],
            [InlineKeyboardButton("🔙 Back", callback_data="show_main_menu")]
        ]
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    if update.callback_query:
        await update.callback_query.edit_message_text(
            menu_message,
            parse_mode='HTML',
            reply_markup=reply_markup
        )
    else:
        await update.message.reply_text(
            menu_message,
            parse_mode='HTML',
            reply_markup=reply_markup
        )

async def show_storage_info(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show detailed storage information for all accounts"""
    user_id = update.effective_user.id
    accounts = get_user_gdrive_accounts(user_id)
    
    if not accounts:
        await update.callback_query.answer("No Google Drive accounts connected")
        return
    
    storage_message = f"📊 <b>Storage Information</b>\n\n"
    
    total_used = 0
    total_available = 0
    
    for i, account in enumerate(accounts, 1):
        quota_info = await get_account_quota(account)
        used = quota_info.get('used', 0)
        total = quota_info.get('total', 15000000000)
        
        total_used += used
        total_available += total
        
        status = "🎯" if account['is_primary'] else "📁"
        storage_progress = create_storage_progress(used, total)
        
        storage_message += (
            f"{status} <b>Akun {i}:</b>\n"
            f"📧 {account['account_email']}\n"
            f"{storage_progress}\n\n"
        )
    
    # Overall summary
    if len(accounts) > 1:
        overall_progress = create_storage_progress(total_used, total_available)
        storage_message += (
            f"📈 <b>Total Semua Akun:</b>\n"
            f"{overall_progress}\n"
        )
    
    keyboard = [
        [
            InlineKeyboardButton("🔄 Refresh", callback_data="gdrive_storage"),
            InlineKeyboardButton("⚙️ Auto-Switch", callback_data="gdrive_auto_switch")
        ],
        [InlineKeyboardButton("🔙 Back", callback_data="gdrive_menu")]
    ]
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.callback_query.edit_message_text(
        storage_message,
        parse_mode='HTML',
        reply_markup=reply_markup
    )

async def browse_files(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Browse files in Google Drive"""
    user_id = update.effective_user.id
    primary_account = get_primary_gdrive_account(user_id)
    
    if not primary_account:
        await update.callback_query.answer("No primary Google Drive account set")
        return
    
    # Get folder ID from callback data if available
    folder_id = context.user_data.get('current_folder', 'root')
    page = context.user_data.get('browse_page', 1)
    
    # Initialize Google Drive manager
    drive_manager = GoogleDriveManager(primary_account['credentials_json'])
    
    # Get files
    files = drive_manager.list_files(folder_id)
    paginated_files, pagination_info = paginate_items(files, page, 5)
    
    browse_message = f"📁 <b>Browse Files</b>\n"
    browse_message += f"📧 Account: {primary_account['account_email']}\n"
    browse_message += f"📂 Folder: {'Root' if folder_id == 'root' else 'Current'}\n\n"
    
    if not paginated_files:
        browse_message += "📝 Folder kosong atau tidak ada file.\n"
    else:
        browse_message += f"📋 Files ({pagination_info['start_index']}-{pagination_info['end_index']} of {pagination_info['total_items']}):\n\n"
        
        for file in paginated_files:
            file_type = "📁" if file['mimeType'] == 'application/vnd.google-apps.folder' else "📄"
            file_size = format_file_size(int(file.get('size', 0))) if file.get('size') else "N/A"
            
            browse_message += f"{file_type} <b>{file['name']}</b>\n"
            if file_type == "📄":
                browse_message += f"   📏 {file_size}\n"
            browse_message += "\n"
    
    # Create keyboard
    keyboard = []
    
    # File action buttons
    for file in paginated_files:
        file_type = "📁" if file['mimeType'] == 'application/vnd.google-apps.folder' else "📄"
        button_text = f"{file_type} {file['name'][:20]}..."
        callback_data = f"gdrive_file_{file['id']}" if file_type == "📄" else f"gdrive_folder_{file['id']}"
        keyboard.append([InlineKeyboardButton(button_text, callback_data=callback_data)])
    
    # Pagination
    if pagination_info['total_pages'] > 1:
        pagination_keyboard = create_pagination_keyboard('gdrive_browse', 
                                                       pagination_info['current_page'],
                                                       pagination_info['total_pages'])
        keyboard.extend(pagination_keyboard.inline_keyboard)
    
    # Navigation buttons
    nav_buttons = []
    if folder_id != 'root':
        nav_buttons.append(InlineKeyboardButton("⬆️ Up", callback_data="gdrive_folder_up"))
    nav_buttons.append(InlineKeyboardButton("🏠 Root", callback_data="gdrive_folder_root"))
    
    if nav_buttons:
        keyboard.append(nav_buttons)
    
    keyboard.append([InlineKeyboardButton("🔙 Back", callback_data="gdrive_menu")])
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.callback_query.edit_message_text(
        browse_message,
        parse_mode='HTML',
        reply_markup=reply_markup
    )

async def show_file_actions(update: Update, context: ContextTypes.DEFAULT_TYPE, file_id: str):
    """Show actions for a specific file"""
    user_id = update.effective_user.id
    primary_account = get_primary_gdrive_account(user_id)
    
    if not primary_account:
        await update.callback_query.answer("No primary account")
        return
    
    # Get file info (simulated)
    file_info = {
        'id': file_id,
        'name': 'Sample File.pdf',
        'mimeType': 'application/pdf',
        'size': '1024000',
        'webViewLink': f'https://drive.google.com/file/d/{file_id}/view'
    }
    
    file_message = (
        f"📄 <b>File Actions</b>\n\n"
        f"📝 <b>Name:</b> {file_info['name']}\n"
        f"📏 <b>Size:</b> {format_file_size(int(file_info.get('size', 0)))}\n"
        f"🔗 <b>Type:</b> {file_info['mimeType']}\n\n"
        f"Pilih aksi yang ingin dilakukan:"
    )
    
    keyboard = []
    
    # Different actions based on file type
    if file_info['mimeType'].startswith('video/'):
        keyboard.append([InlineKeyboardButton("📽️ Stream Video", callback_data=f"gdrive_stream_{file_id}")])
    
    if file_info['mimeType'].startswith('image/'):
        keyboard.append([InlineKeyboardButton("🖼️ View Image", callback_data=f"gdrive_view_image_{file_id}")])
    
    keyboard.extend([
        [
            InlineKeyboardButton("📥 Download Link", callback_data=f"gdrive_download_{file_id}"),
            InlineKeyboardButton("📤 Share", callback_data=f"gdrive_share_{file_id}")
        ],
        [
            InlineKeyboardButton("ℹ️ File Info", callback_data=f"gdrive_info_{file_id}"),
            InlineKeyboardButton("🗑️ Delete", callback_data=f"gdrive_delete_{file_id}")
        ],
        [InlineKeyboardButton("🔙 Back", callback_data="gdrive_browse")]
    ])
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.callback_query.edit_message_text(
        file_message,
        parse_mode='HTML',
        reply_markup=reply_markup
    )

async def stream_video(update: Update, context: ContextTypes.DEFAULT_TYPE, file_id: str):
    """Stream video file"""
    user_id = update.effective_user.id
    primary_account = get_primary_gdrive_account(user_id)
    
    if not primary_account:
        await update.callback_query.answer("No primary account")
        return
    
    # Get streaming URL
    drive_manager = GoogleDriveManager(primary_account['credentials_json'])
    stream_url = drive_manager.get_file_stream_url(file_id)
    
    if not stream_url:
        await update.callback_query.answer("❌ Cannot generate streaming URL")
        return
    
    stream_message = (
        f"📽️ <b>Video Streaming</b>\n\n"
        f"🎬 Preparing video stream...\n"
        f"⏳ Please wait while we load the video.\n\n"
        f"💡 <b>Tips:</b>\n"
        f"• Video will play directly in Telegram\n"
        f"• No download required\n"
        f"• Quality auto-adjusted"
    )
    
    # Log the streaming activity
    log_activity(
        user_id=user_id,
        action="video_stream",
        details=f"Streaming video file: {file_id}",
        gdrive_account_id=primary_account['id']
    )
    
    keyboard = [
        [InlineKeyboardButton("🔗 Open in Browser", url=stream_url)],
        [InlineKeyboardButton("📤 Share Link", callback_data=f"gdrive_share_{file_id}")],
        [InlineKeyboardButton("🔙 Back", callback_data=f"gdrive_file_{file_id}")]
    ]
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.callback_query.edit_message_text(
        stream_message,
        parse_mode='HTML',
        reply_markup=reply_markup
    )
    
    # Try to send video directly (simulated)
    try:
        await context.bot.send_message(
            chat_id=user_id,
            text=f"📹 <b>Video Stream Ready</b>\n\n"
                 f"🔗 Direct link: {stream_url}\n\n"
                 f"Click the link above to start streaming!",
            parse_mode='HTML'
        )
    except Exception as e:
        logger.error(f"Error sending video stream: {e}")

async def manage_accounts(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Manage Google Drive accounts"""
    user_id = update.effective_user.id
    accounts = get_user_gdrive_accounts(user_id)
    
    manage_message = f"⚙️ <b>Kelola Akun Google Drive</b>\n\n"
    
    if not accounts:
        manage_message += "❌ Belum ada akun terhubung."
    else:
        manage_message += f"📊 Total akun: {len(accounts)}\n\n"
        
        for i, account in enumerate(accounts, 1):
            status = "🎯 Primary" if account['is_primary'] else "📁 Secondary"
            active = "✅ Active" if account['is_active'] else "❌ Inactive"
            
            manage_message += (
                f"{status} <b>Akun {i}</b>\n"
                f"📧 {account['account_email']}\n"
                f"🔄 {active}\n"
                f"📅 Added: {account['created_at'][:10]}\n\n"
            )
    
    keyboard = []
    
    # Account management buttons
    for i, account in enumerate(accounts):
        keyboard.append([
            InlineKeyboardButton(
                f"⚙️ Manage {account['account_email'][:20]}...",
                callback_data=f"gdrive_manage_account_{account['id']}"
            )
        ])
    
    keyboard.extend([
        [InlineKeyboardButton("➕ Add Account", callback_data="oauth_add_account")],
        [InlineKeyboardButton("🔄 Refresh All", callback_data="gdrive_refresh_accounts")],
        [InlineKeyboardButton("🔙 Back", callback_data="gdrive_menu")]
    ])
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.callback_query.edit_message_text(
        manage_message,
        parse_mode='HTML',
        reply_markup=reply_markup
    )

async def auto_switch_account(user_id: int) -> bool:
    """Automatically switch to account with available space"""
    accounts = get_user_gdrive_accounts(user_id)
    
    for account in accounts:
        if not account['is_active']:
            continue
        
        quota_info = await get_account_quota(account)
        used = quota_info.get('used', 0)
        total = quota_info.get('total', 15000000000)
        
        # Check if account has at least 100MB free space
        if (total - used) > 100 * 1024 * 1024:
            # Switch to this account
            from database import get_db_connection
            conn = get_db_connection()
            cursor = conn.cursor()
            
            try:
                # Unset current primary
                cursor.execute('''
                    UPDATE gdrive_accounts 
                    SET is_primary = FALSE 
                    WHERE user_id = ?
                ''', (user_id,))
                
                # Set new primary
                cursor.execute('''
                    UPDATE gdrive_accounts 
                    SET is_primary = TRUE 
                    WHERE id = ?
                ''', (account['id'],))
                
                conn.commit()
                
                logger.info(f"Auto-switched to account {account['account_email']} for user {user_id}")
                
                # Log the switch
                log_activity(
                    user_id=user_id,
                    action="auto_switch_account",
                    details=f"Switched to {account['account_email']} (quota available)",
                    gdrive_account_id=account['id']
                )
                
                return True
                
            except Exception as e:
                logger.error(f"Error auto-switching account: {e}")
                conn.rollback()
            finally:
                conn.close()
    
    return False

async def get_account_quota(account: dict) -> dict:
    """Get quota information for an account"""
    try:
        drive_manager = GoogleDriveManager(account['credentials_json'])
        quota_info = drive_manager.get_quota_info()
        
        if quota_info:
            # Update database with latest quota info
            update_gdrive_storage(
                account['id'],
                quota_info.get('used', 0),
                quota_info.get('total', 15000000000)
            )
        
        return quota_info or {'used': 0, 'total': 15000000000}
        
    except Exception as e:
        logger.error(f"Error getting quota for account {account['id']}: {e}")
        return {'used': 0, 'total': 15000000000}

async def handle_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle Google Drive related callbacks"""
    query = update.callback_query
    data = query.data
    
    if data == "gdrive_menu":
        await show_gdrive_menu(update, context)
    elif data == "gdrive_browse":
        await browse_files(update, context)
    elif data == "gdrive_storage":
        await show_storage_info(update, context)
    elif data == "gdrive_manage":
        await manage_accounts(update, context)
    elif data.startswith("gdrive_file_"):
        file_id = data.split("_", 2)[2]
        await show_file_actions(update, context, file_id)
    elif data.startswith("gdrive_stream_"):
        file_id = data.split("_", 2)[2]
        await stream_video(update, context, file_id)
    elif data.startswith("gdrive_folder_"):
        folder_id = data.split("_", 2)[2]
        context.user_data['current_folder'] = folder_id
        context.user_data['browse_page'] = 1
        await browse_files(update, context)
    elif data == "gdrive_folder_root":
        context.user_data['current_folder'] = 'root'
        context.user_data['browse_page'] = 1
        await browse_files(update, context)
    elif data.startswith("gdrive_browse_page_"):
        page = int(data.split("_")[-1])
        context.user_data['browse_page'] = page
        await browse_files(update, context)
    elif data == "gdrive_auto_switch":
        user_id = update.effective_user.id
        success = await auto_switch_account(user_id)
        if success:
            await update.callback_query.answer("✅ Auto-switch berhasil!")
            await show_storage_info(update, context)
        else:
            await update.callback_query.answer("❌ Tidak ada akun dengan space tersedia")
