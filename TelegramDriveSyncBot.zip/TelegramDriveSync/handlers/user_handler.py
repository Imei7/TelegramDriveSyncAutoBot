"""
TelegramDriveSync Bot - User Handler
Menu utama user, handler /start/menu
"""

import logging
from telegram import Update, ReplyKeyboardMarkup, KeyboardButton, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from database import create_user, get_user_by_id, is_user_paid, is_user_oauth_complete, log_activity
from config import Config
from utils import create_main_menu_keyboard

logger = logging.getLogger(__name__)

async def handle_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle /start command"""
    user = update.effective_user
    user_id = user.id
    
    # Create user if doesn't exist
    create_user(
        user_id=user_id,
        username=user.username,
        first_name=user.first_name,
        last_name=user.last_name
    )
    
    # Log activity
    log_activity(user_id, "user_start", "User started bot")
    
    # Check user status
    user_data = get_user_by_id(user_id)
    is_paid = is_user_paid(user_id)
    oauth_complete = is_user_oauth_complete(user_id)
    
    # Welcome message
    welcome_message = f"👋 <b>Selamat datang, {user.first_name}!</b>\n\n"
    
    if not is_paid:
        # Show subscription required message
        welcome_message += Config.MESSAGES['subscription_required']
        
        keyboard = [
            [InlineKeyboardButton("💳 Berlangganan Sekarang", callback_data="payment_start")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await update.message.reply_text(
            welcome_message,
            parse_mode='HTML',
            reply_markup=reply_markup
        )
        
        # Also show about bot info
        await show_about_bot(update, context)
        
    elif not oauth_complete:
        # Show OAuth required message
        welcome_message += Config.MESSAGES['oauth_required']
        
        keyboard = [
            [InlineKeyboardButton("🔐 Hubungkan Google Drive", callback_data="oauth_start")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await update.message.reply_text(
            welcome_message,
            parse_mode='HTML',
            reply_markup=reply_markup
        )
        
    else:
        # User is fully set up - show main menu
        welcome_message += (
            f"✅ Status: Premium User\n"
            f"🔐 Google Drive: Terhubung\n\n"
            f"🚀 Semua fitur siap digunakan!"
        )
        
        keyboard = create_main_menu_keyboard(is_paid, oauth_complete)
        
        await update.message.reply_text(
            welcome_message,
            parse_mode='HTML',
            reply_markup=keyboard
        )

async def show_main_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show main menu to user"""
    user_id = update.effective_user.id
    is_paid = is_user_paid(user_id)
    oauth_complete = is_user_oauth_complete(user_id)
    
    if not is_paid:
        await handle_subscription_required(update, context)
        return
    
    if not oauth_complete:
        await handle_oauth_required(update, context)
        return
    
    menu_message = (
        f"🏠 <b>Menu Utama</b>\n\n"
        f"✅ Status: Premium Active\n"
        f"🔐 Google Drive: Connected\n\n"
        f"Pilih fitur yang ingin Anda gunakan:"
    )
    
    keyboard = create_main_menu_keyboard(is_paid, oauth_complete)
    
    await update.message.reply_text(
        menu_message,
        parse_mode='HTML',
        reply_markup=keyboard
    )

async def handle_text_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle user text messages"""
    text = update.message.text
    user_id = update.effective_user.id
    
    # Check user status first
    is_paid = is_user_paid(user_id)
    oauth_complete = is_user_oauth_complete(user_id)
    
    if text == "💳 Beli Paket Langganan":
        if is_paid:
            await update.message.reply_text(
                "✅ Anda sudah berlangganan premium!\n"
                "Gunakan /menu untuk mengakses semua fitur."
            )
        else:
            from handlers.payment_handler import start_payment_process
            await start_payment_process(update, context)
    
    elif text == "🔐 Hubungkan Google Drive":
        if not is_paid:
            await handle_subscription_required(update, context)
        elif oauth_complete:
            await update.message.reply_text(
                "✅ Google Drive sudah terhubung!\n"
                "Gunakan menu untuk mengelola akun GDrive."
            )
        else:
            from handlers.oauth_handler import start_oauth_process
            await start_oauth_process(update, context)
    
    elif text == "📤 Upload File/Link":
        if not is_paid or not oauth_complete:
            await handle_access_denied(update, context)
        else:
            from handlers.upload_handler import show_upload_menu
            await show_upload_menu(update, context)
    
    elif text == "🗂️ Kelola GDrive":
        if not is_paid or not oauth_complete:
            await handle_access_denied(update, context)
        else:
            from handlers.gdrive_handler import show_gdrive_menu
            await show_gdrive_menu(update, context)
    
    elif text == "📽️ Streaming Video":
        if not is_paid or not oauth_complete:
            await handle_access_denied(update, context)
        else:
            await show_streaming_menu(update, context)
    
    elif text == "🔗 Scrape Twitter":
        if not is_paid or not oauth_complete:
            await handle_access_denied(update, context)
        else:
            from handlers.twitter_scraper import show_twitter_menu
            await show_twitter_menu(update, context)
    
    elif text == "📑 Log Aktivitas":
        if not is_paid:
            await handle_subscription_required(update, context)
        else:
            from handlers.log_handler import show_user_logs
            await show_user_logs(update, context)
    
    elif text == "⚙️ Pengaturan":
        if not is_paid:
            await handle_subscription_required(update, context)
        else:
            await show_user_settings(update, context)
    
    elif text == "📘 Tentang Bot":
        await show_about_bot(update, context)
    
    elif text == "❓ Cara Penggunaan":
        await show_usage_guide(update, context)
    
    elif text == "💬 Hubungi Admin":
        from handlers.contact_admin_handler import start_contact_admin
        await start_contact_admin(update, context)
    
    elif text == "🔙 Kembali":
        await show_main_menu(update, context)
    
    else:
        # Unknown command
        await update.message.reply_text(
            "❓ Perintah tidak dikenali.\n"
            "Gunakan menu di bawah atau /menu untuk navigasi."
        )

async def handle_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle user callback queries"""
    query = update.callback_query
    data = query.data
    
    if data == "show_main_menu":
        await show_main_menu(update, context)
    elif data == "show_about":
        await show_about_bot(update, context)
    elif data == "show_usage":
        await show_usage_guide(update, context)
    elif data == "refresh_status":
        await refresh_user_status(update, context)

async def handle_subscription_required(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle when subscription is required"""
    message = Config.MESSAGES['subscription_required']
    
    keyboard = [
        [InlineKeyboardButton("💳 Berlangganan Sekarang", callback_data="payment_start")],
        [InlineKeyboardButton("📘 Tentang Bot", callback_data="show_about")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.message.reply_text(
        message,
        parse_mode='HTML',
        reply_markup=reply_markup
    )

async def handle_oauth_required(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle when OAuth is required"""
    message = Config.MESSAGES['oauth_required']
    
    keyboard = [
        [InlineKeyboardButton("🔐 Hubungkan Google Drive", callback_data="oauth_start")],
        [InlineKeyboardButton("❓ Cara Penggunaan", callback_data="show_usage")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.message.reply_text(
        message,
        parse_mode='HTML',
        reply_markup=reply_markup
    )

async def handle_access_denied(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle access denied scenarios"""
    user_id = update.effective_user.id
    is_paid = is_user_paid(user_id)
    oauth_complete = is_user_oauth_complete(user_id)
    
    if not is_paid:
        message = (
            "🔒 <b>Akses Terbatas</b>\n\n"
            "Fitur ini hanya tersedia untuk pengguna premium.\n"
            "Silakan berlangganan terlebih dahulu."
        )
        keyboard = [
            [InlineKeyboardButton("💳 Berlangganan", callback_data="payment_start")]
        ]
    else:  # not oauth_complete
        message = (
            "🔐 <b>Google Drive Diperlukan</b>\n\n"
            "Fitur ini memerlukan koneksi Google Drive.\n"
            "Silakan hubungkan akun Anda terlebih dahulu."
        )
        keyboard = [
            [InlineKeyboardButton("🔐 Hubungkan GDrive", callback_data="oauth_start")]
        ]
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.message.reply_text(
        message,
        parse_mode='HTML',
        reply_markup=reply_markup
    )

async def show_about_bot(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show information about the bot"""
    about_message = (
        f"🤖 <b>TelegramDriveSync Bot</b>\n\n"
        f"🚀 <b>Fitur Utama:</b>\n"
        f"📤 Upload file ke Google Drive\n"
        f"🔗 Scraping Twitter/X dengan media\n"
        f"📁 Multi-akun Google Drive\n"
        f"📽️ Streaming video langsung\n"
        f"📊 Log aktivitas lengkap\n"
        f"👥 Sistem admin dan support\n\n"
        f"💳 <b>Berlangganan:</b>\n"
        f"💰 Harga: ${Config.SUBSCRIPTION_PRICE_USD} USD\n"
        f"⏰ Durasi: Selamanya (sekali bayar)\n"
        f"🔒 Akses semua fitur premium\n\n"
        f"🛡️ <b>Keamanan:</b>\n"
        f"✅ Data terenkripsi\n"
        f"🔐 OAuth aman\n"
        f"🚫 Tidak menyimpan password\n"
        f"📝 Log aktivitas transparan\n\n"
        f"💬 Butuh bantuan? Gunakan menu Hubungi Admin!"
    )
    
    keyboard = [
        [InlineKeyboardButton("💳 Berlangganan", callback_data="payment_start")],
        [InlineKeyboardButton("❓ Cara Penggunaan", callback_data="show_usage")],
        [InlineKeyboardButton("🏠 Menu Utama", callback_data="show_main_menu")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    if update.callback_query:
        await update.callback_query.edit_message_text(
            about_message,
            parse_mode='HTML',
            reply_markup=reply_markup
        )
    else:
        await update.message.reply_text(
            about_message,
            parse_mode='HTML',
            reply_markup=reply_markup
        )

async def show_usage_guide(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show usage guide"""
    guide_message = (
        f"❓ <b>Cara Penggunaan Bot</b>\n\n"
        f"🎯 <b>Langkah Awal:</b>\n"
        f"1️⃣ Berlangganan premium ($5 sekali bayar)\n"
        f"2️⃣ Hubungkan akun Google Drive\n"
        f"3️⃣ Mulai menggunakan semua fitur!\n\n"
        f"📤 <b>Upload File:</b>\n"
        f"• Kirim file langsung ke bot\n"
        f"• Atau gunakan menu Upload File/Link\n"
        f"• Support berbagai format file\n"
        f"• Auto-switch akun jika quota penuh\n\n"
        f"🔗 <b>Twitter Scraping:</b>\n"
        f"• Masukkan username (dengan/tanpa @)\n"
        f"• Bot akan download semua media\n"
        f"• File otomatis diupload ke GDrive\n"
        f"• Bisa batch (banyak username sekaligus)\n\n"
        f"🗂️ <b>Kelola GDrive:</b>\n"
        f"• Tambah multiple akun Google Drive\n"
        f"• Cek storage usage real-time\n"
        f"• Browse file di GDrive\n"
        f"• Auto-switch saat quota penuh\n\n"
        f"📽️ <b>Streaming Video:</b>\n"
        f"• Tonton video langsung dari GDrive\n"
        f"• Tidak perlu download ke device\n"
        f"• Support berbagai format video\n\n"
        f"📑 <b>Log Aktivitas:</b>\n"
        f"• Semua aksi tercatat\n"
        f"• History upload/download\n"
        f"• Status dan progress tracking\n\n"
        f"💬 <b>Support:</b>\n"
        f"• Gunakan menu Hubungi Admin\n"
        f"• Sistem ticket terintegrasi\n"
        f"• Response cepat dari admin"
    )
    
    keyboard = [
        [InlineKeyboardButton("💳 Mulai Berlangganan", callback_data="payment_start")],
        [InlineKeyboardButton("📘 Tentang Bot", callback_data="show_about")],
        [InlineKeyboardButton("🏠 Menu Utama", callback_data="show_main_menu")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    if update.callback_query:
        await update.callback_query.edit_message_text(
            guide_message,
            parse_mode='HTML',
            reply_markup=reply_markup
        )
    else:
        await update.message.reply_text(
            guide_message,
            parse_mode='HTML',
            reply_markup=reply_markup
        )

async def show_streaming_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show video streaming menu"""
    streaming_message = (
        f"📽️ <b>Streaming Video</b>\n\n"
        f"🎬 Tonton video langsung dari Google Drive tanpa download!\n\n"
        f"📋 <b>Cara Menggunakan:</b>\n"
        f"1️⃣ Pilih akun Google Drive\n"
        f"2️⃣ Browse folder video\n"
        f"3️⃣ Pilih video untuk ditonton\n"
        f"4️⃣ Streaming langsung di Telegram\n\n"
        f"✅ <b>Format Didukung:</b>\n"
        f"🎥 MP4, AVI, MKV, MOV\n"
        f"📱 Optimized untuk mobile\n"
        f"🔄 Auto quality adjustment\n\n"
        f"⚡ <b>Fitur:</b>\n"
        f"• Streaming instan\n"
        f"• Tidak memakan storage device\n"
        f"• Quality preview\n"
        f"• Share link ke grup"
    )
    
    keyboard = [
        [InlineKeyboardButton("🗂️ Browse Video", callback_data="gdrive_browse_videos")],
        [InlineKeyboardButton("📋 Recent Videos", callback_data="gdrive_recent_videos")],
        [InlineKeyboardButton("🔍 Search Video", callback_data="gdrive_search_videos")],
        [InlineKeyboardButton("🔙 Back", callback_data="show_main_menu")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.message.reply_text(
        streaming_message,
        parse_mode='HTML',
        reply_markup=reply_markup
    )

async def show_user_settings(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show user settings menu"""
    user_id = update.effective_user.id
    user_data = get_user_by_id(user_id)
    
    settings_message = (
        f"⚙️ <b>Pengaturan User</b>\n\n"
        f"👤 <b>Profil:</b>\n"
        f"🆔 ID: <code>{user_id}</code>\n"
        f"📝 Username: @{user_data.get('username', 'Not set')}\n"
        f"💳 Status: {'Premium' if user_data.get('is_paid') else 'Free'}\n"
        f"🔐 OAuth: {'Connected' if user_data.get('oauth_complete') else 'Not connected'}\n\n"
        f"📊 <b>Statistik:</b>\n"
        f"📅 Bergabung: {user_data['created_at'][:10]}\n"
        f"🔄 Aktivitas terakhir: {user_data['last_activity'][:10]}\n\n"
        f"⚙️ <b>Preferensi:</b>\n"
        f"📱 Notifikasi: Aktif\n"
        f"🔄 Auto-backup: Aktif\n"
        f"📊 Detail logs: Aktif"
    )
    
    keyboard = [
        [
            InlineKeyboardButton("🔐 Kelola OAuth", callback_data="settings_oauth"),
            InlineKeyboardButton("📊 Statistik", callback_data="settings_stats")
        ],
        [
            InlineKeyboardButton("🔔 Notifikasi", callback_data="settings_notifications"),
            InlineKeyboardButton("🗑️ Hapus Data", callback_data="settings_delete_data")
        ],
        [
            InlineKeyboardButton("🔄 Reset Settings", callback_data="settings_reset"),
            InlineKeyboardButton("🏠 Menu Utama", callback_data="show_main_menu")
        ]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.message.reply_text(
        settings_message,
        parse_mode='HTML',
        reply_markup=reply_markup
    )

async def refresh_user_status(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Refresh and show current user status"""
    user_id = update.effective_user.id
    is_paid = is_user_paid(user_id)
    oauth_complete = is_user_oauth_complete(user_id)
    
    status_message = f"🔄 <b>Status Update</b>\n\n"
    
    if is_paid and oauth_complete:
        status_message += (
            f"✅ <b>Status: Premium Active</b>\n"
            f"🔐 Google Drive: Connected\n"
            f"🚀 Semua fitur tersedia!\n\n"
            f"Gunakan menu di bawah untuk mengakses fitur."
        )
        keyboard = create_main_menu_keyboard(is_paid, oauth_complete)
    elif is_paid and not oauth_complete:
        status_message += (
            f"💳 <b>Status: Premium Active</b>\n"
            f"⚠️ Google Drive: Not Connected\n\n"
            f"Hubungkan Google Drive untuk menggunakan semua fitur."
        )
        keyboard = [
            [InlineKeyboardButton("🔐 Hubungkan Google Drive", callback_data="oauth_start")]
        ]
    else:
        status_message += (
            f"🆓 <b>Status: Free User</b>\n"
            f"❌ Akses terbatas\n\n"
            f"Berlangganan untuk mengakses semua fitur premium."
        )
        keyboard = [
            [InlineKeyboardButton("💳 Berlangganan", callback_data="payment_start")]
        ]
    
    if update.callback_query:
        reply_markup = InlineKeyboardMarkup(keyboard) if isinstance(keyboard[0][0], InlineKeyboardButton) else None
        await update.callback_query.edit_message_text(
            status_message,
            parse_mode='HTML',
            reply_markup=reply_markup
        )
    else:
        reply_markup = ReplyKeyboardMarkup(keyboard, resize_keyboard=True) if not isinstance(keyboard[0][0], InlineKeyboardButton) else InlineKeyboardMarkup(keyboard)
        await update.message.reply_text(
            status_message,
            parse_mode='HTML',
            reply_markup=reply_markup
        )
