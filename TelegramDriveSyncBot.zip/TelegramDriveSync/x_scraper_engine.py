"""
TelegramDriveSync Bot - Twitter/X Scraper Engine
Handles Twitter scraping functionality for both batch and individual operations
"""

import logging
import requests
import json
import re
import time
from typing import List, Dict, Optional, Tuple
from datetime import datetime
import os
from urllib.parse import urlparse
from config import Config
from utils import validate_twitter_username, format_file_size, sanitize_filename

logger = logging.getLogger(__name__)

class TwitterScraperEngine:
    def __init__(self):
        self.bearer_token = Config.TWITTER_BEARER_TOKEN
        self.session = requests.Session()
        self.rate_limit_remaining = 300
        self.rate_limit_reset = datetime.now()
        
        # Headers for requests
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
            'Accept': 'application/json, text/plain, */*',
            'Accept-Language': 'en-US,en;q=0.5',
            'Accept-Encoding': 'gzip, deflate',
            'DNT': '1',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
        }
        
        if self.bearer_token:
            self.headers['Authorization'] = f'Bearer {self.bearer_token}'
    
    def check_rate_limit(self) -> bool:
        """Check if we have API calls remaining"""
        if datetime.now() > self.rate_limit_reset:
            self.rate_limit_remaining = 300  # Reset limit
            self.rate_limit_reset = datetime.now().replace(minute=0, second=0, microsecond=0)
            self.rate_limit_reset = self.rate_limit_reset.replace(hour=self.rate_limit_reset.hour + 1)
        
        return self.rate_limit_remaining > 0
    
    def update_rate_limit(self, headers: Dict):
        """Update rate limit from response headers"""
        if 'x-rate-limit-remaining' in headers:
            self.rate_limit_remaining = int(headers['x-rate-limit-remaining'])
        
        if 'x-rate-limit-reset' in headers:
            reset_timestamp = int(headers['x-rate-limit-reset'])
            self.rate_limit_reset = datetime.fromtimestamp(reset_timestamp)
    
    def get_user_info(self, username: str) -> Optional[Dict]:
        """Get user information by username"""
        if not validate_twitter_username(username):
            logger.error(f"Invalid username format: {username}")
            return None
        
        if not self.check_rate_limit():
            logger.error("Rate limit exceeded")
            return None
        
        username = username.lstrip('@')
        
        try:
            # Try multiple methods to get user info
            user_info = self._get_user_info_api(username)
            if not user_info:
                user_info = self._get_user_info_scraping(username)
            
            return user_info
        
        except Exception as e:
            logger.error(f"Error getting user info for {username}: {e}")
            return None
    
    def _get_user_info_api(self, username: str) -> Optional[Dict]:
        """Get user info using Twitter API"""
        if not self.bearer_token:
            return None
        
        url = f"https://api.twitter.com/2/users/by/username/{username}"
        params = {
            'user.fields': 'id,name,username,description,public_metrics,profile_image_url,verified'
        }
        
        try:
            response = self.session.get(url, headers=self.headers, params=params, timeout=10)
            self.update_rate_limit(response.headers)
            
            if response.status_code == 200:
                data = response.json()
                if 'data' in data:
                    user_data = data['data']
                    return {
                        'id': user_data['id'],
                        'username': user_data['username'],
                        'name': user_data['name'],
                        'description': user_data.get('description', ''),
                        'followers': user_data.get('public_metrics', {}).get('followers_count', 0),
                        'following': user_data.get('public_metrics', {}).get('following_count', 0),
                        'tweets': user_data.get('public_metrics', {}).get('tweet_count', 0),
                        'verified': user_data.get('verified', False),
                        'profile_image': user_data.get('profile_image_url', ''),
                        'method': 'api'
                    }
            else:
                logger.error(f"API request failed: {response.status_code} - {response.text}")
        
        except Exception as e:
            logger.error(f"API request error for {username}: {e}")
        
        return None
    
    def _get_user_info_scraping(self, username: str) -> Optional[Dict]:
        """Get user info using web scraping (fallback method)"""
        try:
            # This is a simplified scraping approach
            # In production, you might want to use more sophisticated tools
            url = f"https://twitter.com/{username}"
            
            response = self.session.get(url, headers=self.headers, timeout=10)
            
            if response.status_code == 200:
                html_content = response.text
                
                # Extract basic info using regex (simplified)
                name_match = re.search(r'"name":"([^"]*)"', html_content)
                followers_match = re.search(r'"followers_count":(\d+)', html_content)
                
                return {
                    'username': username,
                    'name': name_match.group(1) if name_match else username,
                    'followers': int(followers_match.group(1)) if followers_match else 0,
                    'method': 'scraping'
                }
        
        except Exception as e:
            logger.error(f"Scraping error for {username}: {e}")
        
        return None
    
    def get_user_tweets(self, username: str, count: int = 10) -> List[Dict]:
        """Get recent tweets from user"""
        if not validate_twitter_username(username):
            return []
        
        username = username.lstrip('@')
        
        try:
            tweets = self._get_tweets_api(username, count)
            if not tweets:
                tweets = self._get_tweets_scraping(username, count)
            
            return tweets or []
        
        except Exception as e:
            logger.error(f"Error getting tweets for {username}: {e}")
            return []
    
    def _get_tweets_api(self, username: str, count: int) -> List[Dict]:
        """Get tweets using Twitter API"""
        if not self.bearer_token:
            return []
        
        # First get user ID
        user_info = self._get_user_info_api(username)
        if not user_info:
            return []
        
        user_id = user_info['id']
        
        url = f"https://api.twitter.com/2/users/{user_id}/tweets"
        params = {
            'max_results': min(count, 100),
            'tweet.fields': 'id,text,created_at,public_metrics,attachments',
            'media.fields': 'media_key,type,url,preview_image_url',
            'expansions': 'attachments.media_keys'
        }
        
        try:
            response = self.session.get(url, headers=self.headers, params=params, timeout=10)
            self.update_rate_limit(response.headers)
            
            if response.status_code == 200:
                data = response.json()
                tweets = []
                
                if 'data' in data:
                    media_dict = {}
                    if 'includes' in data and 'media' in data['includes']:
                        for media in data['includes']['media']:
                            media_dict[media['media_key']] = media
                    
                    for tweet_data in data['data']:
                        tweet = {
                            'id': tweet_data['id'],
                            'text': tweet_data['text'],
                            'created_at': tweet_data['created_at'],
                            'likes': tweet_data.get('public_metrics', {}).get('like_count', 0),
                            'retweets': tweet_data.get('public_metrics', {}).get('retweet_count', 0),
                            'media': []
                        }
                        
                        # Add media if present
                        if 'attachments' in tweet_data and 'media_keys' in tweet_data['attachments']:
                            for media_key in tweet_data['attachments']['media_keys']:
                                if media_key in media_dict:
                                    media_info = media_dict[media_key]
                                    tweet['media'].append({
                                        'type': media_info['type'],
                                        'url': media_info.get('url', ''),
                                        'preview': media_info.get('preview_image_url', '')
                                    })
                        
                        tweets.append(tweet)
                
                return tweets
        
        except Exception as e:
            logger.error(f"Error getting tweets via API for {username}: {e}")
        
        return []
    
    def _get_tweets_scraping(self, username: str, count: int) -> List[Dict]:
        """Get tweets using web scraping (fallback)"""
        try:
            # Simplified scraping approach
            url = f"https://twitter.com/{username}"
            
            response = self.session.get(url, headers=self.headers, timeout=10)
            
            if response.status_code == 200:
                # This would require more sophisticated parsing
                # For now, return empty list
                logger.info(f"Scraping fallback for {username} - not fully implemented")
                return []
        
        except Exception as e:
            logger.error(f"Error scraping tweets for {username}: {e}")
        
        return []
    
    def download_media(self, media_url: str, filename: str) -> Optional[str]:
        """Download media file from URL"""
        try:
            response = self.session.get(media_url, headers=self.headers, timeout=30)
            
            if response.status_code == 200:
                # Ensure storage directory exists
                os.makedirs(Config.STORAGE_PATH, exist_ok=True)
                
                # Create safe filename
                safe_filename = sanitize_filename(filename)
                file_path = os.path.join(Config.STORAGE_PATH, safe_filename)
                
                # Save file
                with open(file_path, 'wb') as f:
                    f.write(response.content)
                
                logger.info(f"Downloaded media: {file_path}")
                return file_path
            else:
                logger.error(f"Failed to download media: {response.status_code}")
        
        except Exception as e:
            logger.error(f"Error downloading media from {media_url}: {e}")
        
        return None
    
    def scrape_user_profile(self, username: str, include_tweets: bool = True, 
                          include_media: bool = True, tweet_count: int = 10) -> Dict:
        """Complete user profile scraping"""
        if not validate_twitter_username(username):
            return {'error': 'Invalid username format'}
        
        username = username.lstrip('@')
        
        try:
            # Get user info
            user_info = self.get_user_info(username)
            if not user_info:
                return {'error': 'User not found or private'}
            
            result = {
                'user_info': user_info,
                'tweets': [],
                'media_files': [],
                'scrape_time': datetime.now().isoformat(),
                'success': True
            }
            
            # Get tweets if requested
            if include_tweets:
                tweets = self.get_user_tweets(username, tweet_count)
                result['tweets'] = tweets
                
                # Download media if requested
                if include_media:
                    media_files = []
                    for tweet in tweets:
                        for media in tweet.get('media', []):
                            if media['url']:
                                # Generate filename
                                url_parts = urlparse(media['url'])
                                filename = f"{username}_{tweet['id']}_{os.path.basename(url_parts.path)}"
                                
                                # Download file
                                file_path = self.download_media(media['url'], filename)
                                if file_path:
                                    media_files.append({
                                        'tweet_id': tweet['id'],
                                        'media_type': media['type'],
                                        'local_path': file_path,
                                        'original_url': media['url'],
                                        'file_size': os.path.getsize(file_path) if os.path.exists(file_path) else 0
                                    })
                    
                    result['media_files'] = media_files
            
            return result
        
        except Exception as e:
            logger.error(f"Error in complete profile scraping for {username}: {e}")
            return {'error': str(e), 'success': False}
    
    def batch_scrape_users(self, usernames: List[str], include_tweets: bool = True,
                          include_media: bool = True, tweet_count: int = 10) -> Dict:
        """Scrape multiple users in batch"""
        results = {
            'total_users': len(usernames),
            'successful': 0,
            'failed': 0,
            'results': [],
            'errors': [],
            'start_time': datetime.now().isoformat()
        }
        
        for i, username in enumerate(usernames):
            try:
                logger.info(f"Scraping user {i+1}/{len(usernames)}: {username}")
                
                result = self.scrape_user_profile(username, include_tweets, include_media, tweet_count)
                
                if result.get('success', False):
                    results['successful'] += 1
                    results['results'].append({
                        'username': username,
                        'data': result,
                        'status': 'success'
                    })
                else:
                    results['failed'] += 1
                    results['errors'].append({
                        'username': username,
                        'error': result.get('error', 'Unknown error'),
                        'status': 'failed'
                    })
                
                # Add delay between requests to avoid rate limiting
                if i < len(usernames) - 1:
                    time.sleep(2)
            
            except Exception as e:
                logger.error(f"Error scraping user {username}: {e}")
                results['failed'] += 1
                results['errors'].append({
                    'username': username,
                    'error': str(e),
                    'status': 'failed'
                })
        
        results['end_time'] = datetime.now().isoformat()
        results['success_rate'] = (results['successful'] / results['total_users']) * 100 if results['total_users'] > 0 else 0
        
        return results
    
    def get_scraping_summary(self, results: Dict) -> str:
        """Generate human-readable summary of scraping results"""
        if not results:
            return "❌ No scraping results available"
        
        summary = f"📊 <b>Scraping Results Summary</b>\n\n"
        summary += f"👥 Total Users: {results.get('total_users', 0)}\n"
        summary += f"✅ Successful: {results.get('successful', 0)}\n"
        summary += f"❌ Failed: {results.get('failed', 0)}\n"
        summary += f"📈 Success Rate: {results.get('success_rate', 0):.1f}%\n\n"
        
        # Add individual results
        for result in results.get('results', [])[:5]:  # Show first 5
            user_data = result['data']
            user_info = user_data.get('user_info', {})
            tweets_count = len(user_data.get('tweets', []))
            media_count = len(user_data.get('media_files', []))
            
            summary += f"👤 @{result['username']}\n"
            summary += f"   📝 {tweets_count} tweets, 🖼️ {media_count} media\n"
        
        if len(results.get('results', [])) > 5:
            summary += f"   ... and {len(results['results']) - 5} more\n"
        
        # Add errors if any
        if results.get('errors'):
            summary += f"\n❌ <b>Errors:</b>\n"
            for error in results['errors'][:3]:  # Show first 3 errors
                summary += f"   @{error['username']}: {error['error']}\n"
            
            if len(results['errors']) > 3:
                summary += f"   ... and {len(results['errors']) - 3} more errors\n"
        
        return summary
    
    def cleanup_downloaded_files(self, older_than_hours: int = 24):
        """Clean up old downloaded files"""
        try:
            import glob
            from datetime import timedelta
            
            cutoff_time = datetime.now() - timedelta(hours=older_than_hours)
            pattern = os.path.join(Config.STORAGE_PATH, "*")
            
            cleaned_count = 0
            for file_path in glob.glob(pattern):
                try:
                    file_time = datetime.fromtimestamp(os.path.getctime(file_path))
                    if file_time < cutoff_time:
                        os.remove(file_path)
                        cleaned_count += 1
                except Exception as e:
                    logger.error(f"Error cleaning file {file_path}: {e}")
            
            logger.info(f"Cleaned up {cleaned_count} old scraped files")
            return cleaned_count
        
        except Exception as e:
            logger.error(f"Error in cleanup_downloaded_files: {e}")
            return 0

# Global instance
twitter_scraper = TwitterScraperEngine()
