# TelegramDriveSync Bot

## Overview

TelegramDriveSync Bot is a comprehensive Telegram bot that provides Google Drive integration, Twitter/X scraping capabilities, file upload management, and user subscription services. The bot serves as a bridge between Telegram users and cloud storage, offering paid subscription-based access to premium features.

## System Architecture

### Backend Architecture
- **Language**: Python 3.11
- **Framework**: python-telegram-bot library for Telegram API integration
- **Database**: SQLite with native sqlite3 integration
- **Async Processing**: Built on asyncio for concurrent operations
- **Task Scheduling**: APScheduler for automated tasks and cleanup
- **File Handling**: aiofiles for asynchronous file operations

### Core Components
- **Bot Engine**: Central bot management with error handling and admin notifications
- **Handler System**: Modular handler architecture for different bot functionalities
- **OAuth Integration**: Google Drive OAuth2 flow for account linking
- **Payment System**: CryptoBot API integration for cryptocurrency payments
- **Scraping Engine**: Twitter/X content scraping with media download capabilities
- **File Management**: Upload, storage, and Google Drive synchronization

## Key Components

### Database Schema
The application uses SQLite with the following core tables:
- `users`: User management with subscription and OAuth status
- `gdrive_accounts`: Multiple Google Drive account support per user
- `activity_logs`: Comprehensive activity tracking
- `support_tickets`: Customer support ticket system
- `payments`: Payment transaction records

### Handler Modules
- **admin_handler**: Administrative panel, user management, broadcasting
- **user_handler**: Main user interface and navigation
- **gdrive_handler**: Google Drive operations and storage management
- **upload_handler**: File upload processing and URL downloading
- **oauth_handler**: Google OAuth2 authentication flow
- **payment_handler**: Subscription payment processing
- **twitter_scraper**: Twitter/X content scraping functionality
- **log_handler**: Activity logging and viewing
- **share_to_group_handler**: Group sharing capabilities
- **contact_admin_handler**: Support ticket system

### Configuration Management
Centralized configuration system with:
- Bot tokens and API keys
- Admin user IDs
- Payment configuration
- File size limits and allowed types
- Google Drive OAuth settings

## Data Flow

### User Registration Flow
1. User starts bot with `/start` command
2. User record created in database
3. Subscription status checked
4. Appropriate menu displayed based on access level

### File Upload Flow
1. User selects upload option
2. OAuth status verified
3. File received and validated
4. File uploaded to Google Drive
5. Activity logged and user notified

### Payment Flow
1. User initiates subscription
2. CryptoBot invoice created
3. Payment processed and verified
4. User access level updated
5. Subscription activated

### Twitter Scraping Flow
1. User provides Twitter usernames
2. Content scraped using custom engine
3. Media files downloaded
4. Files uploaded to Google Drive
5. Summary report generated

## External Dependencies

### Required APIs
- **Telegram Bot API**: Core bot functionality
- **Google Drive API**: File storage and management
- **CryptoBot API**: Payment processing
- **Twitter/X API**: Content scraping (optional Bearer token)

### Python Packages
- `python-telegram-bot`: Telegram integration
- `google-api-python-client`: Google Drive operations
- `aiohttp`: HTTP client for API requests
- `apscheduler`: Task scheduling
- `cryptography`: Security operations
- `trafilatura`: Content extraction

## Deployment Strategy

### Environment Setup
- Python 3.11 runtime
- Rust/Cargo for cryptographic dependencies
- SQLite database file storage
- Local file system for temporary storage

### Configuration Requirements
- `BOT_TOKEN`: Telegram bot token
- `CRYPTOBOT_API_TOKEN`: Payment API token
- `GOOGLE_CLIENT_ID` & `GOOGLE_CLIENT_SECRET`: OAuth credentials
- `TWITTER_BEARER_TOKEN`: Optional Twitter API access

### File Structure
- `storage/`: Temporary file storage directory
- `bot_database.db`: SQLite database file
- `bot.log`: Application logging file

## User Preferences

Preferred communication style: Simple, everyday language.

## Changelog

Changelog:
- June 19, 2025. Initial setup