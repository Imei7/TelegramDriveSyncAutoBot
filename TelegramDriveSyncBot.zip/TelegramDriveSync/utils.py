"""
TelegramDriveSync Bot - Utility Functions
Helper functions for file formatting, pagination, progress bars, and validation
"""

import logging
import re
import os
from typing import List, Dict, Any, Tuple, Optional
from datetime import datetime, timedelta
import hashlib
import mimetypes
from telegram import InlineKeyboardButton, InlineKeyboardMarkup, ReplyKeyboardMarkup, KeyboardButton
from config import Config

logger = logging.getLogger(__name__)

# File and Size Formatting

def format_file_size(size_bytes: int) -> str:
    """Format file size in human readable format"""
    if size_bytes == 0:
        return "0 B"
    
    size_names = ["B", "KB", "MB", "GB", "TB"]
    i = 0
    while size_bytes >= 1024 and i < len(size_names) - 1:
        size_bytes /= 1024.0
        i += 1
    
    return f"{size_bytes:.1f} {size_names[i]}"

def get_file_extension(filename: str) -> str:
    """Get file extension from filename"""
    return os.path.splitext(filename)[1].lower()

def get_file_type_emoji(filename: str) -> str:
    """Get emoji based on file type"""
    ext = get_file_extension(filename)
    
    image_exts = ['.jpg', '.jpeg', '.png', '.gif', '.webp', '.bmp']
    video_exts = ['.mp4', '.avi', '.mkv', '.mov', '.wmv', '.flv']
    audio_exts = ['.mp3', '.wav', '.flac', '.ogg', '.m4a']
    doc_exts = ['.pdf', '.doc', '.docx', '.txt', '.rtf']
    archive_exts = ['.zip', '.rar', '.7z', '.tar', '.gz']
    
    if ext in image_exts:
        return "🖼️"
    elif ext in video_exts:
        return "🎥"
    elif ext in audio_exts:
        return "🎵"
    elif ext in doc_exts:
        return "📄"
    elif ext in archive_exts:
        return "📦"
    else:
        return "📁"

def validate_file_type(filename: str) -> bool:
    """Validate if file type is allowed"""
    mime_type, _ = mimetypes.guess_type(filename)
    return mime_type in Config.ALLOWED_FILE_TYPES if mime_type else False

def sanitize_filename(filename: str) -> str:
    """Sanitize filename for safe storage"""
    # Remove or replace invalid characters
    filename = re.sub(r'[<>:"/\\|?*]', '_', filename)
    # Limit length
    if len(filename) > 100:
        name, ext = os.path.splitext(filename)
        filename = name[:90] + ext
    return filename

# Progress and Status Indicators

def create_progress_bar(percentage: float, length: int = 10) -> str:
    """Create a text-based progress bar"""
    filled = int(length * percentage / 100)
    bar = "█" * filled + "░" * (length - filled)
    return f"[{bar}] {percentage:.1f}%"

def create_storage_progress(used: int, total: int) -> str:
    """Create storage usage progress bar"""
    if total == 0:
        return "[░░░░░░░░░░] 0%"
    
    percentage = (used / total) * 100
    progress_bar = create_progress_bar(percentage)
    used_str = format_file_size(used)
    total_str = format_file_size(total)
    
    return f"{progress_bar}\n💾 {used_str} / {total_str}"

def get_status_emoji(status: str) -> str:
    """Get emoji for status"""
    status_emojis = {
        'success': '✅',
        'pending': '⏳',
        'failed': '❌',
        'processing': '🔄',
        'cancelled': '⏹️',
        'queued': '📝'
    }
    return status_emojis.get(status.lower(), '❓')

# Pagination Functions

def paginate_items(items: List[Any], page: int = 1, per_page: int = None) -> Tuple[List[Any], Dict]:
    """Paginate a list of items"""
    if per_page is None:
        per_page = Config.ITEMS_PER_PAGE
    
    total_items = len(items)
    total_pages = (total_items + per_page - 1) // per_page
    
    if page < 1:
        page = 1
    elif page > total_pages:
        page = total_pages
    
    start_idx = (page - 1) * per_page
    end_idx = start_idx + per_page
    
    paginated_items = items[start_idx:end_idx]
    
    pagination_info = {
        'current_page': page,
        'total_pages': total_pages,
        'total_items': total_items,
        'has_previous': page > 1,
        'has_next': page < total_pages,
        'start_index': start_idx + 1,
        'end_index': min(end_idx, total_items)
    }
    
    return paginated_items, pagination_info

def create_pagination_keyboard(prefix: str, current_page: int, total_pages: int, 
                             additional_data: str = "") -> InlineKeyboardMarkup:
    """Create pagination keyboard"""
    keyboard = []
    
    # Navigation buttons
    nav_buttons = []
    
    if current_page > 1:
        nav_buttons.append(InlineKeyboardButton("◀️ Prev", 
                          callback_data=f"{prefix}_page_{current_page-1}{additional_data}"))
    
    nav_buttons.append(InlineKeyboardButton(f"{current_page}/{total_pages}", 
                      callback_data="page_info"))
    
    if current_page < total_pages:
        nav_buttons.append(InlineKeyboardButton("Next ▶️", 
                          callback_data=f"{prefix}_page_{current_page+1}{additional_data}"))
    
    if nav_buttons:
        keyboard.append(nav_buttons)
    
    # Jump to page buttons (for pages > 5)
    if total_pages > 5:
        jump_buttons = []
        if current_page > 3:
            jump_buttons.append(InlineKeyboardButton("1", 
                              callback_data=f"{prefix}_page_1{additional_data}"))
        if current_page > 4:
            jump_buttons.append(InlineKeyboardButton("...", callback_data="page_info"))
        
        if current_page < total_pages - 2:
            if current_page < total_pages - 3:
                jump_buttons.append(InlineKeyboardButton("...", callback_data="page_info"))
            jump_buttons.append(InlineKeyboardButton(str(total_pages), 
                              callback_data=f"{prefix}_page_{total_pages}{additional_data}"))
        
        if jump_buttons:
            keyboard.append(jump_buttons)
    
    return InlineKeyboardMarkup(keyboard)

# Keyboard Creation Functions

def create_main_menu_keyboard(user_paid: bool = False, oauth_complete: bool = False) -> ReplyKeyboardMarkup:
    """Create main menu reply keyboard"""
    keyboard = []
    
    if not user_paid:
        keyboard.append([KeyboardButton("💳 Beli Paket Langganan")])
    elif not oauth_complete:
        keyboard.append([KeyboardButton("🔐 Hubungkan Google Drive")])
    else:
        # Full menu for paid + OAuth users
        keyboard.extend([
            [KeyboardButton("📤 Upload File/Link"), KeyboardButton("🗂️ Kelola GDrive")],
            [KeyboardButton("📽️ Streaming Video"), KeyboardButton("🔗 Scrape Twitter")],
            [KeyboardButton("📑 Log Aktivitas"), KeyboardButton("⚙️ Pengaturan")]
        ])
    
    # Always available options
    keyboard.extend([
        [KeyboardButton("📘 Tentang Bot"), KeyboardButton("❓ Cara Penggunaan")],
        [KeyboardButton("💬 Hubungi Admin")]
    ])
    
    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True, one_time_keyboard=False)

def create_admin_menu_keyboard() -> ReplyKeyboardMarkup:
    """Create admin menu reply keyboard"""
    keyboard = [
        [KeyboardButton("👥 Kelola User"), KeyboardButton("💳 Kelola Paket")],
        [KeyboardButton("📊 Statistik"), KeyboardButton("📄 Laporan")],
        [KeyboardButton("🧼 Pembersihan"), KeyboardButton("📢 Broadcast")],
        [KeyboardButton("📤 Share ke Grup"), KeyboardButton("🔗 Kelola Grup")],
        [KeyboardButton("⚙️ Pengaturan Bot"), KeyboardButton("🏠 Menu Utama")]
    ]
    
    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True, one_time_keyboard=False)

def create_back_keyboard() -> ReplyKeyboardMarkup:
    """Create simple back keyboard"""
    keyboard = [[KeyboardButton("🔙 Kembali")]]
    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True, one_time_keyboard=True)

def create_yes_no_keyboard(yes_callback: str, no_callback: str) -> InlineKeyboardMarkup:
    """Create yes/no inline keyboard"""
    keyboard = [
        [
            InlineKeyboardButton("✅ Ya", callback_data=yes_callback),
            InlineKeyboardButton("❌ Tidak", callback_data=no_callback)
        ]
    ]
    return InlineKeyboardMarkup(keyboard)

# Text Formatting Functions

def format_user_info(user: Dict) -> str:
    """Format user information for display"""
    name = user.get('first_name', 'Unknown')
    if user.get('last_name'):
        name += f" {user['last_name']}"
    
    username = f"@{user['username']}" if user.get('username') else "No username"
    status = "✅ Paid" if user.get('is_paid') else "❌ Free"
    oauth_status = "✅ Connected" if user.get('oauth_complete') else "❌ Not connected"
    
    created_date = datetime.fromisoformat(user['created_at']).strftime('%Y-%m-%d')
    
    return (
        f"👤 <b>{name}</b>\n"
        f"🆔 ID: <code>{user['user_id']}</code>\n"
        f"📝 Username: {username}\n"
        f"💳 Status: {status}\n"
        f"🔐 OAuth: {oauth_status}\n"
        f"📅 Joined: {created_date}"
    )

def format_log_entry(log: Dict) -> str:
    """Format log entry for display"""
    emoji = get_status_emoji(log.get('status', 'unknown'))
    action = log.get('action', 'Unknown')
    details = log.get('details', '')
    
    timestamp = datetime.fromisoformat(log['created_at']).strftime('%m/%d %H:%M')
    
    message = f"{emoji} <b>{action}</b>\n"
    message += f"⏰ {timestamp}\n"
    
    if log.get('file_name'):
        file_emoji = get_file_type_emoji(log['file_name'])
        message += f"{file_emoji} {log['file_name']}\n"
    
    if log.get('file_size'):
        message += f"📏 {format_file_size(log['file_size'])}\n"
    
    if details:
        message += f"📝 {details}\n"
    
    if log.get('account_email'):
        message += f"📧 {log['account_email']}\n"
    
    return message.strip()

def format_ticket_info(ticket: Dict) -> str:
    """Format support ticket information"""
    status_emoji = get_status_emoji(ticket.get('status', 'open'))
    
    created_date = datetime.fromisoformat(ticket['created_at']).strftime('%Y-%m-%d %H:%M')
    updated_date = datetime.fromisoformat(ticket['updated_at']).strftime('%Y-%m-%d %H:%M')
    
    return (
        f"🎫 <b>Ticket #{ticket['ticket_id']}</b>\n"
        f"{status_emoji} Status: {ticket['status'].title()}\n"
        f"📂 Category: {ticket['category']}\n"
        f"📅 Created: {created_date}\n"
        f"🔄 Updated: {updated_date}"
    )

# Validation Functions

def validate_url(url: str) -> bool:
    """Validate URL format"""
    url_pattern = re.compile(
        r'^https?://'  # http:// or https://
        r'(?:(?:[A-Z0-9](?:[A-Z0-9-]{0,61}[A-Z0-9])?\.)+[A-Z]{2,6}\.?|'  # domain...
        r'localhost|'  # localhost...
        r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})'  # ...or ip
        r'(?::\d+)?'  # optional port
        r'(?:/?|[/?]\S+)$', re.IGNORECASE)
    
    return url_pattern.match(url) is not None

def validate_email(email: str) -> bool:
    """Validate email format"""
    email_pattern = re.compile(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$')
    return email_pattern.match(email) is not None

def validate_twitter_username(username: str) -> bool:
    """Validate Twitter username format"""
    # Remove @ if present
    username = username.lstrip('@')
    
    # Twitter username rules: 1-15 characters, alphanumeric + underscore
    if len(username) < 1 or len(username) > 15:
        return False
    
    return re.match(r'^[a-zA-Z0-9_]+$', username) is not None

def extract_urls_from_text(text: str) -> List[str]:
    """Extract URLs from text"""
    url_pattern = re.compile(
        r'http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\\(\\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+'
    )
    return url_pattern.findall(text)

def extract_twitter_usernames(text: str) -> List[str]:
    """Extract Twitter usernames from text"""
    # Match @username or just username
    usernames = []
    lines = text.strip().split('\n')
    
    for line in lines:
        line = line.strip()
        if not line:
            continue
        
        # Remove @ if present
        username = line.lstrip('@')
        
        if validate_twitter_username(username):
            usernames.append(username)
    
    return list(set(usernames))  # Remove duplicates

# Security Functions

def generate_secure_token(length: int = 32) -> str:
    """Generate secure random token"""
    import secrets
    return secrets.token_urlsafe(length)

def hash_string(text: str) -> str:
    """Create SHA-256 hash of string"""
    return hashlib.sha256(text.encode()).hexdigest()

def truncate_text(text: str, max_length: int = 100) -> str:
    """Truncate text to specified length"""
    if len(text) <= max_length:
        return text
    return text[:max_length-3] + "..."

# Time Functions

def format_datetime(dt: datetime) -> str:
    """Format datetime for display"""
    return dt.strftime('%Y-%m-%d %H:%M:%S')

def get_time_ago(dt: datetime) -> str:
    """Get human readable time ago"""
    now = datetime.now()
    diff = now - dt
    
    if diff.days > 0:
        return f"{diff.days} day{'s' if diff.days != 1 else ''} ago"
    elif diff.seconds > 3600:
        hours = diff.seconds // 3600
        return f"{hours} hour{'s' if hours != 1 else ''} ago"
    elif diff.seconds > 60:
        minutes = diff.seconds // 60
        return f"{minutes} minute{'s' if minutes != 1 else ''} ago"
    else:
        return "Just now"

def parse_schedule_time(time_str: str) -> Optional[datetime]:
    """Parse schedule time string to datetime"""
    try:
        # Try different formats
        formats = [
            '%Y-%m-%d %H:%M',
            '%m/%d/%Y %H:%M',
            '%d/%m/%Y %H:%M',
            '%Y-%m-%d %H:%M:%S'
        ]
        
        for fmt in formats:
            try:
                return datetime.strptime(time_str, fmt)
            except ValueError:
                continue
        
        return None
    except Exception as e:
        logger.error(f"Error parsing schedule time '{time_str}': {e}")
        return None

# Callback Data Management

def encode_callback_data(prefix: str, data: Dict) -> str:
    """Encode callback data with length limit"""
    import json
    
    # Convert data to JSON string
    json_str = json.dumps(data, separators=(',', ':'))
    
    # Create callback data
    callback_data = f"{prefix}_{json_str}"
    
    # Check length limit
    if len(callback_data) > Config.MAX_CALLBACK_DATA_LENGTH:
        # Use hash for long data
        data_hash = hash_string(json_str)[:8]
        callback_data = f"{prefix}_hash_{data_hash}"
        
        # Store full data in cache (implement caching if needed)
        # For now, just truncate the data
        logger.warning(f"Callback data too long, using hash: {data_hash}")
    
    return callback_data

def decode_callback_data(callback_data: str) -> Tuple[str, Dict]:
    """Decode callback data"""
    import json
    
    parts = callback_data.split('_', 1)
    if len(parts) != 2:
        return callback_data, {}
    
    prefix, data_part = parts
    
    if data_part.startswith('hash_'):
        # Handle hashed data
        hash_value = data_part[5:]
        # Implement hash lookup if needed
        return prefix, {'hash': hash_value}
    
    try:
        data = json.loads(data_part)
        return prefix, data
    except json.JSONDecodeError:
        return prefix, {}

# File Operations

def ensure_directory_exists(directory: str):
    """Ensure directory exists, create if not"""
    os.makedirs(directory, exist_ok=True)

def get_safe_filename(filename: str, directory: str) -> str:
    """Get safe filename that doesn't conflict with existing files"""
    base_name, extension = os.path.splitext(filename)
    safe_name = sanitize_filename(filename)
    
    counter = 1
    while os.path.exists(os.path.join(directory, safe_name)):
        safe_name = f"{sanitize_filename(base_name)}_{counter}{extension}"
        counter += 1
    
    return safe_name

def cleanup_temp_files(directory: str, max_age_hours: int = 24):
    """Clean up temporary files older than specified hours"""
    import glob
    
    cutoff_time = datetime.now() - timedelta(hours=max_age_hours)
    
    for file_path in glob.glob(os.path.join(directory, '*')):
        try:
            file_time = datetime.fromtimestamp(os.path.getctime(file_path))
            if file_time < cutoff_time:
                os.remove(file_path)
                logger.info(f"Cleaned up temp file: {file_path}")
        except Exception as e:
            logger.error(f"Error cleaning up file {file_path}: {e}")
